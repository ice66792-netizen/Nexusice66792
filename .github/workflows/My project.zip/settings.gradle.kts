pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

// Product name is configurable: pass -PnexusProjectName="My Client" or edit gradle.properties.
rootProject.name = providers.gradleProperty("nexusProjectName").getOrElse("NexusCore")

include(":app")

include(":core:model")
include(":core:common")
include(":core:data")
include(":core:design")
include(":core:engine")

include(":engine:mock")
include(":engine:xray")

include(":feature:dashboard")
include(":feature:profiles")
include(":feature:settings")
include(":feature:personalization")
include(":feature:system")
