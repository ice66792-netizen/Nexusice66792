package dev.nexuscore.feature.system

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dev.nexuscore.common.NexusLog
import dev.nexuscore.common.SecretRedactor
import dev.nexuscore.data.BackupManager
import dev.nexuscore.data.ProfileRepository
import dev.nexuscore.data.SettingsRepository
import dev.nexuscore.engine.EngineRegistry
import dev.nexuscore.engine.VpnControl
import dev.nexuscore.model.BackupParseResult
import dev.nexuscore.model.BackupPart
import dev.nexuscore.model.EngineDiagnostics
import dev.nexuscore.model.EngineState
import dev.nexuscore.model.Profile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SystemUiState(
    val profile: Profile? = null,
    val state: EngineState = EngineState.Idle,
    val diagnostics: EngineDiagnostics? = null,
    val memoryMb: Long = 0L,
    val message: String? = null,
    val backupJson: String = ""
)

class SystemViewModel(
    private val settings: SettingsRepository,
    private val profiles: ProfileRepository,
    private val engines: EngineRegistry,
    private val backups: BackupManager,
    private val control: VpnControl,
    private val appVersion: String
) : ViewModel() {

    private val diagnostics = MutableStateFlow<EngineDiagnostics?>(null)
    private val message = MutableStateFlow<String?>(null)
    private val backupJson = MutableStateFlow("")

    val appVersionText: String = appVersion

    private val active = combine(profiles.profiles, settings.appSettings) { list, app ->
        list.firstOrNull { it.id == app.activeProfileId } ?: list.firstOrNull()
    }

    val state: StateFlow<SystemUiState> = combine(
        active, control.state, diagnostics, message, backupJson
    ) { profile, engineState, diag, msg, json ->
        SystemUiState(
            profile = profile,
            state = engineState,
            diagnostics = diag,
            memoryMb = readMemoryMb(),
            message = msg,
            backupJson = json
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SystemUiState())

    private val redacted = MutableStateFlow(true)
    val redactLogs: StateFlow<Boolean> = redacted.asStateFlow()

    fun refreshDiagnostics() = viewModelScope.launch {
        val profile = state.value.profile
        val provider = engines.provider(profile?.engineId ?: engines.selected.value)
        diagnostics.value = provider?.diagnostics()
    }

    fun exportReport(): String {
        val current = state.value
        val diag = current.diagnostics
        val builder = StringBuilder()
        builder.appendLine("Nexus Core diagnostics")
        builder.appendLine("app_version=$appVersion")
        builder.appendLine("engine=${diag?.engineId ?: "n/a"}")
        builder.appendLine("engine_version=${diag?.engineVersion ?: "n/a"}")
        builder.appendLine("state=${current.state}")
        builder.appendLine("profile=${current.profile?.name ?: "none"}")
        builder.appendLine("profile_protocol=${current.profile?.config?.protocol ?: "n/a"}")
        builder.appendLine("memory_mb=${current.memoryMb}")
        builder.appendLine("last_error=${diag?.lastError ?: "none"}")
        diag?.extra?.forEach { (key, value) -> builder.appendLine("$key=$value") }
        builder.appendLine("--- log tail ---")
        val logs = diag?.logTail ?: NexusLog.snapshot().takeLast(200)
        logs.forEach { line ->
            builder.appendLine(if (redacted.value) SecretRedactor.redact(line) else line)
        }
        return builder.toString()
    }

    fun setRedaction(enabled: Boolean) {
        redacted.value = enabled
        viewModelScope.launch { settings.updateAppSettings { it.copy(redactDiagnostics = enabled) } }
    }

    fun exportBackup(parts: Set<BackupPart>, includeSecrets: Boolean) = viewModelScope.launch {
        backupJson.value = backups.export(parts, includeSecrets)
        message.value = "Backup generated (${backupJson.value.length} chars)"
    }

    fun importBackup(raw: String, replaceProfiles: Boolean) = viewModelScope.launch {
        when (val result = backups.restore(raw, replaceProfiles)) {
            is BackupParseResult.Success -> message.value =
                "Restored: ${result.envelope.profiles.size} profiles, migrations=${result.appliedMigrations}"

            is BackupParseResult.Failure -> message.value = "Import failed: ${result.reason}"
        }
    }

    fun clearBackup() {
        backupJson.value = ""
    }

    fun dismissMessage() {
        message.value = null
    }

    private fun readMemoryMb(): Long {
        val runtime = Runtime.getRuntime()
        val used = runtime.totalMemory() - runtime.freeMemory()
        return used / (1024 * 1024)
    }
}
