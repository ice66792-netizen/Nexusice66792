package dev.nexuscore.feature.system

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.nexuscore.design.Format
import dev.nexuscore.design.InfoBanner
import dev.nexuscore.design.KeyValueRow
import dev.nexuscore.design.NexusCard
import dev.nexuscore.design.NexusTextField
import dev.nexuscore.design.SectionHeader
import dev.nexuscore.design.SettingSwitchRow
import dev.nexuscore.model.BackupPart
import dev.nexuscore.model.EngineState
import dev.nexuscore.model.ValidationSeverity

@Composable
fun SystemScreen(
    state: SystemUiState,
    appVersion: String,
    redactLogs: Boolean,
    onRefresh: () -> Unit,
    onRedactionChange: (Boolean) -> Unit,
    onExportReport: () -> String,
    onExportBackup: (Set<BackupPart>, Boolean) -> Unit,
    onImportBackup: (String, Boolean) -> Unit,
    onDismissMessage: () -> Unit,
    modifier: Modifier = Modifier
) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val clipboard = LocalClipboardManager.current

    Column(modifier = modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            listOf("Diagnostics", "Backup", "About").forEachIndexed { index, title ->
                Tab(selected = tab == index, onClick = { tab = index }, text = { Text(title) })
            }
        }
        when (tab) {
            0 -> DiagnosticsTab(state, appVersion, redactLogs, onRefresh, onRedactionChange, onExportReport, clipboard, onDismissMessage)
            1 -> BackupTab(state, onExportBackup, onImportBackup, onDismissMessage, clipboard)
            else -> AboutTab(appVersion)
        }
    }
}

@Composable
private fun DiagnosticsTab(
    state: SystemUiState,
    appVersion: String,
    redactLogs: Boolean,
    onRefresh: () -> Unit,
    onRedactionChange: (Boolean) -> Unit,
    onExportReport: () -> String,
    clipboard: androidx.compose.ui.platform.ClipboardManager,
    onDismissMessage: () -> Unit
) {
    val diag = state.diagnostics
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        state.message?.let { text ->
            item {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    InfoBanner(text, ValidationSeverity.INFO, Modifier.weight(1f))
                    TextButton(onClick = onDismissMessage) { Text("OK") }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Runtime")
                    KeyValueRow("App version", appVersion)
                    KeyValueRow("Engine", diag?.engineId?.key ?: "not initialised")
                    KeyValueRow("Engine version", diag?.engineVersion ?: "—")
                    KeyValueRow("State", state.state.label())
                    KeyValueRow("Profile", state.profile?.name ?: "none")
                    KeyValueRow("Protocol", state.profile?.config?.protocol?.name ?: "—")
                    KeyValueRow("DNS mode", state.profile?.config?.dns?.mode?.name ?: "—")
                    KeyValueRow("IPv4 / IPv6", "${state.profile?.config?.network?.ipv4Enabled} / " +
                        "${state.profile?.config?.network?.ipv6Enabled}")
                    KeyValueRow("MTU", (state.profile?.config?.network?.mtu ?: 0).toString())
                    KeyValueRow("App memory", "${state.memoryMb} MB")
                    KeyValueRow("Last error", diag?.lastError ?: "none")
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onRefresh) { Text("Refresh") }
                OutlinedButton(onClick = {
                    clipboard.setText(AnnotatedString(onExportReport()))
                }) { Text("Copy report") }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SettingSwitchRow(
                        "Redact secrets",
                        "Remove UUIDs, passwords and tokens from the report",
                        redactLogs
                    ) { onRedactionChange(it) }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Log tail", "${diag?.logTail?.size ?: 0} lines")
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = (diag?.logTail ?: emptyList()).joinToString("\n").ifBlank { "No log entries yet." },
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun BackupTab(
    state: SystemUiState,
    onExport: (Set<BackupPart>, Boolean) -> Unit,
    onImport: (String, Boolean) -> Unit,
    onDismissMessage: () -> Unit,
    clipboard: androidx.compose.ui.platform.ClipboardManager
) {
    var parts by remember { mutableStateOf(BackupPart.values().toSet()) }
    var includeSecrets by remember { mutableStateOf(false) }
    var replaceProfiles by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        state.message?.let { message ->
            item {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    InfoBanner(message, ValidationSeverity.INFO, Modifier.weight(1f))
                    TextButton(onClick = onDismissMessage) { Text("OK") }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Export", "Versioned JSON, migrated on import")
                    BackupPart.values().forEach { part ->
                        SettingSwitchRow(
                            part.name.lowercase().replaceFirstChar { it.uppercase() },
                            null,
                            part in parts
                        ) { checked ->
                            parts = if (checked) parts + part else parts - part
                        }
                    }
                    SettingSwitchRow(
                        "Include secrets",
                        "UUIDs, passwords and keys will be written in plain text",
                        includeSecrets
                    ) { includeSecrets = it }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { onExport(parts, includeSecrets) },
                        enabled = parts.isNotEmpty()
                    ) { Text("Generate backup") }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Backup document")
                    Text(
                        "Copy it somewhere safe, or paste a backup below to restore.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    NexusTextField(
                        value = if (text.isBlank()) state.backupJson else text,
                        onValueChange = { text = it },
                        label = "Backup JSON",
                        singleLine = false
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            clipboard.setText(AnnotatedString(state.backupJson))
                        }) { Text("Copy") }
                        SettingSwitchRow("Replace profiles", null, replaceProfiles) { replaceProfiles = it }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            val payload = if (text.isBlank()) state.backupJson else text
                            onImport(payload, replaceProfiles)
                        },
                        enabled = (text.isNotBlank() || state.backupJson.isNotBlank())
                    ) { Text("Restore backup") }
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun AboutTab(appVersion: String) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("Nexus Core", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Version $appVersion", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Engine")
                    Text(
                        "The app talks to engines through EngineProvider. The bundled Xray adapter uses this " +
                            "project's own JNI bridge; the upstream Xray-core is licensed under MPL-2.0 and is not " +
                            "redistributed in this repository. The simulation engine is clearly marked and routes " +
                            "no traffic.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Data & privacy")
                    Text(
                        "No analytics, no telemetry, no remote logging. Everything is stored on device. " +
                            "Subscriptions are fetched over HTTPS only. Diagnostics mask secrets by default.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Credits")
                    Text(
                        "Xray-core (MPL-2.0) · AndroidX / Jetpack Compose (Apache-2.0) · OkHttp (Apache-2.0) · " +
                            "Kotlin & kotlinx.serialization (Apache-2.0).",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

private fun EngineState.label(): String = when (this) {
    is EngineState.Connected -> "connected since ${Format.duration(System.currentTimeMillis() - sinceEpochMillis)}"
    is EngineState.Connecting -> "connecting (attempt $attempt)"
    is EngineState.Preparing -> "preparing"
    is EngineState.Disconnecting -> "disconnecting"
    is EngineState.Failed -> "failed: $message"
    is EngineState.Unavailable -> "unavailable"
    EngineState.Idle -> "idle"
}
