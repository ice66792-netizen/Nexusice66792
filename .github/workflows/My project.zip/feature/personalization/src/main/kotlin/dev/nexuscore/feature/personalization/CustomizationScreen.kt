package dev.nexuscore.feature.personalization

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.nexuscore.design.ChoiceChips
import dev.nexuscore.design.InfoBanner
import dev.nexuscore.design.NexusCard
import dev.nexuscore.design.NexusTextField
import dev.nexuscore.design.SectionHeader
import dev.nexuscore.design.SettingSliderRow
import dev.nexuscore.design.SettingSwitchRow
import dev.nexuscore.model.AnimationLevel
import dev.nexuscore.model.CardStyle
import dev.nexuscore.model.DashboardBlock
import dev.nexuscore.model.IconPack
import dev.nexuscore.model.IndicatorStyle
import dev.nexuscore.model.QuickAction
import dev.nexuscore.model.StatsFormat
import dev.nexuscore.model.ThemeMode
import dev.nexuscore.model.ThemePresets
import dev.nexuscore.model.ValidationSeverity

@Composable
fun CustomizationScreen(
    state: CustomizationUiState,
    onChangeTheme: ((dev.nexuscore.model.ThemeSettings) -> dev.nexuscore.model.ThemeSettings) -> Unit,
    onApplyScheme: (dev.nexuscore.model.ThemeScheme) -> Unit,
    onSaveScheme: (String) -> Unit,
    onDeleteScheme: (String) -> Unit,
    onToggleBlock: (DashboardBlock, Boolean) -> Unit,
    onMoveBlock: (DashboardBlock, Boolean) -> Unit,
    onToggleQuickAction: (QuickAction, Boolean) -> Unit,
    onDashboard: ((dev.nexuscore.model.DashboardSettings) -> dev.nexuscore.model.DashboardSettings) -> Unit,
    onExportScheme: () -> String,
    onImportScheme: (String) -> Boolean,
    onDismissMessage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val theme = state.theme.active
    val clipboard = LocalClipboardManager.current
    var schemeName by remember { mutableStateOf("") }
    var exportText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("Personalization", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    "Every value below is persisted and applied immediately.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        state.message?.let { text ->
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    InfoBanner(text, ValidationSeverity.INFO, Modifier.weight(1f))
                    TextButton(onClick = onDismissMessage) { Text("OK") }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Appearance")
                    ChoiceChips(ThemeMode.values().toList(), theme.mode, { it.name }) { mode ->
                        onChangeTheme { it.copy(mode = mode) }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Presets", style = MaterialTheme.typography.labelMedium)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(ThemePresets.all) { preset ->
                            val selected = theme.presetId == preset.id
                            Column(
                                modifier = Modifier
                                    .width(76.dp)
                                    .clickable {
                                        onChangeTheme {
                                            it.copy(presetId = preset.id, accentColor = preset.accent)
                                        }
                                    },
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.linearGradient(
                                                listOf(
                                                    Color(preset.accent),
                                                    Color(preset.backgroundDark)
                                                )
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (selected) {
                                        Box(
                                            Modifier
                                                .size(12.dp)
                                                .background(Color.White, CircleShape)
                                        )
                                    }
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    preset.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Custom colours")
                    Text(
                        "Accent: #${Integer.toHexString(theme.accentColor.toInt()).uppercase()}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    SettingSliderRow(
                        "Red", ((theme.accentColor shr 16) and 0xFF).toFloat(), 0f..255f,
                        "${(theme.accentColor shr 16) and 0xFF}"
                    ) { v -> onChangeTheme { it.copy(accentColor = replaceChannel(it.accentColor, 16, v.toInt())) } }
                    SettingSliderRow(
                        "Green", ((theme.accentColor shr 8) and 0xFF).toFloat(), 0f..255f,
                        "${(theme.accentColor shr 8) and 0xFF}"
                    ) { v -> onChangeTheme { it.copy(accentColor = replaceChannel(it.accentColor, 8, v.toInt())) } }
                    SettingSliderRow(
                        "Blue", (theme.accentColor and 0xFF).toFloat(), 0f..255f,
                        "${theme.accentColor and 0xFF}"
                    ) { v -> onChangeTheme { it.copy(accentColor = replaceChannel(it.accentColor, 0, v.toInt())) } }
                    SettingSwitchRow(
                        "Custom background",
                        "Off = preset background is used",
                        theme.backgroundColor != null
                    ) { enabled ->
                        onChangeTheme { it.copy(backgroundColor = if (enabled) 0xFF101418 else null) }
                    }
                    SettingSwitchRow(
                        "Custom surface",
                        "Off = preset surface is used",
                        theme.surfaceColor != null
                    ) { enabled ->
                        onChangeTheme { it.copy(surfaceColor = if (enabled) 0xFF1A1F28 else null) }
                    }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Shape & density")
                    SettingSliderRow(
                        "Corner radius", theme.cornerRadiusDp.toFloat(), 0f..36f, "${theme.cornerRadiusDp} dp"
                    ) { v -> onChangeTheme { it.copy(cornerRadiusDp = v.toInt()) } }
                    SettingSliderRow(
                        "Density", theme.densityScale, 0.8f..1.2f,
                        "${"%.2f".format(theme.densityScale)}x"
                    ) { v -> onChangeTheme { it.copy(densityScale = v) } }
                    SettingSliderRow(
                        "Font scale", theme.fontScale, 0.8f..1.4f, "${"%.2f".format(theme.fontScale)}x"
                    ) { v -> onChangeTheme { it.copy(fontScale = v) } }
                    SettingSliderRow(
                        "Contrast", theme.contrast, 0f..1f, "${(theme.contrast * 100).toInt()}%"
                    ) { v -> onChangeTheme { it.copy(contrast = v) } }
                    Spacer(Modifier.height(8.dp))
                    Text("Card style", style = MaterialTheme.typography.labelMedium)
                    ChoiceChips(CardStyle.values().toList(), theme.cardStyle, { it.name }) { style ->
                        onChangeTheme { it.copy(cardStyle = style) }
                    }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Icons & motion")
                    Text("Icon pack", style = MaterialTheme.typography.labelMedium)
                    ChoiceChips(IconPack.values().toList(), theme.iconPack, { it.name }) { pack ->
                        onChangeTheme { it.copy(iconPack = pack) }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Animation level", style = MaterialTheme.typography.labelMedium)
                    ChoiceChips(AnimationLevel.values().toList(), theme.animationLevel, { it.name }) { level ->
                        onChangeTheme { it.copy(animationLevel = level) }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Connection indicator", style = MaterialTheme.typography.labelMedium)
                    ChoiceChips(IndicatorStyle.values().toList(), theme.indicatorStyle, { it.name }) { style ->
                        onChangeTheme { it.copy(indicatorStyle = style) }
                    }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Saved themes")
                    state.theme.savedSchemes.forEach { scheme ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(scheme.name, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    if (scheme.builtIn) "Built-in" else "Custom",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            TextButton(onClick = { onApplyScheme(scheme) }) { Text("Apply") }
                            if (!scheme.builtIn) {
                                TextButton(onClick = { onDeleteScheme(scheme.id) }) { Text("Delete") }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    NexusTextField(schemeName, { schemeName = it }, "Theme name", placeholder = "Night blue")
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onSaveScheme(schemeName); schemeName = "" }) {
                            Icon(Icons.Outlined.Add, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("Save theme")
                        }
                        OutlinedButton(onClick = {
                            exportText = onExportScheme()
                            clipboard.setText(AnnotatedString(exportText))
                        }) {
                            Text("Export")
                        }
                        OutlinedButton(
                            onClick = {
                                if (onImportScheme(exportText)) exportText = ""
                            },
                            enabled = exportText.isNotBlank()
                        ) {
                            Text("Import")
                        }
                    }
                    if (exportText.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Theme JSON (also copied to clipboard; edit it here to import):",
                            style = MaterialTheme.typography.bodySmall
                        )
                        NexusTextField(
                            value = exportText,
                            onValueChange = { exportText = it },
                            label = "Theme JSON",
                            singleLine = false
                        )
                    }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Dashboard blocks")
                    state.dashboard.orderedBlocks().forEachIndexed { index, block ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Switch(
                                checked = block in state.dashboard.visibleBlocks,
                                onCheckedChange = { onToggleBlock(block, it) }
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                block.name.lowercase().replaceFirstChar { it.uppercase() },
                                modifier = Modifier.weight(1f),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            IconButton(onClick = { onMoveBlock(block, true) }, enabled = index > 0) {
                                Icon(Icons.Outlined.KeyboardArrowUp, contentDescription = "Up")
                            }
                            IconButton(
                                onClick = { onMoveBlock(block, false) },
                                enabled = index < state.dashboard.orderedBlocks().lastIndex
                            ) {
                                Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = "Down")
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Stats format", style = MaterialTheme.typography.labelMedium)
                    ChoiceChips(StatsFormat.values().toList(), state.dashboard.statsFormat, { it.name }) { format ->
                        onDashboard { it.copy(statsFormat = format) }
                    }
                    SettingSwitchRow("Compact cards", null, state.dashboard.compact) { value ->
                        onDashboard { it.copy(compact = value) }
                    }
                    SettingSwitchRow("Show live rates", null, state.dashboard.showRates) { value ->
                        onDashboard { it.copy(showRates = value) }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Quick actions", style = MaterialTheme.typography.labelMedium)
                    QuickAction.values().forEach { action ->
                        SettingSwitchRow(
                            action.name.lowercase().replaceFirstChar { it.uppercase() },
                            null,
                            action in state.dashboard.quickActions
                        ) { enabled -> onToggleQuickAction(action, enabled) }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }
}

private fun replaceChannel(color: Long, shift: Int, value: Int): Long {
    val mask = 0xFFL shl shift
    val cleared = color and mask.inv()
    return cleared or ((value.toLong() and 0xFF) shl shift)
}
