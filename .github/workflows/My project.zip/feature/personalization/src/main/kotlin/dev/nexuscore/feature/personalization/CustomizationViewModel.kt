package dev.nexuscore.feature.personalization

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dev.nexuscore.data.NexusJson
import dev.nexuscore.data.SettingsRepository
import dev.nexuscore.model.DashboardBlock
import dev.nexuscore.model.DashboardSettings
import dev.nexuscore.model.QuickAction
import dev.nexuscore.model.ThemeScheme
import dev.nexuscore.model.ThemeSettings
import dev.nexuscore.model.ThemeState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import java.util.UUID

data class CustomizationUiState(
    val theme: ThemeState = ThemeState(),
    val dashboard: DashboardSettings = DashboardSettings(),
    val message: String? = null
)

class CustomizationViewModel(private val settings: SettingsRepository) : ViewModel() {

    private val message = MutableStateFlow<String?>(null)

    val state: StateFlow<CustomizationUiState> = combine(
        settings.themeState, settings.dashboardSettings, message
    ) { theme, dashboard, msg ->
        CustomizationUiState(theme, dashboard, msg)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CustomizationUiState())

    fun updateTheme(transform: (ThemeSettings) -> ThemeSettings) = viewModelScope.launch {
        settings.updateTheme { state ->
            state.copy(active = transform(state.active), activeSchemeId = "custom")
        }
    }

    fun applyScheme(scheme: ThemeScheme) = viewModelScope.launch {
        settings.updateTheme { it.copy(active = scheme.settings, activeSchemeId = scheme.id) }
    }

    fun saveScheme(name: String) = viewModelScope.launch {
        val active = state.value.theme.active
        val scheme = ThemeScheme(
            id = UUID.randomUUID().toString(),
            name = name.ifBlank { "My theme" },
            builtIn = false,
            settings = active
        )
        settings.updateTheme { it.copy(savedSchemes = it.savedSchemes + scheme, activeSchemeId = scheme.id) }
        message.value = "Theme '${scheme.name}' saved"
    }

    fun deleteScheme(id: String) = viewModelScope.launch {
        settings.updateTheme { it.copy(savedSchemes = it.savedSchemes.filterNot { s -> s.id == id }) }
    }

    fun exportActiveScheme(): String {
        val scheme = ThemeScheme(
            id = UUID.randomUUID().toString(),
            name = "Exported theme",
            settings = state.value.theme.active
        )
        message.value = "Theme JSON copied to the export field"
        return NexusJson.pretty.encodeToString(ThemeScheme.serializer(), scheme)
    }

    fun importScheme(raw: String): Boolean {
        val scheme = runCatching {
            NexusJson.instance.decodeFromString(ThemeScheme.serializer(), raw)
        }.getOrNull()
        if (scheme == null) {
            message.value = "Theme JSON is invalid"
            return false
        }
        viewModelScope.launch {
            val copy = scheme.copy(id = UUID.randomUUID().toString(), builtIn = false)
            settings.updateTheme { it.copy(savedSchemes = it.savedSchemes + copy) }
            message.value = "Theme '${copy.name}' imported"
        }
        return true
    }

    fun updateDashboard(transform: (DashboardSettings) -> DashboardSettings) = viewModelScope.launch {
        settings.updateDashboard(transform)
    }

    fun toggleBlock(block: DashboardBlock, visible: Boolean) = updateDashboard { dashboard ->
        if (visible) {
            dashboard.copy(visibleBlocks = (dashboard.visibleBlocks + block).distinct())
        } else {
            dashboard.copy(visibleBlocks = dashboard.visibleBlocks - block)
        }
    }

    fun moveBlock(block: DashboardBlock, up: Boolean) = updateDashboard { dashboard ->
        val order = dashboard.orderedBlocks().toMutableList()
        val index = order.indexOf(block)
        val target = if (up) index - 1 else index + 1
        if (index < 0 || target !in order.indices) return@updateDashboard dashboard
        val item = order.removeAt(index)
        order.add(target, item)
        dashboard.copy(
            blockOrder = order,
            visibleBlocks = dashboard.visibleBlocks.toMutableList().also { it.sortedBy { b -> order.indexOf(b) } }
        )
    }

    fun toggleQuickAction(action: QuickAction, enabled: Boolean) = updateDashboard { dashboard ->
        dashboard.copy(
            quickActions = if (enabled) {
                (dashboard.quickActions + action).distinct()
            } else {
                dashboard.quickActions - action
            }
        )
    }

    fun dismissMessage() {
        message.value = null
    }
}
