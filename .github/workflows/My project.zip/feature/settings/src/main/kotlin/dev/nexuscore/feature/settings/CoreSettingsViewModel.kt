package dev.nexuscore.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dev.nexuscore.data.NexusJson
import dev.nexuscore.data.ProfileRepository
import dev.nexuscore.data.SettingsRepository
import dev.nexuscore.data.ConfigMerger
import dev.nexuscore.engine.EngineRegistry
import dev.nexuscore.model.ConfigOverrides
import dev.nexuscore.model.DnsOptions
import dev.nexuscore.model.EngineDescriptor
import dev.nexuscore.model.EngineId
import dev.nexuscore.model.NetworkOptions
import dev.nexuscore.model.NexusConfig
import dev.nexuscore.model.PerformanceOptions
import dev.nexuscore.model.Profile
import dev.nexuscore.model.RoutingOptions
import dev.nexuscore.model.RoutingRule
import dev.nexuscore.model.RuleAction
import dev.nexuscore.model.RuleKind
import dev.nexuscore.model.ValidationReport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import java.util.UUID

data class CoreSettingsUiState(
    val profile: Profile? = null,
    val config: NexusConfig = NexusConfig(),
    val overrides: ConfigOverrides = ConfigOverrides(),
    val descriptor: EngineDescriptor? = null,
    val engines: List<EngineDescriptor> = emptyList(),
    val report: ValidationReport? = null,
    val message: String? = null
)

class CoreSettingsViewModel(
    private val profiles: ProfileRepository,
    private val settings: SettingsRepository,
    private val engines: EngineRegistry
) : ViewModel() {

    private val report = MutableStateFlow<ValidationReport?>(null)
    private val message = MutableStateFlow<String?>(null)

    private val active = combine(profiles.profiles, settings.appSettings) { list, app ->
        list.firstOrNull { it.id == app.activeProfileId } ?: list.firstOrNull()
    }

    val state: StateFlow<CoreSettingsUiState> = combine(
        active, engines.selected, report, message
    ) { profile, engineId, currentReport, currentMessage ->
        val effective = profile?.let { ConfigMerger.merge(it.config, it.overrides).config } ?: NexusConfig()
        CoreSettingsUiState(
            profile = profile,
            config = effective,
            overrides = profile?.overrides ?: ConfigOverrides(),
            descriptor = engines.provider(engineId)?.descriptor(),
            engines = engines.descriptors(),
            report = currentReport,
            message = currentMessage
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CoreSettingsUiState())

    fun dismissMessage() {
        message.value = null
    }

    private fun persist(
        update: (Profile) -> Profile
    ) = viewModelScope.launch {
        val profile = state.value.profile ?: return@launch
        profiles.upsert(update(profile))
        validateNow()
    }

    fun updateNetwork(transform: (NetworkOptions) -> NetworkOptions) = persist { profile ->
        profile.copy(overrides = profile.overrides.copy(
            network = transform(ConfigMerger.merge(profile.config, profile.overrides).config.network)
        ))
    }

    fun updateDns(transform: (DnsOptions) -> DnsOptions) = persist { profile ->
        profile.copy(overrides = profile.overrides.copy(
            dns = transform(ConfigMerger.merge(profile.config, profile.overrides).config.dns)
        ))
    }

    fun updatePerformance(transform: (PerformanceOptions) -> PerformanceOptions) = persist { profile ->
        profile.copy(overrides = profile.overrides.copy(
            performance = transform(ConfigMerger.merge(profile.config, profile.overrides).config.performance)
        ))
    }

    fun updateRouting(transform: (RoutingOptions) -> RoutingOptions) = persist { profile ->
        profile.copy(overrides = profile.overrides.copy(
            routing = transform(ConfigMerger.merge(profile.config, profile.overrides).config.routing)
        ))
    }

    fun addRule(kind: RuleKind, value: String, action: RuleAction) = updateRouting { routing ->
        routing.copy(
            rules = routing.rules + RoutingRule(
                id = UUID.randomUUID().toString(),
                kind = kind,
                value = value.trim(),
                action = action
            )
        )
    }

    fun removeRule(id: String) = updateRouting { routing ->
        routing.copy(rules = routing.rules.filterNot { it.id == id })
    }

    fun moveRule(id: String, up: Boolean) = updateRouting { routing ->
        val list = routing.rules.toMutableList()
        val index = list.indexOfFirst { it.id == id }
        if (index < 0) return@updateRouting routing
        val target = if (up) index - 1 else index + 1
        if (target !in list.indices) return@updateRouting routing
        val item = list.removeAt(index)
        list.add(target, item)
        routing.copy(rules = list)
    }

    fun setRuleEnabled(id: String, enabled: Boolean) = updateRouting { routing ->
        routing.copy(rules = routing.rules.map { if (it.id == id) it.copy(enabled = enabled) else it })
    }

    fun selectEngine(id: EngineId) = viewModelScope.launch {
        if (!engines.select(id)) {
            message.value = "Engine is not part of this build"
            return@launch
        }
        settings.updateAppSettings { it.copy(selectedEngine = id) }
        state.value.profile?.let { profiles.upsert(it.copy(engineId = id)) }
        validateNow()
    }

    fun validateNow() = viewModelScope.launch {
        val profile = state.value.profile ?: return@launch
        val provider = engines.provider(profile.engineId) ?: return@launch
        report.value = provider.validate(ConfigMerger.merge(profile.config, profile.overrides).config)
    }

    fun resetOverrides() = persist { it.copy(overrides = ConfigOverrides()) }

    fun configJson(): String {
        val profile = state.value.profile ?: return "{}"
        val effective = ConfigMerger.merge(profile.config, profile.overrides).config
        return NexusJson.pretty.encodeToString(NexusConfig.serializer(), effective)
    }
}
