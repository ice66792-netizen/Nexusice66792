package dev.nexuscore.feature.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.nexuscore.design.ChoiceChips
import dev.nexuscore.design.InfoBanner
import dev.nexuscore.design.KeyValueRow
import dev.nexuscore.design.NexusCard
import dev.nexuscore.design.NexusTextField
import dev.nexuscore.design.SectionHeader
import dev.nexuscore.design.SettingSliderRow
import dev.nexuscore.design.SettingSwitchRow
import dev.nexuscore.model.DnsMode
import dev.nexuscore.model.EngineId
import dev.nexuscore.model.LogLevel
import dev.nexuscore.model.QueryStrategy
import dev.nexuscore.model.RuleAction
import dev.nexuscore.model.RuleKind
import dev.nexuscore.model.ValidationSeverity

@Composable
fun CoreSettingsScreen(
    state: CoreSettingsUiState,
    onNetwork: ((dev.nexuscore.model.NetworkOptions) -> dev.nexuscore.model.NetworkOptions) -> Unit,
    onDns: ((dev.nexuscore.model.DnsOptions) -> dev.nexuscore.model.DnsOptions) -> Unit,
    onPerformance: ((dev.nexuscore.model.PerformanceOptions) -> dev.nexuscore.model.PerformanceOptions) -> Unit,
    onAddRule: (RuleKind, String, RuleAction) -> Unit,
    onRemoveRule: (String) -> Unit,
    onMoveRule: (String, Boolean) -> Unit,
    onToggleRule: (String, Boolean) -> Unit,
    onSelectEngine: (EngineId) -> Unit,
    onValidate: () -> Unit,
    onResetOverrides: () -> Unit,
    onDismissMessage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val config = state.config
    var showRuleDialog by remember { mutableStateOf(false) }
    var showAdvanced by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("core_settings"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("Core settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    "Only parameters the selected engine actually supports are shown.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        state.message?.let { text ->
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    InfoBanner(text, ValidationSeverity.INFO, Modifier.weight(1f))
                    TextButton(onClick = onDismissMessage) { Text("OK") }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Engine")
                    state.engines.forEach { descriptor ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "${descriptor.displayName} · ${descriptor.version}",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    if (descriptor.isAvailable) descriptor.buildInfo
                                    else (descriptor.availability as? dev.nexuscore.model.EngineAvailability.Unavailable)
                                        ?.reasons?.firstOrNull() ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            OutlinedButton(
                                onClick = { onSelectEngine(descriptor.id) },
                                enabled = state.descriptor?.id != descriptor.id
                            ) { Text("Use") }
                        }
                    }
                    if (state.descriptor?.isSimulated == true) {
                        InfoBanner(
                            "Simulation engine selected: no traffic is routed.",
                            ValidationSeverity.WARNING
                        )
                    }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Network", "Applied as profile overrides")
                    KeyValueRow("MTU", config.network.mtu.toString())
                    SettingSliderRow(
                        title = "MTU",
                        value = config.network.mtu.toFloat(),
                        range = 576f..9000f,
                        valueLabel = "${config.network.mtu}",
                        onValueChange = { value -> onNetwork { it.copy(mtu = value.toInt()) } }
                    )
                    SettingSliderRow(
                        title = "Connect timeout",
                        value = config.network.connectTimeoutMs.toFloat(),
                        range = 1000f..30000f,
                        valueLabel = "${config.network.connectTimeoutMs} ms",
                        onValueChange = { value -> onNetwork { it.copy(connectTimeoutMs = value.toInt()) } }
                    )
                    SettingSliderRow(
                        title = "Reconnect attempts",
                        value = config.network.reconnect.maxAttempts.toFloat(),
                        range = 0f..10f,
                        valueLabel = "${config.network.reconnect.maxAttempts}",
                        onValueChange = { value ->
                            onNetwork {
                                it.copy(reconnect = it.reconnect.copy(maxAttempts = value.toInt()))
                            }
                        }
                    )
                    SettingSwitchRow(
                        "IPv4", "Route IPv4 traffic", config.network.ipv4Enabled
                    ) { enabled -> onNetwork { it.copy(ipv4Enabled = enabled) } }
                    SettingSwitchRow(
                        "IPv6", "Route IPv6 traffic", config.network.ipv6Enabled
                    ) { enabled -> onNetwork { it.copy(ipv6Enabled = enabled) } }
                    NexusTextField(
                        value = config.network.socksPort.toString(),
                        onValueChange = { text ->
                            text.toIntOrNull()?.let { port -> onNetwork { it.copy(socksPort = port) } }
                        },
                        label = "Local SOCKS port",
                        keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                    )
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("DNS")
                    ChoiceChips(
                        options = DnsMode.values().toList(),
                        selected = config.dns.mode,
                        label = { it.name.replace('_', ' ') }
                    ) { mode -> onDns { it.copy(mode = mode) } }
                    Spacer(Modifier.height(8.dp))
                    NexusTextField(
                        value = config.dns.servers.joinToString(", "),
                        onValueChange = { text ->
                            val servers = text.split(',').map { it.trim() }.filter { it.isNotEmpty() }
                            onDns { it.copy(servers = servers) }
                        },
                        label = "DNS servers",
                        placeholder = "1.1.1.1, tls://dns.google",
                        supportingText = when (config.dns.mode) {
                            DnsMode.SYSTEM -> "System resolver is used; servers are ignored."
                            DnsMode.DNS_OVER_TLS -> "Use tls://host or tls://IP"
                            DnsMode.DNS_OVER_HTTPS -> "Use https://host/dns-query"
                            DnsMode.UDP -> "Plain UDP resolvers"
                        }
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Query strategy", style = MaterialTheme.typography.labelMedium)
                    ChoiceChips(
                        options = QueryStrategy.values().toList(),
                        selected = config.dns.queryStrategy,
                        label = { it.name.replace('_', ' ') }
                    ) { strategy -> onDns { it.copy(queryStrategy = strategy) } }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SectionHeader("Routing", "Order matters: first match wins", Modifier.weight(1f))
                        TextButton(onClick = { showRuleDialog = true }) { Text("Add") }
                    }
                    if (config.routing.rules.isEmpty()) {
                        Text(
                            "No rules. All traffic goes through the proxy.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    config.routing.rules.forEachIndexed { index, rule ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "${rule.kind.name} · ${rule.value}",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    "→ ${rule.action.name}" + if (rule.note.isBlank()) "" else " · ${rule.note}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = rule.enabled,
                                onCheckedChange = { onToggleRule(rule.id, it) }
                            )
                            IconButton(onClick = { onMoveRule(rule.id, true) }, enabled = index > 0) {
                                Icon(Icons.Outlined.KeyboardArrowUp, contentDescription = "Move up")
                            }
                            IconButton(
                                onClick = { onMoveRule(rule.id, false) },
                                enabled = index < config.routing.rules.lastIndex
                            ) {
                                Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = "Move down")
                            }
                            IconButton(onClick = { onRemoveRule(rule.id) }) {
                                Icon(Icons.Outlined.Delete, contentDescription = "Delete")
                            }
                        }
                    }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Performance")
                    ChoiceChips(
                        options = LogLevel.values().toList(),
                        selected = config.performance.logLevel,
                        label = { it.name }
                    ) { level -> onPerformance { it.copy(logLevel = level) } }
                    SettingSliderRow(
                        title = "Stats refresh",
                        value = config.performance.statsRefreshIntervalMs.toFloat(),
                        range = 250f..5000f,
                        valueLabel = "${config.performance.statsRefreshIntervalMs} ms",
                        onValueChange = { value ->
                            onPerformance { it.copy(statsRefreshIntervalMs = value.toLong()) }
                        }
                    )
                    SettingSliderRow(
                        title = "Log buffer",
                        value = config.performance.logBufferLines.toFloat(),
                        range = 100f..2000f,
                        valueLabel = "${config.performance.logBufferLines} lines",
                        onValueChange = { value ->
                            onPerformance { it.copy(logBufferLines = value.toInt()) }
                        }
                    )
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SectionHeader("Expert mode", "Validation, limits, native JSON", Modifier.weight(1f))
                        Switch(checked = showAdvanced, onCheckedChange = { showAdvanced = it })
                    }
                    if (showAdvanced) {
                        val report = state.report
                        if (report == null) {
                            Text("Not validated yet.", style = MaterialTheme.typography.bodySmall)
                        } else {
                            Text(
                                if (report.isValid) "Configuration is valid" else "Configuration has errors",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            report.issues.take(12).forEach { issue ->
                                InfoBanner(
                                    "${issue.severity.name}: ${issue.message}",
                                    issue.severity,
                                    Modifier.padding(vertical = 3.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = onValidate) { Text("Validate") }
                            OutlinedButton(onClick = onResetOverrides) { Text("Reset overrides") }
                        }
                        if (!config.rawJson.isNullOrBlank()) {
                            Spacer(Modifier.height(8.dp))
                            InfoBanner(
                                "This profile uses a native JSON config; form values are ignored by the engine.",
                                ValidationSeverity.WARNING
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }

    if (showRuleDialog) {
        AddRuleDialog(
            onDismiss = { showRuleDialog = false },
            onAdd = { kind, value, action ->
                onAddRule(kind, value, action)
                showRuleDialog = false
            }
        )
    }
}

@Composable
private fun AddRuleDialog(
    onDismiss: () -> Unit,
    onAdd: (RuleKind, String, RuleAction) -> Unit
) {
    var kind by remember { mutableStateOf(RuleKind.DOMAIN_SUFFIX) }
    var value by remember { mutableStateOf("") }
    var action by remember { mutableStateOf(RuleAction.DIRECT) }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New routing rule") },
        text = {
            Column {
                Text("Match type", style = MaterialTheme.typography.labelMedium)
                ChoiceChips(
                    options = listOf(RuleKind.DOMAIN_SUFFIX, RuleKind.DOMAIN, RuleKind.IP_CIDR, RuleKind.PORT),
                    selected = kind,
                    label = { it.name.replace('_', ' ') }
                ) { kind = it }
                Spacer(Modifier.height(8.dp))
                NexusTextField(value, { value = it }, label = "Value", placeholder = "example.com")
                Spacer(Modifier.height(8.dp))
                Text("Action", style = MaterialTheme.typography.labelMedium)
                ChoiceChips(
                    options = RuleAction.values().toList(),
                    selected = action,
                    label = { it.name }
                ) { action = it }
            }
        },
        confirmButton = {
            TextButton(onClick = { onAdd(kind, value, action) }, enabled = value.isNotBlank()) {
                Text("Add")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
