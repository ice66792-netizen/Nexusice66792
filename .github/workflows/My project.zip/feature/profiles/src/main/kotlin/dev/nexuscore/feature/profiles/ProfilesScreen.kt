package dev.nexuscore.feature.profiles

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FileCopy
import androidx.compose.material.icons.outlined.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.nexuscore.design.EmptyState
import dev.nexuscore.design.InfoBanner
import dev.nexuscore.design.NexusCard
import dev.nexuscore.design.NexusTextField
import dev.nexuscore.design.SectionHeader
import dev.nexuscore.design.StatusPill
import dev.nexuscore.design.SettingSliderRow
import dev.nexuscore.model.Profile
import dev.nexuscore.model.Subscription
import dev.nexuscore.model.ValidationStatus
import dev.nexuscore.model.ValidationSeverity

@Composable
fun ProfilesScreen(
    profiles: List<Profile>,
    activeId: String?,
    subscriptions: List<Subscription>,
    importText: String,
    message: String?,
    onImportTextChange: (String) -> Unit,
    onImport: () -> Unit,
    onSelect: (String) -> Unit,
    onCreate: () -> Unit,
    onEdit: (Profile) -> Unit,
    onDuplicate: (String) -> Unit,
    onDelete: (String) -> Unit,
    onAddSubscription: (String, String) -> Unit,
    onRefreshSubscription: (String) -> Unit,
    onRemoveSubscription: (String) -> Unit,
    onOpenSubscriptions: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("profiles"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Profiles", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(
                        "${profiles.size} saved · ${subscriptions.size} subscriptions",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OutlinedButton(onClick = onCreate) {
                    Icon(Icons.Outlined.Add, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("New")
                }
            }
        }

        message?.let { item { InfoBanner(it, ValidationSeverity.INFO) } }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Import share link", "vless, vmess, trojan, ss, socks")
                    NexusTextField(
                        value = importText,
                        onValueChange = onImportTextChange,
                        label = "Paste link",
                        singleLine = false
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = onImport, enabled = importText.isNotBlank()) {
                        Text("Import and edit")
                    }
                }
            }
        }

        if (profiles.isEmpty()) {
            item {
                EmptyState(
                    "No profiles yet",
                    "Create a profile manually, import a share link, or add a subscription."
                )
            }
        }

        items(profiles, key = { it.id }) { profile ->
            val status = profile.validation.status
            NexusCard(onClick = { onSelect(profile.id) }) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                profile.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (profile.id == activeId) {
                                Spacer(Modifier.width(8.dp))
                                StatusPill("active", MaterialTheme.colorScheme.primary)
                            }
                        }
                        Text(
                            "${profile.config.protocol.name} · ${profile.config.endpoint.address}:" +
                                "${profile.config.endpoint.port} · ${profile.engineId.key}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            when (status) {
                                ValidationStatus.VALID -> "Validated"
                                ValidationStatus.WARNING -> "Warnings: ${profile.validation.message}"
                                ValidationStatus.INVALID -> "Invalid: ${profile.validation.message}"
                                ValidationStatus.UNKNOWN -> "Not validated yet"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = when (status) {
                                ValidationStatus.INVALID -> MaterialTheme.colorScheme.error
                                ValidationStatus.WARNING -> Color(0xFFE0A020)
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }
                    IconButton(onClick = { onEdit(profile) }) {
                        Icon(Icons.Outlined.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = { onDuplicate(profile.id) }) {
                        Icon(Icons.Outlined.FileCopy, contentDescription = "Duplicate")
                    }
                    IconButton(onClick = { onDelete(profile.id) }) {
                        Icon(Icons.Outlined.Delete, contentDescription = "Delete")
                    }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SectionHeader("Subscriptions", "Auto-refresh keeps your overrides", Modifier.weight(1f))
                        TextButton(onClick = onOpenSubscriptions) { Text("Manage") }
                    }
                    if (subscriptions.isEmpty()) {
                        Text(
                            "No subscriptions added.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    subscriptions.forEach { subscription ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(subscription.name, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    subscription.lastError ?: dev.nexuscore.design.Format.timeAgo(
                                        subscription.lastFetchedAtEpochMillis
                                    ),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (subscription.lastError != null) {
                                        MaterialTheme.colorScheme.error
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                            IconButton(onClick = { onRefreshSubscription(subscription.id) }) {
                                Icon(Icons.Outlined.Sync, contentDescription = "Refresh")
                            }
                            IconButton(onClick = { onRemoveSubscription(subscription.id) }) {
                                Icon(Icons.Outlined.Delete, contentDescription = "Remove")
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun SubscriptionsScreen(
    subscriptions: List<Subscription>,
    onAdd: (String, String) -> Unit,
    onRefresh: (String) -> Unit,
    onRemove: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var name by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    var url by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("Back") }
                Text("Subscriptions", style = MaterialTheme.typography.titleLarge)
            }
        }
        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Add subscription", "HTTPS only")
                    NexusTextField(name, { name = it }, "Name")
                    Spacer(Modifier.height(8.dp))
                    NexusTextField(url, { url = it }, "URL", placeholder = "https://example.com/sub")
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            onAdd(name, url)
                            name = ""
                            url = ""
                        },
                        enabled = url.startsWith("https://") || url.contains("127.0.0.1")
                    ) { Text("Add and fetch") }
                }
            }
        }
        items(subscriptions, key = { it.id }) { subscription ->
            NexusCard {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(subscription.name, style = MaterialTheme.typography.titleSmall)
                        Text(
                            dev.nexuscore.common.SecretRedactor.sanitizeUrl(subscription.url),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            subscription.lastError ?: "Updated ${dev.nexuscore.design.Format.timeAgo(subscription.lastFetchedAtEpochMillis)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (subscription.lastError != null) {
                                MaterialTheme.colorScheme.error
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }
                    IconButton(onClick = { onRefresh(subscription.id) }) {
                        Icon(Icons.Outlined.Sync, contentDescription = "Refresh")
                    }
                    IconButton(onClick = { onRemove(subscription.id) }) {
                        Icon(Icons.Outlined.Delete, contentDescription = "Remove")
                    }
                }
            }
        }
    }
}
