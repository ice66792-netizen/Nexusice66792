package dev.nexuscore.feature.profiles

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.nexuscore.design.ChoiceChips
import dev.nexuscore.design.InfoBanner
import dev.nexuscore.design.KeyValueRow
import dev.nexuscore.design.NexusCard
import dev.nexuscore.design.NexusTextField
import dev.nexuscore.design.SectionHeader
import dev.nexuscore.design.SettingSwitchRow
import dev.nexuscore.model.ProxyProtocol
import dev.nexuscore.model.SecurityMode
import dev.nexuscore.model.TransportNetwork
import dev.nexuscore.model.ValidationSeverity

@Composable
fun ProfileEditorScreen(
    state: ProfileEditorState,
    onClose: () -> Unit,
    onUpdateName: (String) -> Unit,
    onUpdateDescription: (String) -> Unit,
    onProtocol: (ProxyProtocol) -> Unit,
    onEndpoint: ((dev.nexuscore.model.ServerEndpoint) -> dev.nexuscore.model.ServerEndpoint) -> Unit,
    onTransport: ((dev.nexuscore.model.TransportOptions) -> dev.nexuscore.model.TransportOptions) -> Unit,
    onSecurity: ((dev.nexuscore.model.SecurityOptions) -> dev.nexuscore.model.SecurityOptions) -> Unit,
    onRawJson: (String) -> Unit,
    onClearRawJson: () -> Unit,
    onResetOverrides: () -> Unit,
    onValidate: () -> Unit,
    onSave: () -> Unit,
    modifier: Modifier = Modifier
) {
    val draft = state.draft
    if (draft == null) {
        Column(modifier.fillMaxSize().padding(24.dp)) {
            Text("Profile not found")
            TextButton(onClick = onClose) { Text("Back") }
        }
        return
    }
    val config = draft.config
    val endpoint = config.endpoint

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onClose) { Text("Back") }
                Text(
                    if (state.isNew) "New profile" else "Edit profile",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        state.message?.let { item { InfoBanner(it, ValidationSeverity.INFO) } }
        state.effective?.usedRawJson?.let { used ->
            if (used) {
                item {
                    InfoBanner(
                        "This profile carries a native JSON config. Form values are kept as fallback and are " +
                            "ignored while the JSON is present.",
                        ValidationSeverity.WARNING
                    )
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Identity")
                    NexusTextField(draft.name, onUpdateName, "Name")
                    Spacer(Modifier.height(8.dp))
                    NexusTextField(draft.description, onUpdateDescription, "Description")
                    Spacer(Modifier.height(8.dp))
                    KeyValueRow("Engine", draft.engineId.key)
                    KeyValueRow("Source", draft.source.name)
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Protocol")
                    ChoiceChips(
                        options = ProxyProtocol.values().toList(),
                        selected = config.protocol,
                        label = { it.name }
                    ) { protocol -> onProtocol(protocol) }
                    Spacer(Modifier.height(8.dp))
                    NexusTextField(
                        value = endpoint.address,
                        onValueChange = { value -> onEndpoint { it.copy(address = value.trim()) } },
                        label = "Server address",
                        placeholder = "example.com"
                    )
                    Spacer(Modifier.height(8.dp))
                    NexusTextField(
                        value = endpoint.port.toString(),
                        onValueChange = { value ->
                            value.toIntOrNull()?.let { port -> onEndpoint { it.copy(port = port) } }
                        },
                        label = "Port",
                        keyboardType = KeyboardType.Number
                    )
                    if (config.protocol == ProxyProtocol.VLESS || config.protocol == ProxyProtocol.VMESS) {
                        Spacer(Modifier.height(8.dp))
                        NexusTextField(
                            value = endpoint.id,
                            onValueChange = { value -> onEndpoint { it.copy(id = value.trim()) } },
                            label = "UUID"
                        )
                    }
                    if (config.protocol == ProxyProtocol.TROJAN ||
                        config.protocol == ProxyProtocol.SHADOWSOCKS
                    ) {
                        Spacer(Modifier.height(8.dp))
                        NexusTextField(
                            value = endpoint.password,
                            onValueChange = { value -> onEndpoint { it.copy(password = value) } },
                            label = "Password"
                        )
                    }
                    if (config.protocol == ProxyProtocol.SHADOWSOCKS) {
                        Spacer(Modifier.height(8.dp))
                        NexusTextField(
                            value = endpoint.method,
                            onValueChange = { value -> onEndpoint { it.copy(method = value.trim()) } },
                            label = "Cipher"
                        )
                    }
                    if (config.protocol == ProxyProtocol.VLESS) {
                        Spacer(Modifier.height(8.dp))
                        NexusTextField(
                            value = endpoint.flow,
                            onValueChange = { value -> onEndpoint { it.copy(flow = value.trim()) } },
                            label = "Flow",
                            placeholder = "xtls-rprx-vision"
                        )
                    }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Transport & security")
                    ChoiceChips(
                        options = TransportNetwork.values().toList(),
                        selected = config.transport.network,
                        label = { it.name }
                    ) { network -> onTransport { it.copy(network = network) } }
                    Spacer(Modifier.height(8.dp))
                    NexusTextField(
                        value = config.transport.path,
                        onValueChange = { value -> onTransport { it.copy(path = value) } },
                        label = "Path / URL prefix"
                    )
                    Spacer(Modifier.height(8.dp))
                    NexusTextField(
                        value = config.transport.serviceName,
                        onValueChange = { value -> onTransport { it.copy(serviceName = value) } },
                        label = "gRPC service name"
                    )
                    Spacer(Modifier.height(8.dp))
                    ChoiceChips(
                        options = SecurityMode.values().toList(),
                        selected = config.security.mode,
                        label = { it.name }
                    ) { mode -> onSecurity { it.copy(mode = mode) } }
                    Spacer(Modifier.height(8.dp))
                    NexusTextField(
                        value = config.security.serverName.ifBlank { endpoint.sni },
                        onValueChange = { value -> onSecurity { it.copy(serverName = value.trim()) } },
                        label = "SNI / server name"
                    )
                    if (config.security.mode == SecurityMode.REALITY) {
                        Spacer(Modifier.height(8.dp))
                        NexusTextField(
                            value = endpoint.publicKey,
                            onValueChange = { value -> onEndpoint { it.copy(publicKey = value.trim()) } },
                            label = "REALITY public key"
                        )
                        Spacer(Modifier.height(8.dp))
                        NexusTextField(
                            value = endpoint.shortId,
                            onValueChange = { value -> onEndpoint { it.copy(shortId = value.trim()) } },
                            label = "REALITY short id"
                        )
                    }
                    SettingSwitchRow(
                        "Allow insecure TLS",
                        "Disables certificate verification — use only for debugging",
                        config.security.allowInsecure
                    ) { enabled -> onSecurity { it.copy(allowInsecure = enabled) } }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Native JSON", "Optional, engine must support it")
                    NexusTextField(
                        value = config.rawJson.orEmpty(),
                        onValueChange = onRawJson,
                        label = "Xray JSON",
                        singleLine = false
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onClearRawJson, enabled = !config.rawJson.isNullOrBlank()) {
                            Text("Remove JSON")
                        }
                        OutlinedButton(onClick = onResetOverrides) { Text("Reset overrides") }
                    }
                }
            }
        }

        item {
            NexusCard {
                Column(Modifier.padding(16.dp)) {
                    SectionHeader("Validation")
                    val report = state.report
                    if (report == null) {
                        Text(
                            "Run validation to check this profile against the selected engine.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        report.issues.take(10).forEach { issue ->
                            InfoBanner(
                                "${issue.severity.name}: ${issue.message}",
                                issue.severity,
                                Modifier.padding(vertical = 3.dp)
                            )
                        }
                        if (report.issues.isEmpty()) {
                            Text("No issues found.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (state.diff.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("Overrides applied:", style = MaterialTheme.typography.labelMedium)
                        state.diff.take(6).forEach { change ->
                            Text(
                                "${change.path}: ${change.before} → ${change.after}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = onValidate) { Text("Validate") }
                OutlinedButton(onClick = onSave, modifier = Modifier.weight(1f)) {
                    Text(if (state.isNew) "Create profile" else "Save")
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }
}
