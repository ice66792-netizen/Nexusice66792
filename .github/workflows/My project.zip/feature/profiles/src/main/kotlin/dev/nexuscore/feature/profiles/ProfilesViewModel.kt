package dev.nexuscore.feature.profiles

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dev.nexuscore.common.SecretRedactor
import dev.nexuscore.data.ProfileRepository
import dev.nexuscore.data.ShareLinkParser
import dev.nexuscore.data.SettingsRepository
import dev.nexuscore.engine.ConfigDiff
import dev.nexuscore.engine.EngineRegistry
import dev.nexuscore.model.ConfigOverrides
import dev.nexuscore.model.EffectiveConfig
import dev.nexuscore.model.EngineCapabilities
import dev.nexuscore.model.EngineState
import dev.nexuscore.model.ImportResult
import dev.nexuscore.model.NexusConfig
import dev.nexuscore.model.Profile
import dev.nexuscore.model.ValidationReport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ProfileEditorState(
    val draft: Profile? = null,
    val effective: EffectiveConfig? = null,
    val report: ValidationReport? = null,
    val diff: List<dev.nexuscore.engine.ConfigChange> = emptyList(),
    val capabilities: EngineCapabilities = EngineCapabilities(),
    val message: String? = null,
    val isNew: Boolean = false
)

class ProfilesViewModel(
    private val profiles: ProfileRepository,
    settings: SettingsRepository,
    private val engines: EngineRegistry,
    private val subscriptions: dev.nexuscore.data.SubscriptionRepository
) : ViewModel() {

    val list: StateFlow<List<Profile>> = profiles.profiles

    val subscriptionList: StateFlow<List<dev.nexuscore.model.Subscription>> = subscriptions.subscriptions

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun addSubscription(name: String, url: String) = viewModelScope.launch {
        if (!url.trim().startsWith("https://") && !url.contains("127.0.0.1")) {
            _message.value = "Only HTTPS subscription URLs are accepted"
            return@launch
        }
        val created = subscriptions.add(name, url)
        _message.value = "Fetching '${created.name}'…"
        refreshSubscription(created.id)
    }

    fun refreshSubscription(id: String) = viewModelScope.launch {
        subscriptions.prepareRefresh(id)
            .onSuccess { preview ->
                subscriptions.commit(preview)
                _message.value = "Updated: ${preview.changedFields.take(3).joinToString(", ")}"
            }
            .onFailure { _message.value = it.message ?: "Refresh failed" }
    }

    fun removeSubscription(id: String) = viewModelScope.launch {
        subscriptions.remove(id)
        _message.value = "Subscription removed"
    }

    fun dismissMessage() {
        _message.value = null
    }

    val activeId: StateFlow<String?> = settings.appSettings
        .let { flow -> combine(flow, profiles.profiles) { app, list -> app.activeProfileId ?: list.firstOrNull()?.id } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _editor = MutableStateFlow(ProfileEditorState())
    val editor: StateFlow<ProfileEditorState> = _editor.asStateFlow()

    private val _importText = MutableStateFlow("")
    val importText: StateFlow<String> = _importText.asStateFlow()

    fun onImportTextChange(value: String) {
        _importText.value = value
    }

    fun select(id: String) = viewModelScope.launch { profiles.setActive(id) }

    fun createNew() {
        val profile = profiles.newProfile("New profile")
        openEditor(profile)
    }

    fun openEditor(profile: Profile) {
        _editor.value = stateFor(profile, isNew = false)
    }

    fun closeEditor() {
        _editor.value = ProfileEditorState()
        _importText.value = ""
    }

    private fun stateFor(profile: Profile, isNew: Boolean): ProfileEditorState {
        val provider = engines.provider(profile.engineId)
        val effective = profiles.effective(profile)
        return ProfileEditorState(
            draft = profile,
            effective = effective,
            report = null,
            diff = ConfigDiff.diff(profile.config, effective.config),
            capabilities = provider?.capabilities() ?: EngineCapabilities(),
            isNew = isNew
        )
    }

    fun updateDraft(transform: (Profile) -> Profile) {
        val current = _editor.value
        val draft = current.draft ?: return
        val updated = transform(draft)
        _editor.value = current.copy(
            draft = updated,
            effective = profiles.effective(updated),
            diff = ConfigDiff.diff(updated.config, profiles.effective(updated).config)
        )
    }

    fun updateConfig(transform: (NexusConfig) -> NexusConfig) {
        updateDraft { it.copy(config = transform(it.config)) }
    }

    fun updateOverrides(transform: (ConfigOverrides) -> ConfigOverrides) {
        updateDraft { it.copy(overrides = transform(it.overrides)) }
    }

    fun resetOverrides() = updateDraft { it.copy(overrides = ConfigOverrides()) }

    fun validateDraft() {
        val draft = _editor.value.draft ?: return
        viewModelScope.launch {
            val report = engines.provider(draft.engineId)?.validate(profiles.effective(draft).config)
                ?: ValidationReport()
            _editor.value = _editor.value.copy(report = report)
        }
    }

    fun save() {
        val draft = _editor.value.draft ?: return
        viewModelScope.launch {
            val saved = profiles.upsert(draft)
            profiles.validate(saved)
            _editor.value = stateFor(saved, isNew = false).copy(message = "Profile saved")
            if (_editor.value.isNew) profiles.setActive(saved.id)
        }
    }

    fun duplicate(id: String) = viewModelScope.launch { profiles.duplicate(id) }

    fun delete(id: String) = viewModelScope.launch { profiles.delete(id) }

    fun importFromLink() {
        val text = _importText.value.trim()
        if (text.isEmpty()) {
            _editor.value = _editor.value.copy(message = "Paste a share link or JSON first")
            return
        }
        when (val result = ShareLinkParser.parse(text)) {
            is ImportResult.Success -> {
                val first = result.profiles.first()
                val profile = profiles.newProfile(first.name).copy(config = first.config)
                _editor.value = stateFor(profile, isNew = true)
                _importText.value = ""
            }

            is ImportResult.Failure -> _editor.value = _editor.value.copy(
                message = "Import failed: ${SecretRedactor.redact(result.message)}"
            )
        }
    }

    fun importJsonConfig(raw: String) {
        val draft = _editor.value.draft ?: return
        updateConfig { it.copy(rawJson = raw) }
        validateDraft()
    }

    fun clearRawJson() = updateConfig { it.copy(rawJson = null) }
}
