package dev.nexuscore.feature.dashboard

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.FileUpload
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import dev.nexuscore.design.Format
import dev.nexuscore.design.InfoBanner
import dev.nexuscore.design.LocalAnimationLevel
import dev.nexuscore.design.NexusCard
import dev.nexuscore.design.SectionHeader
import dev.nexuscore.design.StatusPill
import dev.nexuscore.model.AnimationLevel
import dev.nexuscore.model.DashboardBlock
import dev.nexuscore.model.EngineState
import dev.nexuscore.model.QuickAction
import dev.nexuscore.model.StatsFormat
import dev.nexuscore.model.ValidationSeverity

/**
 * Dashboard blocks are rendered in the order and visibility configured by the
 * user; every block has real data behind it, no placeholders.
 */
@Composable
fun DashboardScreen(
    state: DashboardUiState,
    onToggleConnection: () -> Unit,
    onOpenProfiles: () -> Unit,
    onOpenSettings: () -> Unit,
    onQuickAction: (QuickAction) -> Unit,
    modifier: Modifier = Modifier
) {
    val settings = state.dashboard
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard"),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = "Nexus Core",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = when (val s = state.state) {
                            is EngineState.Connected -> "Connected"
                            is EngineState.Connecting -> "Connecting…"
                            is EngineState.Preparing -> "Preparing engine…"
                            is EngineState.Disconnecting -> "Disconnecting…"
                            is EngineState.Failed -> "Error"
                            is EngineState.Unavailable -> "Engine unavailable"
                            EngineState.Idle -> "Disconnected"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onOpenProfiles) {
                    Icon(Icons.Outlined.Settings, contentDescription = "Profiles")
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Outlined.Settings, contentDescription = "Settings")
                }
            }
        }

        if (state.simulated) {
            item {
                InfoBanner(
                    text = "Simulation engine is active. Connections, traffic and latency shown here are " +
                        "generated locally and do not represent real network activity.",
                    severity = ValidationSeverity.WARNING
                )
            }
        }

        if (state.unavailableReasons.isNotEmpty() && state.state !is EngineState.Failed) {
            item {
                InfoBanner(
                    text = state.unavailableReasons.joinToString("\n"),
                    severity = ValidationSeverity.ERROR
                )
            }
        }

        state.dashboard.orderedBlocks().forEach { block ->
            item(key = "block_$block") {
            when (block) {
                DashboardBlock.STATUS -> ConnectionIndicator(state, onToggleConnection)

                DashboardBlock.PROFILE -> ProfileCard(state, onOpenProfiles)

                DashboardBlock.TRAFFIC -> TrafficCard(state)

                DashboardBlock.DURATION -> {
                    CardBlock(title = "Session") {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Timer, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = if (state.isConnected) {
                                    Format.duration(System.currentTimeMillis() - state.connectedSince)
                                } else {
                                    "00:00"
                                },
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                DashboardBlock.LATENCY -> {
                    CardBlock(title = "Latency") {
                        val latency = state.stats.latencyMs
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Speed, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = if (latency != null) {
                                    Format.latency(latency)
                                } else {
                                    "Not measured by this engine"
                                },
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }

                DashboardBlock.CORE -> {
                    CardBlock(title = "Core") {
                        val descriptor = state.descriptor
                        Text(
                            text = descriptor?.let { "${it.displayName} · ${it.version}" } ?: "No engine selected",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = descriptor?.buildInfo ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            val available = descriptor?.isAvailable == true
                            StatusPill(
                                text = if (available) "Available" else "Unavailable",
                                color = if (available) Color(0xFF2E9E5B) else MaterialTheme.colorScheme.error
                            )
                            StatusPill(
                                text = "${descriptor?.capabilities?.features?.size ?: 0} capabilities",
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                DashboardBlock.QUICK_ACTIONS -> {
                    CardBlock(title = "Quick access") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            settings.quickActions.forEach { action ->
                                OutlinedButton(
                                    onClick = { onQuickAction(action) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = action.name.lowercase().replaceFirstChar { it.uppercase() },
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "Blocks, order, density and colours are configurable in Personalization.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
        }
    }
}

@Composable
private fun ConnectionIndicator(state: DashboardUiState, onToggle: () -> Unit) {
    val level = LocalAnimationLevel.current
    val pulse = remember { androidx.compose.animation.core.Animatable(1f) }
    if (level == AnimationLevel.FULL && state.isConnected) {
        androidx.compose.runtime.LaunchedEffect(state.isConnected) {
            pulse.animateTo(
                targetValue = 1.08f,
                animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse)
            )
        }
    }

    val accent = when (val s = state.state) {
        is EngineState.Connected -> Color(0xFF2E9E5B)
        is EngineState.Failed -> MaterialTheme.colorScheme.error
        is EngineState.Connecting, is EngineState.Preparing -> Color(0xFFE0A020)
        else -> MaterialTheme.colorScheme.outline
    }

    NexusCard {
        Column(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(148.dp)
                    .scale(if (level == AnimationLevel.FULL) pulse.value else 1f)
                    .background(
                        Brush.radialGradient(
                            listOf(accent.copy(alpha = 0.28f), Color.Transparent)
                        ),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(96.dp)
                        .background(accent.copy(alpha = 0.16f), CircleShape)
                        .clickable(enabled = !state.isBusy) { onToggle() },
                    contentAlignment = Alignment.Center
                ) {
                    if (state.isBusy) {
                        CircularProgressIndicator(modifier = Modifier.size(36.dp), strokeWidth = 3.dp)
                    } else {
                        Icon(
                            imageVector = Icons.Outlined.Bolt,
                            contentDescription = if (state.isConnected) "Disconnect" else "Connect",
                            tint = accent,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onToggle,
                enabled = !state.isBusy,
                modifier = Modifier.fillMaxWidth().testTag("connect_button"),
                colors = ButtonDefaults.buttonColors(containerColor = accent)
            ) {
                Text(if (state.isConnected) "Disconnect" else "Connect")
            }
            if (state.state is EngineState.Failed) {
                Spacer(Modifier.height(8.dp))
                val failure = state.state as EngineState.Failed
                InfoBanner(
                    text = listOfNotNull(failure.message, failure.detail).joinToString("\n"),
                    severity = ValidationSeverity.ERROR
                )
            }
        }
    }
}

@Composable
private fun ProfileCard(state: DashboardUiState, onOpenProfiles: () -> Unit) {
    NexusCard(onClick = onOpenProfiles) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Active profile", style = MaterialTheme.typography.labelMedium)
                Text(
                    text = state.profile?.name ?: "No profile selected",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                state.profile?.let {
                    Text(
                        text = "${it.config.protocol.name} · ${it.config.endpoint.address}:" +
                            "${it.config.endpoint.port}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            TextButton(onClick = onOpenProfiles) { Text("Manage") }
        }
    }
}

@Composable
private fun TrafficCard(state: DashboardUiState) {
    val format = state.dashboard.statsFormat
    CardBlock(title = "Traffic") {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Metric(
                icon = { Icon(Icons.Outlined.FileUpload, null, tint = Color(0xFF3D7BFF)) },
                label = "Upload",
                value = Format.bytes(state.stats.uplinkBytes),
                secondary = if (state.dashboard.showRates) Format.rate(state.stats.uplinkRateBps, format) else null,
                modifier = Modifier.weight(1f)
            )
            Metric(
                icon = { Icon(Icons.Outlined.FileDownload, null, tint = Color(0xFF2E9E5B)) },
                label = "Download",
                value = Format.bytes(state.stats.downlinkBytes),
                secondary = if (state.dashboard.showRates) Format.rate(state.stats.downlinkRateBps, format) else null,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = "${state.stats.activeConnections} active connections",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (format == StatsFormat.ADAPTIVE) {
            Text(
                text = "Rates shown in bytes. Switch to bits in Personalization.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun Metric(
    icon: @Composable () -> Unit,
    label: String,
    value: String,
    secondary: String?,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            icon()
            Spacer(Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.labelMedium)
        }
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        if (secondary != null) {
            Text(
                text = secondary,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun CardBlock(title: String, content: @Composable () -> Unit) {
    NexusCard {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            SectionHeader(title)
            content()
        }
    }
}
