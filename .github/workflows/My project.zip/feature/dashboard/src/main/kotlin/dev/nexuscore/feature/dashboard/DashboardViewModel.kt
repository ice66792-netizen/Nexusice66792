package dev.nexuscore.feature.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dev.nexuscore.data.ProfileRepository
import dev.nexuscore.data.SettingsRepository
import dev.nexuscore.engine.EngineRegistry
import dev.nexuscore.engine.VpnControl
import dev.nexuscore.model.DashboardSettings
import dev.nexuscore.model.EngineDescriptor
import dev.nexuscore.model.EngineState
import dev.nexuscore.model.EngineStats
import dev.nexuscore.model.Profile
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn

data class DashboardUiState(
    val profile: Profile? = null,
    val descriptor: EngineDescriptor? = null,
    val state: EngineState = EngineState.Idle,
    val stats: EngineStats = EngineStats(),
    val dashboard: DashboardSettings = DashboardSettings(),
    val expertMode: Boolean = false
) {
    val isBusy: Boolean
        get() = state is EngineState.Connecting || state is EngineState.Preparing ||
            state is EngineState.Disconnecting

    val isConnected: Boolean get() = state is EngineState.Connected

    val connectedSince: Long
        get() = (state as? EngineState.Connected)?.sinceEpochMillis ?: 0L

    val simulated: Boolean get() = descriptor?.isSimulated == true

    val unavailableReasons: List<String>
        get() = when (val s = state) {
            is EngineState.Unavailable -> s.reasons
            is EngineState.Failed -> listOfNotNull(s.message, s.detail)
            else -> (descriptor?.availability as? dev.nexuscore.model.EngineAvailability.Unavailable)?.reasons.orEmpty()
        }
}

class DashboardViewModel(
    settings: SettingsRepository,
    profiles: ProfileRepository,
    engines: EngineRegistry,
    private val control: VpnControl
) : ViewModel() {

    private val preferences = combine(settings.appSettings, settings.dashboardSettings) { app, dashboard ->
        app to dashboard
    }

    private val descriptorFlow = engines.selected.flatMapLatest { id ->
        flowOf(engines.provider(id)?.descriptor())
    }

    val state: StateFlow<DashboardUiState> = combine(
        preferences,
        profiles.profiles,
        descriptorFlow,
        control.state,
        control.stats
    ) { (app, dashboard), profileList, descriptor, engineState, stats ->
        val active = profileList.firstOrNull { it.id == app.activeProfileId } ?: profileList.firstOrNull()
        DashboardUiState(
            profile = active,
            descriptor = descriptor,
            state = engineState,
            stats = stats,
            dashboard = dashboard,
            expertMode = app.expertMode
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardUiState())

    fun toggleConnection() {
        when (val current = state.value.state) {
            is EngineState.Connected,
            is EngineState.Connecting,
            is EngineState.Preparing,
            is EngineState.Disconnecting -> control.requestDisconnect()

            else -> control.requestConnect()
        }
    }
}
