package dev.nexuscore.design

import dev.nexuscore.model.StatsFormat
import java.util.Locale

object Format {

    fun bytes(value: Long): String {
        if (value < 1024) return "$value B"
        val units = listOf("KiB", "MiB", "GiB", "TiB")
        var size = value.toDouble() / 1024
        var index = 0
        while (size >= 1024 && index < units.lastIndex) {
            size /= 1024
            index++
        }
        return String.format(Locale.US, "%.1f %s", size, units[index])
    }

    fun rate(bytesPerSecond: Long, format: StatsFormat = StatsFormat.ADAPTIVE): String {
        if (format == StatsFormat.BITS) {
            val bits = bytesPerSecond * 8
            return when {
                bits >= 1_000_000_000 -> String.format(Locale.US, "%.2f Gbit/s", bits / 1_000_000_000.0)
                bits >= 1_000_000 -> String.format(Locale.US, "%.1f Mbit/s", bits / 1_000_000.0)
                bits >= 1_000 -> String.format(Locale.US, "%.0f kbit/s", bits / 1_000.0)
                else -> "$bits bit/s"
            }
        }
        return "${bytes(bytesPerSecond)}/s"
    }

    fun duration(millis: Long): String {
        if (millis <= 0) return "00:00"
        val totalSeconds = millis / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun latency(ms: Long?): String = ms?.let { "$it ms" } ?: "—"

    fun timeAgo(epochMillis: Long, now: Long = System.currentTimeMillis()): String {
        if (epochMillis <= 0L) return "never"
        val delta = (now - epochMillis).coerceAtLeast(0)
        val minutes = delta / 60_000
        return when {
            minutes < 1 -> "just now"
            minutes < 60 -> "${minutes}m ago"
            minutes < 1440 -> "${minutes / 60}h ago"
            else -> "${minutes / 1440}d ago"
        }
    }
}
