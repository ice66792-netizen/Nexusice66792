package dev.nexuscore.design

import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory

/**
 * Thin wrapper around `viewModel(factory = ...)` so feature screens do not
 * repeat three lines of boilerplate each.
 */
@Composable
inline fun <reified T : ViewModel> nexusViewModel(crossinline create: () -> T): T =
    viewModel<T>(
        factory = viewModelFactory {
            initializer { create() }
        }
    )
