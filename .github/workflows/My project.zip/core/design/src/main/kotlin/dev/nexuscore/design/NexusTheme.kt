package dev.nexuscore.design

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import dev.nexuscore.model.AnimationLevel
import dev.nexuscore.model.ThemeMode
import dev.nexuscore.model.ThemePresets
import dev.nexuscore.model.ThemeSettings

val LocalNexusTheme = staticCompositionLocalOf { ThemeSettings() }

val LocalAnimationLevel = staticCompositionLocalOf { AnimationLevel.FULL }

/**
 * Maps the fully user-defined [ThemeSettings] onto a Material 3 scheme.
 *
 * Colours that the user did not override fall back to the selected preset, so
 * the app is never left with an unreadable combination.
 */
@Composable
fun NexusTheme(
    theme: ThemeSettings,
    content: @Composable () -> Unit
) {
    val dark = when (theme.mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val preset = ThemePresets.byId(theme.presetId)
    val accent = Color(theme.accentColor)
    val background = Color(theme.backgroundColor ?: if (dark) preset.backgroundDark else preset.backgroundLight)
    val surface = Color(theme.surfaceColor ?: if (dark) preset.surfaceDark else preset.surfaceLight)

    val scheme = buildScheme(dark, accent, background, surface, theme.contrast)
    val corner = theme.cornerRadiusDp
    val shapes = Shapes(
        extraSmall = RoundedCornerShape((corner * 0.35f).dp),
        small = RoundedCornerShape((corner * 0.6f).dp),
        medium = RoundedCornerShape((corner * 0.8f).dp),
        large = RoundedCornerShape(corner.dp),
        extraLarge = RoundedCornerShape((corner * 1.3f).dp)
    )

    val density = LocalDensity.current
    val adjustedDensity = Density(
        density = density.density * theme.densityScale,
        fontScale = density.fontScale * theme.fontScale
    )

    CompositionLocalProvider(
        LocalNexusTheme provides theme,
        LocalAnimationLevel provides theme.animationLevel,
        LocalDensity provides adjustedDensity
    ) {
        MaterialTheme(
            colorScheme = scheme,
            typography = Typography().scaled(theme.fontScale),
            shapes = shapes,
            content = content
        )
    }
}

private fun buildScheme(
    dark: Boolean,
    primary: Color,
    background: Color,
    surface: Color,
    contrast: Float
): ColorScheme {
    val base = if (dark) darkColorScheme() else lightColorScheme()
    val onBackground = if (dark) Color(0xFFE8ECF3) else Color(0xFF14181F)
    val forcedContrast = contrast.coerceIn(0f, 1f)

    return base.copy(
        primary = primary,
        onPrimary = readableOn(primary),
        primaryContainer = lerp(primary, background, if (dark) 0.72f else 0.86f),
        onPrimaryContainer = if (dark) Color(0xFFDDE6FF) else Color(0xFF0A2A66),
        secondary = lerp(primary, onBackground, 0.25f),
        onSecondary = readableOn(lerp(primary, onBackground, 0.25f)),
        secondaryContainer = lerp(primary, surface, 0.8f),
        onSecondaryContainer = onBackground,
        tertiary = lerp(primary, Color(0xFFFFB020), 0.35f),
        background = background,
        onBackground = onBackground,
        surface = surface,
        onSurface = onBackground,
        surfaceVariant = lerp(surface, onBackground, 0.08f),
        onSurfaceVariant = lerp(onBackground, surface, 0.32f - forcedContrast * 0.1f),
        outline = lerp(onBackground, surface, 0.55f - forcedContrast * 0.2f),
        outlineVariant = lerp(onBackground, surface, 0.78f),
        error = Color(0xFFE5484D),
        onError = Color.White,
        errorContainer = lerp(Color(0xFFE5484D), background, 0.78f),
        onErrorContainer = if (dark) Color(0xFFFFDAD6) else Color(0xFF410002)
    )
}

fun readableOn(color: Color): Color =
    if (color.luminance() > 0.55f) Color(0xFF0B0F17) else Color.White

private fun TextStyle.scaled(factor: Float): TextStyle =
    if (factor == 1f) this else copy(fontSize = fontSize * factor, lineHeight = lineHeight * factor)

private fun Typography.scaled(factor: Float): Typography = copy(
    displayLarge = displayLarge.scaled(factor),
    displayMedium = displayMedium.scaled(factor),
    displaySmall = displaySmall.scaled(factor),
    headlineLarge = headlineLarge.scaled(factor),
    headlineMedium = headlineMedium.scaled(factor),
    headlineSmall = headlineSmall.scaled(factor),
    titleLarge = titleLarge.scaled(factor),
    titleMedium = titleMedium.scaled(factor),
    titleSmall = titleSmall.scaled(factor),
    bodyLarge = bodyLarge.scaled(factor),
    bodyMedium = bodyMedium.scaled(factor),
    bodySmall = bodySmall.scaled(factor),
    labelLarge = labelLarge.scaled(factor),
    labelMedium = labelMedium.scaled(factor),
    labelSmall = labelSmall.scaled(factor)
)
