package dev.nexuscore.common

/**
 * Best-effort, deterministic redaction for anything that leaves the app
 * (diagnostics, logs, crash notes).
 */
object SecretRedactor {

    private val uuid = Regex(
        "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
    )
    private val longHex = Regex("[0-9a-fA-F]{32,}")
    private val kvSecret = Regex(
        "(?i)(password|passwd|secret|token|api[_-]?key|private[_-]?key|preshared[_-]?key|psk)\\s*[=:]\\s*\"?[^\\s\"&,}]+\"?"
    )
    private val urlCredentials = Regex("(?i)\\b([a-z][a-z0-9+.-]*://)[^\\s/@:]+:[^\\s/@]+@")
    private val jwt = Regex("eyJ[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{5,}")

    fun redact(input: String): String {
        if (input.isEmpty()) return input
        var out = input
        out = jwt.replace(out, "<jwt>")
        out = uuid.replace(out, "<uuid>")
        out = longHex.replace(out, "<hex>")
        out = urlCredentials.replace(out, "$1<credentials>@")
        out = kvSecret.replace(out) { m ->
            val key = m.value.substringBefore('=').substringBefore(':').trim()
            "$key=<redacted>"
        }
        return out
    }

    /** Removes embedded credentials from a URL that is displayed in the UI. */
    fun sanitizeUrl(url: String): String {
        val at = url.indexOf('@')
        val schemeEnd = url.indexOf("://")
        if (at <= 0 || schemeEnd < 0 || at < schemeEnd) return url
        return url.substring(0, schemeEnd + 3) + "<hidden>@" + url.substring(at + 1)
    }
}
