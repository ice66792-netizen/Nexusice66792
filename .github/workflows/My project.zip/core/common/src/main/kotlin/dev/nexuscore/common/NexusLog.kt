package dev.nexuscore.common

import java.util.ArrayDeque
import java.util.Locale

/**
 * In-memory ring buffer used by the diagnostics screen.
 *
 * Secrets never reach the buffer: every message goes through [SecretRedactor]
 * before it is stored, and also before the platform log call.
 */
object NexusLog {

    private const val MAX_LINES = 800
    private const val TAG = "NexusCore"

    private val buffer = ArrayDeque<String>()
    private val lock = Any()

    var minLevel: Int = 2 // 0=debug 1=info 2=warn 3=error
        @Synchronized set

    fun d(tag: String, message: String) = append(0, "D", tag, message)

    fun i(tag: String, message: String) = append(1, "I", tag, message)

    fun w(tag: String, message: String) = append(2, "W", tag, message)

    fun e(tag: String, message: String, throwable: Throwable? = null) {
        val detail = throwable?.let { ": ${it.javaClass.simpleName}: ${it.message}" } ?: ""
        append(3, "E", tag, message + detail)
    }

    private fun append(level: Int, letter: String, tag: String, message: String) {
        if (level < minLevel) return
        val safe = SecretRedactor.redact(message)
        val line = "%tT %s/%-14s %s".format(Locale.US, System.currentTimeMillis(), letter, tag, safe)
        synchronized(lock) {
            buffer.addLast(line)
            while (buffer.size > MAX_LINES) buffer.removeFirst()
        }
        when (letter) {
            "E" -> android.util.Log.e(TAG, "[$tag] $safe")
            "W" -> android.util.Log.w(TAG, "[$tag] $safe")
            "I" -> android.util.Log.i(TAG, "[$tag] $safe")
            else -> android.util.Log.d(TAG, "[$tag] $safe")
        }
    }

    fun snapshot(): List<String> = synchronized(lock) { buffer.toList() }

    fun clear() = synchronized(lock) { buffer.clear() }
}
