package dev.nexuscore.model

import kotlinx.serialization.Serializable

/** Identifiers of engines that can be plugged into the app. */
enum class EngineId(val key: String) {
    XRAY("xray"),
    MOCK("mock");

    companion object {
        fun fromKey(key: String): EngineId = values().firstOrNull { it.key == key } ?: XRAY
    }
}

/**
 * Protocols the data model can express.
 *
 * Whether a protocol can actually be used is decided by [EngineCapabilities]
 * of the selected engine - never by the presence of a field in the model.
 */
enum class ProxyProtocol(val scheme: String) {
    VLESS("vless"),
    VMESS("vmess"),
    TROJAN("trojan"),
    SHADOWSOCKS("ss"),
    SOCKS("socks"),
    WIREGUARD("wireguard"),
    HYSTERIA2("hysteria2");

    companion object {
        fun fromScheme(scheme: String): ProxyProtocol? =
            values().firstOrNull { it.scheme.equals(scheme, ignoreCase = true) }
    }
}

/** Fine grained, explicitly declared engine features. */
enum class EngineFeature {
    VLESS_REALITY,
    VMESS,
    TROJAN,
    SHADOWSOCKS,
    SOCKS,
    WIREGUARD,
    HYSTERIA2,
    TLS,
    REALITY,
    TLS_FRAGMENTATION,
    MUX,
    FULL_JSON_IMPORT,
    DOMAIN_ROUTING,
    IP_ROUTING,
    PORT_ROUTING,
    APP_ROUTING,
    PROCESS_ROUTING,
    DNS_OVERRIDE,
    DNS_RULES,
    TUN_MTU,
    TRAFFIC_STATS,
    LATENCY_PROBE,
    LOG_LEVEL_CONTROL,
    REMOTE_DNS_RESOLUTION
}

data class EngineCapabilities(
    val features: Set<EngineFeature> = emptySet(),
    val protocols: Set<ProxyProtocol> = emptySet(),
    val maxLogLevel: String = "warning",
    val notes: List<String> = emptyList()
) {
    fun supports(feature: EngineFeature): Boolean = feature in features

    fun supports(protocol: ProxyProtocol): Boolean = protocol in protocols
}

sealed interface EngineAvailability {
    data object Available : EngineAvailability

    /** The engine cannot run on this build; [reasons] are shown verbatim in the UI. */
    data class Unavailable(val reasons: List<String>) : EngineAvailability
}

data class EngineDescriptor(
    val id: EngineId,
    val displayName: String,
    val version: String,
    val buildInfo: String,
    /** True for the explicit simulation engine used by tests / demo mode. */
    val isSimulated: Boolean,
    val availability: EngineAvailability,
    val capabilities: EngineCapabilities
) {
    val isAvailable: Boolean get() = availability is EngineAvailability.Available
}

sealed interface EngineState {
    data object Idle : EngineState
    data object Preparing : EngineState
    data class Connecting(val attempt: Int = 1) : EngineState
    data class Connected(val sinceEpochMillis: Long) : EngineState
    data object Disconnecting : EngineState
    data class Failed(
        val message: String,
        val detail: String? = null,
        val recoverable: Boolean = true
    ) : EngineState

    data class Unavailable(val reasons: List<String>) : EngineState
}

data class EngineStats(
    val uplinkBytes: Long = 0L,
    val downlinkBytes: Long = 0L,
    val uplinkRateBps: Long = 0L,
    val downlinkRateBps: Long = 0L,
    val activeConnections: Int = 0,
    val latencyMs: Long? = null,
    val sampledAtEpochMillis: Long = 0L
)

enum class ValidationSeverity { INFO, WARNING, ERROR }

@Serializable
data class ValidationIssue(
    val code: String,
    val message: String,
    val severity: ValidationSeverity,
    val path: String? = null
)

data class ValidationReport(
    val issues: List<ValidationIssue> = emptyList()
) {
    val errors: List<ValidationIssue> get() = issues.filter { it.severity == ValidationSeverity.ERROR }
    val warnings: List<ValidationIssue> get() = issues.filter { it.severity == ValidationSeverity.WARNING }
    val isValid: Boolean get() = errors.isEmpty()

    fun preview(): String = issues.firstOrNull()?.message ?: ""
}

data class EngineDiagnostics(
    val engineId: EngineId,
    val engineVersion: String,
    val state: EngineState,
    val lastError: String?,
    val logTail: List<String>,
    val extra: Map<String, String> = emptyMap()
)

/** Description of a running engine session, handed over by the VPN service. */
data class EngineSessionRequest(
    val config: NexusConfig,
    val tunFileDescriptor: Int,
    val dnsServers: List<String>,
    val socksPort: Int
)

data class CapabilitySummary(
    val total: Int,
    val supported: Int
) {
    val unsupported: Int get() = total - supported
}
