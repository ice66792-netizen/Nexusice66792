package dev.nexuscore.model

import kotlinx.serialization.Serializable

@Serializable
enum class ThemeMode { SYSTEM, LIGHT, DARK }

@Serializable
enum class CardStyle { ELEVATED, OUTLINED, FLAT }

@Serializable
enum class AnimationLevel { FULL, REDUCED, OFF }

@Serializable
enum class IconPack { OUTLINED, FILLED, MINIMAL }

@Serializable
enum class IndicatorStyle { PULSE, RING, MINIMAL, WAVE }

@Serializable
enum class StatsFormat { BYTES, BITS, ADAPTIVE }

@Serializable
enum class DashboardBlock {
    STATUS,
    PROFILE,
    TRAFFIC,
    DURATION,
    LATENCY,
    CORE,
    QUICK_ACTIONS
}

@Serializable
enum class QuickAction { CONNECT, PROFILES, ROUTING, DNS, DIAGNOSTICS, BACKUP }

/**
 * Every visual decision is data, persisted as JSON. Colour values are ARGB longs.
 */
@Serializable
data class ThemeSettings(
    val mode: ThemeMode = ThemeMode.SYSTEM,
    val presetId: String = "nexus_default",
    val accentColor: Long = 0xFF3D7BFF,
    val backgroundColor: Long? = null,
    val surfaceColor: Long? = null,
    val contrast: Float = 0.0f,
    val cornerRadiusDp: Int = 20,
    val densityScale: Float = 1.0f,
    val fontScale: Float = 1.0f,
    val cardStyle: CardStyle = CardStyle.ELEVATED,
    val animationLevel: AnimationLevel = AnimationLevel.FULL,
    val iconPack: IconPack = IconPack.OUTLINED,
    val indicatorStyle: IndicatorStyle = IndicatorStyle.PULSE,
    val overlayAlpha: Float = 1.0f
)

@Serializable
data class ThemeScheme(
    val id: String,
    val name: String,
    val builtIn: Boolean = false,
    val settings: ThemeSettings = ThemeSettings()
)

@Serializable
data class ThemeState(
    val active: ThemeSettings = ThemeSettings(),
    val activeSchemeId: String = "nexus_default",
    val savedSchemes: List<ThemeScheme> = emptyList()
)

@Serializable
data class DashboardSettings(
    val visibleBlocks: List<DashboardBlock> = listOf(
        DashboardBlock.STATUS,
        DashboardBlock.PROFILE,
        DashboardBlock.TRAFFIC,
        DashboardBlock.DURATION,
        DashboardBlock.LATENCY,
        DashboardBlock.CORE
    ),
    val blockOrder: List<DashboardBlock> = DashboardBlock.values().toList(),
    val statsFormat: StatsFormat = StatsFormat.ADAPTIVE,
    val compact: Boolean = false,
    val showRates: Boolean = true,
    val quickActions: List<QuickAction> = listOf(
        QuickAction.PROFILES,
        QuickAction.ROUTING,
        QuickAction.DNS,
        QuickAction.DIAGNOSTICS
    ),
    val refreshIntervalMs: Long = 1_000L
) {
    fun orderedBlocks(): List<DashboardBlock> {
        val known = blockOrder.filter { it in visibleBlocks }
        return known + visibleBlocks.filter { it !in known }
    }
}

@Serializable
data class AppSettings(
    val expertMode: Boolean = false,
    val demoEngineEnabled: Boolean = false,
    val selectedEngine: EngineId = EngineId.XRAY,
    val activeProfileId: String? = null,
    val autoReconnect: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val redactDiagnostics: Boolean = true,
    val logLevel: LogLevel = LogLevel.WARNING,
    val onboardingCompleted: Boolean = false,
    val lastBackupAtEpochMillis: Long = 0L
)

/** Built-in presets. Their ids are stable and referenced by saved schemes. */
data class ThemePreset(
    val id: String,
    val name: String,
    val accent: Long,
    val backgroundLight: Long,
    val backgroundDark: Long,
    val surfaceLight: Long,
    val surfaceDark: Long
)

object ThemePresets {
    val all: List<ThemePreset> = listOf(
        ThemePreset(
            id = "nexus_default",
            name = "Nexus Blue",
            accent = 0xFF3D7BFF,
            backgroundLight = 0xFFF7F8FC,
            backgroundDark = 0xFF0B0F17,
            surfaceLight = 0xFFFFFFFF,
            surfaceDark = 0xFF141A26
        ),
        ThemePreset(
            id = "midnight_violet",
            name = "Midnight Violet",
            accent = 0xFF9B6BFF,
            backgroundLight = 0xFFF8F5FF,
            backgroundDark = 0xFF100B1A,
            surfaceLight = 0xFFFFFFFF,
            surfaceDark = 0xFF1B1428
        ),
        ThemePreset(
            id = "graphite",
            name = "Graphite",
            accent = 0xFF8A94A6,
            backgroundLight = 0xFFF4F5F7,
            backgroundDark = 0xFF101214,
            surfaceLight = 0xFFFFFFFF,
            surfaceDark = 0xFF1A1D21
        ),
        ThemePreset(
            id = "teal_flow",
            name = "Teal Flow",
            accent = 0xFF00A99D,
            backgroundLight = 0xFFF2FAF9,
            backgroundDark = 0xFF07110F,
            surfaceLight = 0xFFFFFFFF,
            surfaceDark = 0xFF11201D
        ),
        ThemePreset(
            id = "sunset_amber",
            name = "Sunset Amber",
            accent = 0xFFF08A24,
            backgroundLight = 0xFFFFF9F2,
            backgroundDark = 0xFF150F08,
            surfaceLight = 0xFFFFFFFF,
            surfaceDark = 0xFF241A10
        ),
        ThemePreset(
            id = "mono_paper",
            name = "Mono Paper",
            accent = 0xFF2F3A45,
            backgroundLight = 0xFFFBFBF9,
            backgroundDark = 0xFF0E0E0F,
            surfaceLight = 0xFFFFFFFF,
            surfaceDark = 0xFF18181A
        )
    )

    fun byId(id: String): ThemePreset = all.firstOrNull { it.id == id } ?: all.first()
}
