package dev.nexuscore.model

import kotlinx.serialization.Serializable

@Serializable
enum class BackupPart { SETTINGS, THEME, DASHBOARD, PROFILES, SUBSCRIPTIONS, THEME_SCHEMES }

/**
 * Versioned, human readable backup container.
 *
 * Migration is strictly additive: [BackupMigrator] upgrades older envelopes
 * and never guesses fields that are absent.
 */
@Serializable
data class BackupEnvelope(
    val format: String = FORMAT,
    val formatVersion: Int = CURRENT_VERSION,
    val appVersion: String = "",
    val createdAtEpochMillis: Long = 0L,
    val includesSecrets: Boolean = false,
    val settings: AppSettings? = null,
    val theme: ThemeSettings? = null,
    val dashboard: DashboardSettings? = null,
    val profiles: List<Profile> = emptyList(),
    val subscriptions: List<Subscription> = emptyList(),
    val schemes: List<ThemeScheme> = emptyList()
) {
    companion object {
        const val FORMAT = "nexuscore.backup"
        const val CURRENT_VERSION = 2

        /** Oldest format this build can still read. */
        const val MIN_SUPPORTED_VERSION = 1
    }
}

sealed interface BackupParseResult {
    data class Success(
        val envelope: BackupEnvelope,
        val appliedMigrations: List<Int>
    ) : BackupParseResult

    data class Failure(val reason: String) : BackupParseResult
}
