package dev.nexuscore.model

import kotlinx.serialization.Serializable

@Serializable
enum class TransportNetwork { TCP, WS, GRPC, HTTP2, XHTTP, KCP, QUIC }

@Serializable
enum class SecurityMode { NONE, TLS, REALITY }

@Serializable
enum class DnsMode { SYSTEM, UDP, DNS_OVER_TLS, DNS_OVER_HTTPS }

@Serializable
enum class QueryStrategy { USE_IP, USE_IPV4, USE_IPV6, USE_IPV4V6 }

@Serializable
enum class DomainStrategy { AS_IS, IP_IF_NON_MATCH, IP_ON_DEMAND }

@Serializable
enum class RuleKind {
    DOMAIN,
    DOMAIN_SUFFIX,
    DOMAIN_KEYWORD,
    DOMAIN_REGEX,
    IP_CIDR,
    PORT,
    NETWORK,
    PROTOCOL,
    APP
}

@Serializable
enum class RuleAction { PROXY, DIRECT, BLOCK }

@Serializable
enum class LogLevel { NONE, ERROR, WARNING, INFO, DEBUG }

@Serializable
data class ServerEndpoint(
    val address: String = "",
    val port: Int = 443,
    val id: String = "",
    val password: String = "",
    val method: String = "aes-256-gcm",
    val sni: String = "",
    val flow: String = "",
    val fingerprint: String = "chrome",
    val publicKey: String = "",
    val shortId: String = "",
    val spiderX: String = "/",
    val wireGuardPrivateKey: String = "",
    val wireGuardPeerPublicKey: String = "",
    val preSharedKey: String = ""
)

@Serializable
data class TransportOptions(
    val network: TransportNetwork = TransportNetwork.TCP,
    val path: String = "/",
    val host: String = "",
    val serviceName: String = "",
    val earlyDataHeaderName: String = "",
    val headerType: String = "none"
)

@Serializable
data class SecurityOptions(
    val mode: SecurityMode = SecurityMode.TLS,
    val serverName: String = "",
    val alpn: List<String> = emptyList(),
    val fingerprint: String = "chrome",
    val publicKey: String = "",
    val shortId: String = "",
    val allowInsecure: Boolean = false,
    val tlsFragmentEnabled: Boolean = false,
    val tlsFragmentLength: String = "100-200",
    val tlsFragmentIntervalMs: Int = 10
)

@Serializable
data class MuxOptions(
    val enabled: Boolean = false,
    val concurrency: Int = 8,
    val xudpConcurrency: Int = 8
)

@Serializable
data class ReconnectPolicy(
    val maxAttempts: Int = 3,
    val initialDelayMs: Long = 1_000L,
    val backoffMultiplier: Double = 2.0,
    val maxDelayMs: Long = 30_000L,
    val jitter: Boolean = true
)

@Serializable
data class NetworkOptions(
    val connectTimeoutMs: Int = 8_000,
    val handshakeTimeoutMs: Int = 8_000,
    val ipv4Enabled: Boolean = true,
    val ipv6Enabled: Boolean = true,
    val tcpFastOpen: Boolean = false,
    val mtu: Int = 1500,
    val socksPort: Int = 10808,
    val allowLan: Boolean = false,
    val reconnect: ReconnectPolicy = ReconnectPolicy(),
    val requireNetwork: Boolean = true
)

@Serializable
data class DnsOptions(
    val mode: DnsMode = DnsMode.SYSTEM,
    val servers: List<String> = emptyList(),
    val fallbackServers: List<String> = emptyList(),
    val queryStrategy: QueryStrategy = QueryStrategy.USE_IP,
    val disableCache: Boolean = false,
    val hosts: Map<String, String> = emptyMap(),
    val tag: String = "dns-in"
)

@Serializable
data class RoutingRule(
    val id: String,
    val kind: RuleKind,
    val value: String,
    val action: RuleAction,
    val enabled: Boolean = true,
    val note: String = ""
)

@Serializable
data class RoutingOptions(
    val domainStrategy: DomainStrategy = DomainStrategy.AS_IS,
    val rules: List<RoutingRule> = emptyList(),
    val bypassPrivateNetworks: Boolean = true
)

@Serializable
data class PerformanceOptions(
    val statsRefreshIntervalMs: Long = 1_000L,
    val latencyProbeUrl: String = "https://www.gstatic.com/generate_204",
    val latencyProbeIntervalSec: Int = 0,
    val logLevel: LogLevel = LogLevel.WARNING,
    val logBufferLines: Int = 500,
    val backgroundTrafficUpdates: Boolean = true
)

/**
 * Engine independent description of a connection.
 *
 * [rawJson] holds an imported engine-native configuration. It is validated and
 * previewed, but only used when the selected engine advertises
 * [EngineFeature.FULL_JSON_IMPORT].
 */
@Serializable
data class NexusConfig(
    val schemaVersion: Int = CURRENT_SCHEMA_VERSION,
    val protocol: ProxyProtocol = ProxyProtocol.VLESS,
    val endpoint: ServerEndpoint = ServerEndpoint(),
    val transport: TransportOptions = TransportOptions(),
    val security: SecurityOptions = SecurityOptions(),
    val mux: MuxOptions = MuxOptions(),
    val network: NetworkOptions = NetworkOptions(),
    val dns: DnsOptions = DnsOptions(),
    val routing: RoutingOptions = RoutingOptions(),
    val performance: PerformanceOptions = PerformanceOptions(),
    val rawJson: String? = null
) {
    companion object {
        const val CURRENT_SCHEMA_VERSION: Int = 1
    }
}

/** Sparse, user owned overrides. `null` means "inherit from the profile". */
@Serializable
data class ConfigOverrides(
    val transport: TransportOptions? = null,
    val security: SecurityOptions? = null,
    val mux: MuxOptions? = null,
    val network: NetworkOptions? = null,
    val dns: DnsOptions? = null,
    val routing: RoutingOptions? = null,
    val performance: PerformanceOptions? = null
) {
    val isEmpty: Boolean
        get() = transport == null && security == null && mux == null &&
            network == null && dns == null && routing == null && performance == null
}

/** Effective configuration plus the layer that produced it (for the diff view). */
data class EffectiveConfig(
    val config: NexusConfig,
    val appliedOverrides: ConfigOverrides,
    val usedRawJson: Boolean
)
