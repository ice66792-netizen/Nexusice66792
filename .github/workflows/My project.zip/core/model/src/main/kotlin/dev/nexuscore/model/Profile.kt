package dev.nexuscore.model

import kotlinx.serialization.Serializable

@Serializable
enum class ProfileSource { MANUAL, SHARE_LINK, IMPORTED_JSON, SUBSCRIPTION }

@Serializable
enum class ValidationStatus { UNKNOWN, VALID, WARNING, INVALID }

@Serializable
data class StoredValidation(
    val status: ValidationStatus = ValidationStatus.UNKNOWN,
    val message: String = "",
    val checkedAtEpochMillis: Long = 0L,
    val errorCodes: List<String> = emptyList()
)

@Serializable
data class Profile(
    val id: String,
    val name: String,
    val description: String = "",
    val engineId: EngineId = EngineId.XRAY,
    val source: ProfileSource = ProfileSource.MANUAL,
    val sourceUrl: String = "",
    val config: NexusConfig = NexusConfig(),
    val overrides: ConfigOverrides = ConfigOverrides(),
    val validation: StoredValidation = StoredValidation(),
    val tags: List<String> = emptyList(),
    val subscriptionId: String? = null,
    val createdAtEpochMillis: Long = 0L,
    val updatedAtEpochMillis: Long = 0L
) {
    val hasOverrides: Boolean get() = !overrides.isEmpty
}

@Serializable
data class Subscription(
    val id: String,
    val name: String,
    val url: String,
    val profileId: String? = null,
    val autoUpdate: Boolean = true,
    val intervalHours: Int = 12,
    val lastFetchedAtEpochMillis: Long = 0L,
    val lastError: String? = null,
    val etag: String? = null,
    val hideUrlFromUi: Boolean = false
)

/** Result of parsing an external configuration source. */
sealed interface ImportResult {
    data class Success(
        val profiles: List<Profile>,
        val warnings: List<String> = emptyList()
    ) : ImportResult

    data class Failure(val message: String) : ImportResult
}

/** Result of a subscription refresh, including a preview of what would change. */
data class SubscriptionRefresh(
    val subscriptionId: String,
    val profile: Profile,
    val changedFields: List<String>,
    val warnings: List<String>
)
