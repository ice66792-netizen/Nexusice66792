package dev.nexuscore.data

import dev.nexuscore.model.ImportResult
import dev.nexuscore.model.ProxyProtocol
import dev.nexuscore.model.SecurityMode
import dev.nexuscore.model.TransportNetwork
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ShareLinkParserTest {

    @Test
    fun `parses vless reality link`() {
        val link = "vless://11111111-2222-3333-4444-555555555555@example.com:443" +
            "?encryption=none&security=reality&sni=cdn.example.com&fp=chrome" +
            "&pbk=PUBKEY&sid=ab12&type=grpc&serviceName=grpcsvc#My%20Node"

        val result = ShareLinkParser.parse(link)
        assertTrue(result is ImportResult.Success)
        val profile = (result as ImportResult.Success).profiles.single()

        assertEquals(ProxyProtocol.VLESS, profile.config.protocol)
        assertEquals("example.com", profile.config.endpoint.address)
        assertEquals(443, profile.config.endpoint.port)
        assertEquals(SecurityMode.REALITY, profile.config.security.mode)
        assertEquals("PUBKEY", profile.config.endpoint.publicKey)
        assertEquals("ab12", profile.config.endpoint.shortId)
        assertEquals(TransportNetwork.GRPC, profile.config.transport.network)
        assertEquals("grpcsvc", profile.config.transport.serviceName)
        assertEquals("My Node", profile.name)
    }

    @Test
    fun `parses shadowsocks base64 link`() {
        val payload = Base64Codec.encode("aes-256-gcm:secret".toByteArray())
        val link = "ss://$payload@1.2.3.4:8388#SS"

        val profile = (ShareLinkParser.parse(link) as ImportResult.Success).profiles.single()
        assertEquals(ProxyProtocol.SHADOWSOCKS, profile.config.protocol)
        assertEquals("aes-256-gcm", profile.config.endpoint.method)
        assertEquals("secret", profile.config.endpoint.password)
        assertEquals("1.2.3.4", profile.config.endpoint.address)
        assertEquals(8388, profile.config.endpoint.port)
    }

    @Test
    fun `unknown scheme fails loudly`() {
        val result = ShareLinkParser.parse("hysteria2://pass@host:443")
        assertTrue(result is ImportResult.Failure)
    }

    @Test
    fun `subscription payload with base64 list is parsed`() {
        val link = "trojan://pwd@host.example:8443?sni=host.example#Node%201"
        val body = Base64Codec.encode(link.toByteArray())

        val result = SubscriptionParser.parse(body, "sub-1", dev.nexuscore.model.EngineId.XRAY)
        assertTrue(result is ImportResult.Success)
        val profile = (result as ImportResult.Success).profiles.single()
        assertEquals(ProxyProtocol.TROJAN, profile.config.protocol)
        assertEquals("sub-1", profile.subscriptionId)
    }
}
