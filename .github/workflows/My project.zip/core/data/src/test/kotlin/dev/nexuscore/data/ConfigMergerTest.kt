package dev.nexuscore.data

import dev.nexuscore.model.ConfigOverrides
import dev.nexuscore.model.DnsMode
import dev.nexuscore.model.DnsOptions
import dev.nexuscore.model.NetworkOptions
import dev.nexuscore.model.NexusConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfigMergerTest {

    private val base = NexusConfig(
        network = NetworkOptions(mtu = 1400, socksPort = 10808),
        dns = DnsOptions(mode = DnsMode.SYSTEM)
    )

    @Test
    fun `overrides win over base config`() {
        val overrides = ConfigOverrides(network = NetworkOptions(mtu = 9000, socksPort = 10809))
        val merged = ConfigMerger.merge(base, overrides)

        assertEquals(9000, merged.config.network.mtu)
        assertEquals(10809, merged.config.network.socksPort)
        assertEquals(9000, merged.appliedOverrides.network?.mtu)
    }

    @Test
    fun `session overrides win over profile overrides`() {
        val overrides = ConfigOverrides(dns = DnsOptions(mode = DnsMode.UDP, servers = listOf("1.1.1.1")))
        val session = ConfigOverrides(dns = DnsOptions(mode = DnsMode.DNS_OVER_HTTPS, servers = listOf("https://dns.google/dns-query")))

        val merged = ConfigMerger.merge(base, overrides, session)

        assertEquals(DnsMode.DNS_OVER_HTTPS, merged.config.dns.mode)
        assertEquals(listOf("https://dns.google/dns-query"), merged.config.dns.servers)
    }

    @Test
    fun `untouched sections keep base values`() {
        val merged = ConfigMerger.merge(base, ConfigOverrides())
        assertEquals(base, merged.config)
        assertTrue(merged.appliedOverrides.isEmpty)
    }

    @Test
    fun `raw json is reported`() {
        val merged = ConfigMerger.merge(base.copy(rawJson = "{}"))
        assertTrue(merged.usedRawJson)
    }
}
