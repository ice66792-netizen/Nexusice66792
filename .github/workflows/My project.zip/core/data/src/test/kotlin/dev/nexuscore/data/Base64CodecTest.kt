package dev.nexuscore.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class Base64CodecTest {

    @Test
    fun `round trips ascii`() {
        val text = "vless://11111111-2222@host:443#node"
        val encoded = Base64Codec.encode(text.toByteArray())
        assertEquals(text, Base64Codec.decodeToStringOrNull(encoded))
    }

    @Test
    fun `handles url safe alphabet and missing padding`() {
        val encoded = Base64Codec.encode("method:password".toByteArray(), urlSafe = true)
        assertEquals("method:password", Base64Codec.decodeToStringOrNull(encoded))
    }

    @Test
    fun `rejects garbage`() {
        assertNull(Base64Codec.decode("not base64 ***"))
    }
}
