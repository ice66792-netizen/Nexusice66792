package dev.nexuscore.data

import dev.nexuscore.model.BackupEnvelope
import dev.nexuscore.model.BackupParseResult
import dev.nexuscore.model.Profile
import dev.nexuscore.model.ThemeSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BackupMigratorTest {

    @Test
    fun `reads current format`() {
        val raw = NexusJson.pretty.encodeToString(
            BackupEnvelope.serializer(),
            BackupEnvelope(
                appVersion = "1.0",
                theme = ThemeSettings(),
                profiles = listOf(
                    Profile(id = "p1", name = "A", createdAtEpochMillis = 1, updatedAtEpochMillis = 1)
                )
            )
        )

        val result = BackupMigrator.migrate(raw)
        assertTrue(result is BackupParseResult.Success)
        val success = result as BackupParseResult.Success
        assertEquals(1, success.envelope.profiles.size)
        assertTrue(success.appliedMigrations.isEmpty())
    }

    @Test
    fun `migrates v1 documents`() {
        val raw = """
            {"format":"nexuscore.backup","formatVersion":1,"appVersion":"0.9",
             "profiles":[{"id":"p1","name":"Legacy","createdAtEpochMillis":1,"updatedAtEpochMillis":1}]}
        """.trimIndent()

        val result = BackupMigrator.migrate(raw)
        assertTrue(result is BackupParseResult.Success)
        val success = result as BackupParseResult.Success
        assertEquals(listOf(1), success.appliedMigrations)
        assertEquals(BackupEnvelope.CURRENT_VERSION, success.envelope.formatVersion)
        assertEquals("Legacy", success.envelope.profiles.single().name)
    }

    @Test
    fun `rejects newer formats`() {
        val raw = """{"format":"nexuscore.backup","formatVersion":99}"""
        assertTrue(BackupMigrator.migrate(raw) is BackupParseResult.Failure)
    }

    @Test
    fun `rejects foreign json`() {
        val raw = """{"hello":"world"}"""
        assertTrue(BackupMigrator.migrate(raw) is BackupParseResult.Failure)
    }
}
