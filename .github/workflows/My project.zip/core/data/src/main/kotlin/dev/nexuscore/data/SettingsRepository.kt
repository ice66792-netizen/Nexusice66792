package dev.nexuscore.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dev.nexuscore.common.NexusLog
import dev.nexuscore.model.AppSettings
import dev.nexuscore.model.DashboardSettings
import dev.nexuscore.model.ThemeScheme
import dev.nexuscore.model.ThemeSettings
import dev.nexuscore.model.ThemeState
import dev.nexuscore.model.ThemePresets
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import java.io.IOException

private val Context.nexusDataStore: DataStore<Preferences> by preferencesDataStore(name = "nexus_settings")

/**
 * Typed access to every persisted user preference. Each document is stored as
 * JSON in its own preference key, which keeps migrations additive and makes a
 * corrupt document affect only that document.
 */
class SettingsRepository(private val context: Context) {

    private val appKey = stringPreferencesKey("app_settings_v1")
    private val themeKey = stringPreferencesKey("theme_state_v1")
    private val dashboardKey = stringPreferencesKey("dashboard_settings_v1")

    private val safePreferences: Flow<Preferences> = context.nexusDataStore.data.catch { throwable ->
        if (throwable is IOException) {
            NexusLog.e("Settings", "DataStore read failed, using defaults", throwable)
            emit(emptyPreferences())
        } else {
            throw throwable
        }
    }

    val appSettings: Flow<AppSettings> = safePreferences.map { prefs ->
        prefs[appKey]?.let { decode(it, AppSettings.serializer()) } ?: AppSettings()
    }

    val themeState: Flow<ThemeState> = safePreferences.map { prefs ->
        prefs[themeKey]?.let { decode(it, ThemeState.serializer()) } ?: defaultThemeState()
    }

    val dashboardSettings: Flow<DashboardSettings> = safePreferences.map { prefs ->
        prefs[dashboardKey]?.let { decode(it, DashboardSettings.serializer()) } ?: DashboardSettings()
    }

    suspend fun updateAppSettings(transform: (AppSettings) -> AppSettings) {
        context.nexusDataStore.edit { prefs ->
            val current = prefs[appKey]?.let { decode(it, AppSettings.serializer()) } ?: AppSettings()
            prefs[appKey] = NexusJson.instance.encodeToString(AppSettings.serializer(), transform(current))
        }
    }

    suspend fun updateTheme(transform: (ThemeState) -> ThemeState) {
        context.nexusDataStore.edit { prefs ->
            val current = prefs[themeKey]?.let { decode(it, ThemeState.serializer()) } ?: defaultThemeState()
            prefs[themeKey] = NexusJson.instance.encodeToString(ThemeState.serializer(), transform(current))
        }
    }

    suspend fun updateDashboard(transform: (DashboardSettings) -> DashboardSettings) {
        context.nexusDataStore.edit { prefs ->
            val current = prefs[dashboardKey]?.let { decode(it, DashboardSettings.serializer()) } ?: DashboardSettings()
            prefs[dashboardKey] =
                NexusJson.instance.encodeToString(DashboardSettings.serializer(), transform(current))
        }
    }

    /** Used by backup restore. Replaces whole documents. */
    suspend fun restore(
        settings: AppSettings?,
        theme: ThemeState?,
        dashboard: DashboardSettings?
    ) {
        context.nexusDataStore.edit { prefs ->
            settings?.let { prefs[appKey] = NexusJson.instance.encodeToString(AppSettings.serializer(), it) }
            theme?.let { prefs[themeKey] = NexusJson.instance.encodeToString(ThemeState.serializer(), it) }
            dashboard?.let {
                prefs[dashboardKey] = NexusJson.instance.encodeToString(DashboardSettings.serializer(), it)
            }
        }
    }

    /** Convenience snapshot for code paths that are not collecting a flow. */
    suspend fun currentAppSettings(): AppSettings = appSettings.first()

    suspend fun currentTheme(): ThemeState = themeState.first()

    suspend fun currentDashboard(): DashboardSettings = dashboardSettings.first()

    private fun <T> decode(raw: String, serializer: kotlinx.serialization.KSerializer<T>): T? =
        runCatching { NexusJson.instance.decodeFromString(serializer, raw) }
            .onFailure { NexusLog.w("Settings", "Corrupt document, ignoring: ${it.message}") }
            .getOrNull()

    companion object {
        fun defaultThemeState(): ThemeState {
            val schemes = ThemePresets.all.map { preset ->
                ThemeScheme(
                    id = preset.id,
                    name = preset.name,
                    builtIn = true,
                    settings = ThemeSettings(presetId = preset.id, accentColor = preset.accent)
                )
            }
            return ThemeState(
                active = ThemeSettings(presetId = ThemePresets.all.first().id),
                activeSchemeId = ThemePresets.all.first().id,
                savedSchemes = schemes
            )
        }
    }
}
