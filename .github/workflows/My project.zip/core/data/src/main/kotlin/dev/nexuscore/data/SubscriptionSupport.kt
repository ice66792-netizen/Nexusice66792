package dev.nexuscore.data

import dev.nexuscore.common.NexusLog
import dev.nexuscore.common.SecretRedactor
import dev.nexuscore.model.EngineId
import dev.nexuscore.model.ImportResult
import dev.nexuscore.model.Profile
import dev.nexuscore.model.ProfileSource
import dev.nexuscore.model.Subscription
import dev.nexuscore.model.SubscriptionRefresh
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.UUID
import java.util.concurrent.TimeUnit

@Serializable
data class SubscriptionsDocument(
    val schemaVersion: Int = 1,
    val subscriptions: List<Subscription> = emptyList()
)

sealed interface FetchResult {
    data class Success(val body: String, val etag: String?) : FetchResult
    data object NotModified : FetchResult
    data class Failure(val message: String) : FetchResult
}

/** Strict but pragmatic fetcher: HTTPS only, capped body, explicit timeouts. */
class SubscriptionFetcher(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
) {

    suspend fun fetch(url: String, etag: String? = null): FetchResult = withContext(Dispatchers.IO) {
        val parsed = url.toHttpUrlOrNull()
            ?: return@withContext FetchResult.Failure("Malformed subscription URL")

        if (parsed.scheme != "https" && !isLocal(parsed.host)) {
            return@withContext FetchResult.Failure(
                "Only HTTPS subscriptions are allowed (HTTP is permitted for 127.0.0.1 / localhost only)."
            )
        }

        val request = Request.Builder()
            .url(parsed)
            .header("User-Agent", "NexusCore/1.0 (Android)")
            .header("Accept", "text/plain, application/json, */*")
            .apply { etag?.let { header("If-None-Match", it) } }
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.code == 304) return@withContext FetchResult.NotModified
                if (!response.isSuccessful) {
                    return@withContext FetchResult.Failure("Server returned HTTP ${response.code}")
                }
                val declared = response.body?.contentLength() ?: -1L
                if (declared > MAX_BYTES) {
                    return@withContext FetchResult.Failure("Subscription is larger than ${MAX_BYTES / 1024} KiB")
                }
                val bytes = response.body?.bytes() ?: return@withContext FetchResult.Failure("Empty response")
                if (bytes.size > MAX_BYTES) {
                    return@withContext FetchResult.Failure("Subscription is larger than ${MAX_BYTES / 1024} KiB")
                }
                FetchResult.Success(bytes.toString(Charsets.UTF_8), response.header("ETag"))
            }
        } catch (t: Throwable) {
            NexusLog.w("Subscription", "Fetch failed: ${t.message}")
            FetchResult.Failure(SecretRedactor.redact(t.message ?: t.javaClass.simpleName))
        }
    }

    private fun isLocal(host: String): Boolean =
        host == "127.0.0.1" || host == "localhost" || host == "::1"

    private companion object {
        const val MAX_BYTES = 2 * 1024 * 1024
    }
}

/** Parses subscription payloads: base64 link lists, plain link lists and full Xray JSON. */
object SubscriptionParser {

    fun parse(body: String, subscriptionId: String?, engineId: EngineId): ImportResult {
        val trimmed = body.trim()
        if (trimmed.isEmpty()) return ImportResult.Failure("Subscription is empty")

        if (trimmed.startsWith("{")) {
            val obj = runCatching { NexusJson.instance.parseToJsonElement(trimmed).jsonObject }.getOrNull()
                ?: return ImportResult.Failure("Subscription JSON is malformed")
            return parseJsonConfig(obj, trimmed, subscriptionId, engineId)
        }

        val decoded = Base64Codec.decodeToStringOrNull(trimmed) ?: trimmed
        val lines = decoded.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") && !it.startsWith("//") }
            .toList()

        if (lines.isEmpty()) return ImportResult.Failure("Subscription contains no links")

        val profiles = mutableListOf<Profile>()
        val warnings = mutableListOf<String>()
        lines.forEachIndexed { index, line ->
            when (val result = ShareLinkParser.parse(line, engineId)) {
                is ImportResult.Success -> profiles += result.profiles.map { profile ->
                    profile.copy(
                        subscriptionId = subscriptionId,
                        source = ProfileSource.SUBSCRIPTION,
                        name = profile.name.ifBlank { "Node ${index + 1}" }
                    )
                }

                is ImportResult.Failure -> warnings += "Line ${index + 1}: ${result.message}"
            }
        }

        return if (profiles.isEmpty()) {
            ImportResult.Failure(warnings.firstOrNull() ?: "No supported links found")
        } else {
            ImportResult.Success(profiles, warnings)
        }
    }

    private fun parseJsonConfig(
        obj: JsonObject,
        raw: String,
        subscriptionId: String?,
        engineId: EngineId
    ): ImportResult {
        if (!obj.containsKey("outbounds")) {
            return ImportResult.Failure("JSON has no 'outbounds' section")
        }
        val now = System.currentTimeMillis()
        val profile = Profile(
            id = UUID.randomUUID().toString(),
            name = "Imported Xray config",
            description = "Full JSON configuration imported from a subscription",
            engineId = engineId,
            source = ProfileSource.SUBSCRIPTION,
            config = dev.nexuscore.model.NexusConfig(rawJson = raw),
            subscriptionId = subscriptionId,
            createdAtEpochMillis = now,
            updatedAtEpochMillis = now
        )
        return ImportResult.Success(
            listOf(profile),
            listOf("Native JSON keeps its own routing/DNS; app level routing UI is disabled for this profile.")
        )
    }
}

class SubscriptionRepository(
    filesDir: File,
    private val profiles: ProfileRepository,
    private val fetcher: SubscriptionFetcher = SubscriptionFetcher()
) {

    private val store = AtomicJsonFile(
        File(filesDir, "subscriptions.json"),
        SubscriptionsDocument.serializer(),
        SubscriptionsDocument()
    )
    private val mutex = Mutex()
    private val _subscriptions = MutableStateFlow(store.read().subscriptions)
    val subscriptions: StateFlow<List<Subscription>> = _subscriptions.asStateFlow()

    suspend fun add(name: String, url: String, engine: EngineId = EngineId.XRAY): Subscription =
        mutex.withLock {
            val subscription = Subscription(
                id = UUID.randomUUID().toString(),
                name = name.ifBlank { "Subscription" },
                url = url.trim()
            )
            persist(_subscriptions.value + subscription)
            subscription
        }

    suspend fun remove(id: String) = mutex.withLock {
        persist(_subscriptions.value.filterNot { it.id == id })
        profiles.profiles.value.filter { it.subscriptionId == id }.forEach { profiles.delete(it.id) }
    }

    suspend fun update(id: String, transform: (Subscription) -> Subscription) = mutex.withLock {
        persist(_subscriptions.value.map { if (it.id == id) transform(it) else it })
    }

    /** Used by backup restore. Existing entries with the same id are replaced. */
    suspend fun importAll(incoming: List<Subscription>): Int = mutex.withLock {
        val map = LinkedHashMap<String, Subscription>()
        _subscriptions.value.forEach { map[it.id] = it }
        incoming.forEach { map[it.id] = it }
        persist(map.values.toList())
        incoming.size
    }

    /**
     * Fetches and parses without touching storage. The caller shows a diff
     * preview and then calls [commit].
     */
    suspend fun prepareRefresh(id: String): Result<SubscriptionRefresh> {
        val subscription = _subscriptions.value.firstOrNull { it.id == id }
            ?: return Result.failure(IllegalArgumentException("Unknown subscription"))

        val fetched = when (val result = fetcher.fetch(subscription.url, subscription.etag)) {
            is FetchResult.Success -> result
            FetchResult.NotModified -> return Result.failure(IllegalStateException("Already up to date"))
            is FetchResult.Failure -> {
                update(id) { it.copy(lastError = result.message) }
                return Result.failure(IllegalStateException(result.message))
            }
        }

        val existing = profiles.profiles.value.firstOrNull { it.subscriptionId == id }
        val parse = SubscriptionParser.parse(
            body = fetched.body,
            subscriptionId = id,
            engineId = existing?.engineId ?: EngineId.XRAY
        )
        val first = when (parse) {
            is ImportResult.Success -> parse.profiles.first()
            is ImportResult.Failure -> {
                update(id) { it.copy(lastError = parse.message) }
                return Result.failure(IllegalStateException(parse.message))
            }
        }

        val merged = if (existing != null) {
            first.copy(
                id = existing.id,
                name = existing.name,
                overrides = existing.overrides,
                tags = existing.tags,
                validation = existing.validation,
                createdAtEpochMillis = existing.createdAtEpochMillis,
                sourceUrl = subscription.url
            )
        } else {
            first.copy(sourceUrl = subscription.url)
        }

        val changed = if (existing == null) {
            listOf("profile:created")
        } else {
            dev.nexuscore.engine.ConfigDiff.changedFields(existing.config, merged.config)
                .ifEmpty { listOf("profile:unchanged") }
        }

        val warnings = (parse as? ImportResult.Success)?.warnings.orEmpty()
        return Result.success(SubscriptionRefresh(id, merged, changed, warnings))
    }

    /** Applies a prepared refresh and remembers the ETag for the next poll. */
    suspend fun commit(refresh: SubscriptionRefresh, etag: String? = null) {
        val stored = profiles.upsert(refresh.profile)
        update(refresh.subscriptionId) {
            it.copy(
                lastFetchedAtEpochMillis = System.currentTimeMillis(),
                lastError = null,
                etag = etag ?: it.etag,
                profileId = stored.id
            )
        }
        profiles.validate(stored)
    }

    private fun persist(list: List<Subscription>) {
        store.write(SubscriptionsDocument(subscriptions = list))
        _subscriptions.value = list
    }
}
