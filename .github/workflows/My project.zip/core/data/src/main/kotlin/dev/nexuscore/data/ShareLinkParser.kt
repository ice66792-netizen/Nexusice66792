package dev.nexuscore.data

import dev.nexuscore.model.DnsMode
import dev.nexuscore.model.EngineId
import dev.nexuscore.model.ImportResult
import dev.nexuscore.model.NexusConfig
import dev.nexuscore.model.Profile
import dev.nexuscore.model.ProfileSource
import dev.nexuscore.model.ProxyProtocol
import dev.nexuscore.model.SecurityMode
import dev.nexuscore.model.ServerEndpoint
import dev.nexuscore.model.SecurityOptions
import dev.nexuscore.model.TransportNetwork
import dev.nexuscore.model.TransportOptions
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.URLDecoder
import java.util.UUID

/**
 * Parses the share link formats used by Xray / sing-box clients.
 *
 * Supported: vless, vmess, trojan, ss, socks, wireguard (best effort) plus full
 * Xray JSON. Unsupported schemes produce an explicit failure - never a silently
 * empty profile.
 */
object ShareLinkParser {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    fun parse(link: String, engineId: EngineId = EngineId.XRAY): ImportResult {
        val trimmed = link.trim()
        if (trimmed.isEmpty()) return ImportResult.Failure("Empty link")

        return when {
            trimmed.startsWith("vless://", true) -> parseVless(trimmed, engineId)
            trimmed.startsWith("trojan://", true) -> parseTrojan(trimmed, engineId)
            trimmed.startsWith("vmess://", true) -> parseVmess(trimmed, engineId)
            trimmed.startsWith("ss://", true) -> parseShadowsocks(trimmed, engineId)
            trimmed.startsWith("socks://", true) || trimmed.startsWith("socks5://", true) ->
                parseSocks(trimmed, engineId)

            trimmed.startsWith("wireguard://", true) || trimmed.startsWith("wg://", true) ->
                ImportResult.Failure("WireGuard share links vary between vendors; import the WireGuard JSON instead.")

            trimmed.startsWith("hysteria2://", true) || trimmed.startsWith("hy2://", true) ->
                ImportResult.Failure("Hysteria2 is not supported by the bundled Xray core.")

            else -> ImportResult.Failure("Unsupported link scheme")
        }
    }

    // ---------------------------------------------------------------- vless

    private fun parseVless(link: String, engineId: EngineId): ImportResult {
        val parts = splitLink(link) ?: return ImportResult.Failure("Malformed vless link")
        if (parts.userInfo.isBlank()) return ImportResult.Failure("vless link has no UUID")

        val query = parts.query
        val network = transport(query["type"])
        val securityMode = when (query["security"]?.lowercase()) {
            "reality" -> SecurityMode.REALITY
            "tls" -> SecurityMode.TLS
            "none", null -> SecurityMode.NONE
            else -> SecurityMode.TLS
        }

        val config = NexusConfig(
            protocol = ProxyProtocol.VLESS,
            endpoint = ServerEndpoint(
                address = parts.host,
                port = parts.port,
                id = decode(parts.userInfo),
                sni = query["sni"].orEmpty(),
                flow = query["flow"].orEmpty(),
                fingerprint = query["fp"] ?: "chrome",
                publicKey = query["pbk"].orEmpty(),
                shortId = query["sid"].orEmpty(),
                spiderX = query["spx"] ?: "/"
            ),
            transport = TransportOptions(
                network = network,
                path = query["path"] ?: "/",
                host = query["host"].orEmpty(),
                serviceName = query["serviceName"].orEmpty()
            ),
            security = SecurityOptions(
                mode = securityMode,
                serverName = query["sni"].orEmpty(),
                fingerprint = query["fp"] ?: "chrome",
                publicKey = query["pbk"].orEmpty(),
                shortId = query["sid"].orEmpty(),
                alpn = query["alpn"]?.split(',')?.filter { it.isNotBlank() }.orEmpty()
            )
        )
        return success(parts.name, config, link, engineId)
    }

    // --------------------------------------------------------------- trojan

    private fun parseTrojan(link: String, engineId: EngineId): ImportResult {
        val parts = splitLink(link) ?: return ImportResult.Failure("Malformed trojan link")
        val query = parts.query
        val securityMode = when (query["security"]?.lowercase()) {
            "reality" -> SecurityMode.REALITY
            "none" -> SecurityMode.NONE
            else -> SecurityMode.TLS
        }
        val config = NexusConfig(
            protocol = ProxyProtocol.TROJAN,
            endpoint = ServerEndpoint(
                address = parts.host,
                port = parts.port,
                password = decode(parts.userInfo),
                sni = query["sni"].orEmpty(),
                fingerprint = query["fp"] ?: "chrome",
                publicKey = query["pbk"].orEmpty(),
                shortId = query["sid"].orEmpty()
            ),
            transport = TransportOptions(
                network = transport(query["type"]),
                path = query["path"] ?: "/",
                host = query["host"].orEmpty(),
                serviceName = query["serviceName"].orEmpty()
            ),
            security = SecurityOptions(
                mode = securityMode,
                serverName = query["sni"].orEmpty(),
                fingerprint = query["fp"] ?: "chrome",
                publicKey = query["pbk"].orEmpty(),
                shortId = query["sid"].orEmpty()
            )
        )
        return success(parts.name, config, link, engineId)
    }

    // ---------------------------------------------------------------- vmess

    private fun parseVmess(link: String, engineId: EngineId): ImportResult {
        val payload = link.removePrefix("vmess://").substringBefore('#')
        val decoded = Base64Codec.decodeToStringOrNull(payload)
            ?: return ImportResult.Failure("vmess payload is not valid Base64")
        val obj: JsonObject = runCatching { json.parseToJsonElement(decoded).jsonObject }
            .getOrNull() ?: return ImportResult.Failure("vmess payload is not valid JSON")

        fun str(key: String): String = obj[key]?.jsonPrimitive?.contentOrNull.orEmpty()

        val host = str("add")
        if (host.isBlank()) return ImportResult.Failure("vmess payload has no address")
        val port = str("port").toIntOrNull() ?: 443
        val network = transport(str("net").ifBlank { "tcp" })
        val tls = str("tls").equals("tls", true)

        val config = NexusConfig(
            protocol = ProxyProtocol.VMESS,
            endpoint = ServerEndpoint(
                address = host,
                port = port,
                id = str("id"),
                sni = str("sni"),
                fingerprint = str("fp").ifBlank { "chrome" }
            ),
            transport = TransportOptions(
                network = network,
                path = str("path").ifBlank { "/" },
                host = str("host")
            ),
            security = SecurityOptions(
                mode = if (tls) SecurityMode.TLS else SecurityMode.NONE,
                serverName = str("sni").ifBlank { str("host") },
                fingerprint = str("fp").ifBlank { "chrome" },
                alpn = str("alpn").split(',').filter { it.isNotBlank() }
            )
        )
        val name = str("ps").ifBlank { "VMess $host" }
        return success(name, config, link, engineId)
    }

    // ---------------------------------------------------------- shadowsocks

    private fun parseShadowsocks(link: String, engineId: EngineId): ImportResult {
        var body = link.removePrefix("ss://")
        val name = decode(body.substringAfter('#', ""))
        body = body.substringBefore('#').substringBefore('?')

        val at = body.lastIndexOf('@')
        val method: String
        val password: String
        val hostPort: String

        if (at >= 0) {
            val decodedUserInfo = Base64Codec.decodeToStringOrNull(body.substring(0, at))
                ?: decode(body.substring(0, at))
            val colon = decodedUserInfo.indexOf(':')
            if (colon <= 0) return ImportResult.Failure("ss link has no method:password")
            method = decodedUserInfo.substring(0, colon)
            password = decodedUserInfo.substring(colon + 1)
            hostPort = body.substring(at + 1)
        } else {
            val decoded = Base64Codec.decodeToStringOrNull(body)
                ?: return ImportResult.Failure("ss payload is not valid Base64")
            val atInDecoded = decoded.lastIndexOf('@')
            if (atInDecoded <= 0) return ImportResult.Failure("ss payload has no host")
            val credentials = decoded.substring(0, atInDecoded)
            val colon = credentials.indexOf(':')
            if (colon <= 0) return ImportResult.Failure("ss payload has no method:password")
            method = credentials.substring(0, colon)
            password = credentials.substring(colon + 1)
            hostPort = decoded.substring(atInDecoded + 1)
        }

        val host = hostOf(hostPort)
        val port = portOf(hostPort)
        if (host.isBlank()) return ImportResult.Failure("ss link has no host")

        val config = NexusConfig(
            protocol = ProxyProtocol.SHADOWSOCKS,
            endpoint = ServerEndpoint(
                address = host,
                port = port,
                password = password.trim(),
                method = method.trim()
            ),
            security = SecurityOptions(mode = SecurityMode.NONE),
            dns = dev.nexuscore.model.DnsOptions(mode = DnsMode.SYSTEM)
        )
        return success(name.ifBlank { "Shadowsocks $host" }, config, link, engineId)
    }

    // ---------------------------------------------------------------- socks

    private fun parseSocks(link: String, engineId: EngineId): ImportResult {
        var body = link.substringAfter("://")
        val name = decode(body.substringAfter('#', ""))
        body = body.substringBefore('#')
        val at = body.lastIndexOf('@')
        if (at < 0) return ImportResult.Failure("socks link has no credentials")
        val credentials = Base64Codec.decodeToStringOrNull(body.substring(0, at))
            ?: return ImportResult.Failure("socks credentials are not valid Base64")
        val colon = credentials.indexOf(':')
        val hostPort = body.substring(at + 1)

        val config = NexusConfig(
            protocol = ProxyProtocol.SOCKS,
            endpoint = ServerEndpoint(
                address = hostOf(hostPort),
                port = portOf(hostPort),
                password = if (colon >= 0) credentials.substring(colon + 1) else "",
                id = if (colon >= 0) credentials.substring(0, colon) else credentials
            ),
            security = SecurityOptions(mode = SecurityMode.NONE)
        )
        return success(name.ifBlank { "SOCKS5 ${config.endpoint.address}" }, config, link, engineId)
    }

    // --------------------------------------------------------------- helpers

    private data class LinkParts(
        val userInfo: String,
        val host: String,
        val port: Int,
        val query: Map<String, String>,
        val name: String
    )

    private fun success(
        name: String,
        config: NexusConfig,
        origin: String,
        engineId: EngineId
    ): ImportResult {
        val now = System.currentTimeMillis()
        val profile = Profile(
            id = UUID.randomUUID().toString(),
            name = name.ifBlank { "${config.protocol.name} ${config.endpoint.address}" },
            description = "Imported from share link",
            engineId = engineId,
            source = ProfileSource.SHARE_LINK,
            sourceUrl = origin,
            config = config,
            createdAtEpochMillis = now,
            updatedAtEpochMillis = now
        )
        return ImportResult.Success(listOf(profile))
    }

    private fun splitLink(link: String): LinkParts? {
        val body = link.substringAfter("://", "")
        if (body.isEmpty()) return null
        val name = decode(body.substringAfter('#', ""))
        var rest = body.substringBefore('#')
        val queryPart = rest.substringAfter('?', "")
        if (rest.contains('?')) rest = rest.substringBefore('?')
        val at = rest.lastIndexOf('@')
        val userInfo = if (at >= 0) rest.substring(0, at) else ""
        val hostPort = if (at >= 0) rest.substring(at + 1) else rest
        val host = hostOf(hostPort)
        if (host.isBlank()) return null
        return LinkParts(
            userInfo = userInfo,
            host = host,
            port = portOf(hostPort),
            query = parseQuery(queryPart),
            name = name
        )
    }

    private fun hostOf(hostPort: String): String {
        val clean = hostPort.substringBefore('/').trim()
        return when {
            clean.startsWith("[") -> clean.substringAfter('[').substringBefore(']')
            clean.contains(':') -> clean.substringBeforeLast(':')
            else -> clean
        }
    }

    private fun portOf(hostPort: String): Int {
        val clean = hostPort.substringBefore('/').trim()
        val portText = when {
            clean.startsWith("[") -> clean.substringAfter(']').removePrefix(":")
            clean.contains(':') -> clean.substringAfterLast(':')
            else -> ""
        }
        return portText.toIntOrNull()?.takeIf { it in 1..65535 } ?: 443
    }

    private fun parseQuery(raw: String): Map<String, String> {
        if (raw.isBlank()) return emptyMap()
        return raw.split('&').mapNotNull { pair ->
            if (pair.isBlank()) return@mapNotNull null
            val key = pair.substringBefore('=')
            val value = if (pair.contains('=')) pair.substringAfter('=') else ""
            decode(key) to decode(value)
        }.toMap()
    }

    private fun transport(type: String?): TransportNetwork = when (type?.lowercase()) {
        "ws", "websocket" -> TransportNetwork.WS
        "grpc" -> TransportNetwork.GRPC
        "http", "h2" -> TransportNetwork.HTTP2
        "xhttp", "splithttp" -> TransportNetwork.XHTTP
        "kcp", "mkcp" -> TransportNetwork.KCP
        "quic" -> TransportNetwork.QUIC
        else -> TransportNetwork.TCP
    }

    private fun decode(value: String): String = runCatching {
        URLDecoder.decode(value, "UTF-8")
    }.getOrDefault(value)
}
