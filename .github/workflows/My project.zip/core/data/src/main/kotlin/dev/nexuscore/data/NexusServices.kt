package dev.nexuscore.data

import android.content.Context
import dev.nexuscore.engine.ConfigValidator
import dev.nexuscore.engine.EngineProvider
import dev.nexuscore.engine.EngineRegistry
import dev.nexuscore.engine.VpnControl

/**
 * Manual composition root.
 *
 * Hilt was considered but rejected for this build: the project must compile
 * deterministically without annotation processors, and there are only a handful
 * of singletons. Everything is still constructor-injected, so switching to Hilt
 * later means replacing this object with modules - no call-site changes.
 */
object NexusServices {

    lateinit var settings: SettingsRepository
        private set

    lateinit var profiles: ProfileRepository
        private set

    lateinit var subscriptions: SubscriptionRepository
        private set

    lateinit var backups: BackupManager
        private set

    lateinit var engines: EngineRegistry
        private set

    lateinit var validator: ConfigValidator
        private set

    /** Implemented by the app module (VpnService owner). */
    lateinit var control: VpnControl
        private set

    val isInitialized: Boolean
        get() = ::settings.isInitialized

    fun initialize(
        context: Context,
        appVersion: String,
        engineProviders: List<EngineProvider>
    ) {
        val appContext = context.applicationContext
        validator = ConfigValidator()
        engines = EngineRegistry(engineProviders)
        settings = SettingsRepository(appContext)
        profiles = ProfileRepository(
            filesDir = appContext.filesDir,
            settings = settings,
            validator = validator,
            registry = engines
        )
        subscriptions = SubscriptionRepository(appContext.filesDir, profiles)
        backups = BackupManager(settings, profiles, subscriptions, appVersion)
    }

    fun attachControl(vpnControl: VpnControl) {
        control = vpnControl
    }
}
