package dev.nexuscore.data

/**
 * Dependency free Base64 (standard and URL-safe, padding optional).
 *
 * Implemented locally so the parsers stay JVM testable and do not depend on
 * `android.util.Base64` (which is unavailable in local unit tests).
 */
object Base64Codec {

    private const val STANDARD = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    private const val URL_SAFE = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"

    fun decode(input: String, urlSafe: Boolean = false): ByteArray? {
        val alphabet = if (urlSafe) URL_SAFE else STANDARD
        val cleaned = input.filterNot { it.isWhitespace() }.trimEnd('=')
        if (cleaned.isEmpty()) return ByteArray(0)
        val output = ArrayList<Byte>((cleaned.length * 3) / 4)
        var buffer = 0
        var bits = 0
        for (char in cleaned) {
            val index = alphabet.indexOf(char)
            if (index < 0) return null
            buffer = (buffer shl 6) or index
            bits += 6
            if (bits >= 8) {
                bits -= 8
                output.add(((buffer shr bits) and 0xFF).toByte())
            }
        }
        return output.toByteArray()
    }

    fun decodeToStringOrNull(input: String): String? {
        val trimmed = input.trim()
        val bytes = decode(trimmed, urlSafe = trimmed.contains('-') || trimmed.contains('_'))
            ?: return null
        if (bytes.isEmpty()) return null
        val text = bytes.toString(Charsets.UTF_8)
        return text.takeIf { it.all { c -> c == '\n' || c == '\r' || c == '\t' || !c.isISOControl() } }
    }

    fun encode(bytes: ByteArray, urlSafe: Boolean = false): String {
        val alphabet = if (urlSafe) URL_SAFE else STANDARD
        val sb = StringBuilder((bytes.size + 2) / 3 * 4)
        var i = 0
        while (i < bytes.size) {
            val b0 = bytes[i].toInt() and 0xFF
            val b1 = if (i + 1 < bytes.size) bytes[i + 1].toInt() and 0xFF else 0
            val b2 = if (i + 2 < bytes.size) bytes[i + 2].toInt() and 0xFF else 0
            sb.append(alphabet[b0 shr 2])
            sb.append(alphabet[((b0 and 0x03) shl 4) or (b1 shr 4)])
            if (i + 1 < bytes.size) sb.append(alphabet[((b1 and 0x0F) shl 2) or (b2 shr 6)]) else sb.append('=')
            if (i + 2 < bytes.size) sb.append(alphabet[b2 and 0x3F]) else sb.append('=')
            i += 3
        }
        return if (urlSafe) sb.toString().trimEnd('=') else sb.toString()
    }
}
