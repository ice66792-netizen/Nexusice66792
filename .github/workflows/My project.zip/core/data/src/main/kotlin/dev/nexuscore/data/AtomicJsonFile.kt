package dev.nexuscore.data

import dev.nexuscore.common.NexusLog
import kotlinx.serialization.KSerializer
import java.io.File

/**
 * Crash safe JSON document store.
 *
 * Writes go to `.tmp`, the previous version is preserved as `.bak`, and the
 * rename is atomic. A truncated write can therefore never destroy the last
 * good configuration.
 */
class AtomicJsonFile<T>(
    private val file: File,
    private val serializer: KSerializer<T>,
    private val default: T
) {

    private val backup = File(file.parentFile, file.name + ".bak")
    private val temp = File(file.parentFile, file.name + ".tmp")

    @Synchronized
    fun read(): T = readFrom(file) ?: readFrom(backup) ?: default

    private fun readFrom(source: File): T? {
        if (!source.isFile || source.length() == 0L) return null
        return runCatching {
            NexusJson.instance.decodeFromString(serializer, source.readText())
        }.onFailure {
            NexusLog.w("JsonStore", "Cannot read ${source.name}: ${it.message}")
        }.getOrNull()
    }

    @Synchronized
    fun write(value: T) {
        file.parentFile?.mkdirs()
        val payload = NexusJson.pretty.encodeToString(serializer, value)
        temp.writeText(payload)
        if (file.isFile) {
            runCatching { file.copyTo(backup, overwrite = true) }
        }
        if (!temp.renameTo(file)) {
            file.writeText(payload)
            temp.delete()
        }
    }
}
