package dev.nexuscore.data

import dev.nexuscore.engine.ConfigValidator
import dev.nexuscore.engine.EngineRegistry
import dev.nexuscore.model.EffectiveConfig
import dev.nexuscore.model.EngineId
import dev.nexuscore.model.Profile
import dev.nexuscore.model.ProfileSource
import dev.nexuscore.model.StoredValidation
import dev.nexuscore.model.ValidationReport
import dev.nexuscore.model.ValidationSeverity
import dev.nexuscore.model.ValidationStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.Serializable
import java.io.File
import java.util.UUID

@Serializable
data class ProfilesDocument(
    val schemaVersion: Int = 1,
    val profiles: List<Profile> = emptyList()
)

/**
 * Profiles are the unit of configuration. Subscription content lives in
 * [Profile.config]; everything the user changed by hand lives in
 * [Profile.overrides], so a refresh can replace the former without losing the
 * latter.
 */
class ProfileRepository(
    filesDir: File,
    private val settings: SettingsRepository,
    private val validator: ConfigValidator,
    private val registry: EngineRegistry
) {

    private val store = AtomicJsonFile(
        File(filesDir, "profiles.json"),
        ProfilesDocument.serializer(),
        ProfilesDocument()
    )

    private val mutex = Mutex()
    private val _profiles = MutableStateFlow(store.read().profiles)
    val profiles: StateFlow<List<Profile>> = _profiles.asStateFlow()

    val activeProfile: Flow<Profile?> = combine(profiles, settings.appSettings) { list, app ->
        list.firstOrNull { it.id == app.activeProfileId } ?: list.firstOrNull()
    }

    fun find(id: String?): Profile? = id?.let { key -> _profiles.value.firstOrNull { it.id == key } }

    fun effective(profile: Profile): EffectiveConfig =
        ConfigMerger.merge(profile.config, profile.overrides)

    fun newProfile(
        name: String,
        engineId: EngineId = EngineId.XRAY,
        source: ProfileSource = ProfileSource.MANUAL
    ): Profile {
        val now = System.currentTimeMillis()
        return Profile(
            id = UUID.randomUUID().toString(),
            name = name,
            engineId = engineId,
            source = source,
            createdAtEpochMillis = now,
            updatedAtEpochMillis = now
        )
    }

    suspend fun upsert(profile: Profile): Profile = mutex.withLock {
        val normalized = profile.copy(updatedAtEpochMillis = System.currentTimeMillis())
        val current = _profiles.value.toMutableList()
        val index = current.indexOfFirst { it.id == normalized.id }
        if (index >= 0) current[index] = normalized else current.add(normalized)
        persist(current)
        normalized
    }

    suspend fun delete(id: String) = mutex.withLock {
        persist(_profiles.value.filterNot { it.id == id })
        if (settings.currentAppSettings().activeProfileId == id) {
            settings.updateAppSettings { it.copy(activeProfileId = _profiles.value.firstOrNull()?.id) }
        }
    }

    suspend fun duplicate(id: String): Profile? {
        val source = find(id) ?: return null
        val now = System.currentTimeMillis()
        return upsert(
            source.copy(
                id = UUID.randomUUID().toString(),
                name = "${source.name} copy",
                createdAtEpochMillis = now,
                updatedAtEpochMillis = now,
                subscriptionId = null,
                source = ProfileSource.MANUAL
            )
        )
    }

    suspend fun rename(id: String, name: String) {
        find(id)?.let { upsert(it.copy(name = name.trim().ifBlank { it.name })) }
    }

    suspend fun setActive(id: String) {
        if (find(id) == null) return
        settings.updateAppSettings { it.copy(activeProfileId = id) }
    }

    /**
     * Validates with the engine that the profile is bound to and stores a
     * compact result so the list can render status without re-validating.
     */
    suspend fun validate(profile: Profile): ValidationReport {
        val provider = registry.provider(profile.engineId)
            ?: return ValidationReport()
        val report = provider.validate(effective(profile).config)
        val status = when {
            !report.isValid -> ValidationStatus.INVALID
            report.warnings.isNotEmpty() -> ValidationStatus.WARNING
            else -> ValidationStatus.VALID
        }
        val stored = StoredValidation(
            status = status,
            message = report.errors.firstOrNull()?.message
                ?: report.warnings.firstOrNull()?.message
                ?: "Configuration looks valid",
            checkedAtEpochMillis = System.currentTimeMillis(),
            errorCodes = report.issues
                .filter { it.severity == ValidationSeverity.ERROR }
                .map { it.code }
        )
        upsert(profile.copy(validation = stored))
        return report
    }

    /** Stores arbitrary configuration without touching user overrides. */
    suspend fun replaceConfig(id: String, config: dev.nexuscore.model.NexusConfig): Profile? {
        val current = find(id) ?: return null
        return upsert(
            current.copy(
                config = config,
                source = ProfileSource.SUBSCRIPTION.takeIf { current.subscriptionId != null }
                    ?: current.source
            )
        )
    }

    suspend fun applyOverrides(id: String, overrides: dev.nexuscore.model.ConfigOverrides): Profile? {
        val current = find(id) ?: return null
        return upsert(current.copy(overrides = overrides))
    }

    suspend fun importProfiles(incoming: List<Profile>, replaceAll: Boolean): Int = mutex.withLock {
        val base = if (replaceAll) emptyList() else _profiles.value
        val map = LinkedHashMap<String, Profile>()
        base.forEach { map[it.id] = it }
        incoming.forEach { map[it.id] = it }
        persist(map.values.toList())
        incoming.size
    }

    fun exportJson(): String =
        NexusJson.pretty.encodeToString(ProfilesDocument.serializer(), ProfilesDocument(profiles = _profiles.value))

    @Synchronized
    private fun persist(list: List<Profile>) {
        store.write(ProfilesDocument(profiles = list))
        _profiles.value = list
    }
}
