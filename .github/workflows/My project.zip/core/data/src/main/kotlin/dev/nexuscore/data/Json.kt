package dev.nexuscore.data

import kotlinx.serialization.json.Json

/** Single JSON policy for everything that touches disk or the network. */
object NexusJson {
    val instance: Json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        isLenient = false
        explicitNulls = false
    }

    val pretty: Json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = true
        explicitNulls = false
    }
}
