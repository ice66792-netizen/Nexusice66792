package dev.nexuscore.data

import dev.nexuscore.common.NexusLog
import dev.nexuscore.model.BackupEnvelope
import dev.nexuscore.model.BackupParseResult
import dev.nexuscore.model.BackupPart
import dev.nexuscore.model.NexusConfig
import dev.nexuscore.model.Profile
import dev.nexuscore.model.ProfileSource
import dev.nexuscore.model.ServerEndpoint
import dev.nexuscore.model.Subscription
import dev.nexuscore.model.ThemeState
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/** Versioned, forward compatible parsing of backup documents. */
object BackupMigrator {

    fun migrate(raw: String): BackupParseResult {
        val root: JsonObject = runCatching {
            NexusJson.instance.parseToJsonElement(raw).jsonObject
        }.getOrNull() ?: return BackupParseResult.Failure("Backup is not a JSON object")

        val format = root["format"]?.jsonPrimitive?.content
        if (format != null && format != BackupEnvelope.FORMAT) {
            return BackupParseResult.Failure("Unknown backup format '$format'")
        }

        val version = root["formatVersion"]?.jsonPrimitive?.intOrNull ?: 1
        if (version > BackupEnvelope.CURRENT_VERSION) {
            return BackupParseResult.Failure(
                "Backup was created by a newer app version (format $version). Update the app first."
            )
        }
        if (version < BackupEnvelope.MIN_SUPPORTED_VERSION) {
            return BackupParseResult.Failure("Backup format $version is no longer supported")
        }

        val migrations = mutableListOf<Int>()
        var current = root
        if (version < 2) {
            // v1 -> v2: explicit format string, secrets flag and theme schemes.
            current = buildJsonObject {
                root.forEach { (key, value) -> put(key, value) }
                put("format", BackupEnvelope.FORMAT)
                put("formatVersion", 2)
                put("includesSecrets", root["includesSecrets"]?.jsonPrimitive?.content ?: "false")
            }
            migrations += 1
        }

        val envelope = runCatching {
            NexusJson.instance.decodeFromJsonElement(BackupEnvelope.serializer(), current)
        }.getOrElse { throwable ->
            NexusLog.w("Backup", "Cannot decode backup: ${throwable.message}")
            return BackupParseResult.Failure("Backup structure is invalid: ${throwable.message}")
        }
        return BackupParseResult.Success(envelope, migrations)
    }
}

class BackupManager(
    private val settings: SettingsRepository,
    private val profiles: ProfileRepository,
    private val subscriptions: SubscriptionRepository,
    private val appVersion: String
) {

    suspend fun export(parts: Set<BackupPart>, includeSecrets: Boolean): String {
        val themeState = if (BackupPart.THEME in parts || BackupPart.THEME_SCHEMES in parts) {
            settings.currentTheme()
        } else {
            null
        }

        val envelope = BackupEnvelope(
            appVersion = appVersion,
            createdAtEpochMillis = System.currentTimeMillis(),
            includesSecrets = includeSecrets,
            settings = if (BackupPart.SETTINGS in parts) settings.currentAppSettings() else null,
            theme = if (BackupPart.THEME in parts) themeState?.active else null,
            dashboard = if (BackupPart.DASHBOARD in parts) settings.currentDashboard() else null,
            profiles = if (BackupPart.PROFILES in parts) {
                profiles.profiles.value.map { if (includeSecrets) it else stripSecrets(it) }
            } else {
                emptyList()
            },
            subscriptions = if (BackupPart.SUBSCRIPTIONS in parts) {
                val list = subscriptions.subscriptions.value
                if (includeSecrets) list else list.map { it.copy(url = it.url.substringBefore('?')) }
            } else {
                emptyList()
            },
            schemes = if (BackupPart.THEME_SCHEMES in parts) themeState?.savedSchemes.orEmpty() else emptyList()
        )

        return NexusJson.pretty.encodeToString(BackupEnvelope.serializer(), envelope)
    }

    suspend fun restore(raw: String, replaceProfiles: Boolean): BackupParseResult {
        val result = BackupMigrator.migrate(raw)
        if (result is BackupParseResult.Success) {
            val envelope = result.envelope
            val themeState = envelope.theme?.let {
                ThemeState(
                    active = it,
                    activeSchemeId = it.presetId,
                    savedSchemes = envelope.schemes
                )
            }
            settings.restore(envelope.settings, themeState, envelope.dashboard)
            if (envelope.profiles.isNotEmpty()) {
                profiles.importProfiles(envelope.profiles, replaceAll = replaceProfiles)
            }
            if (envelope.subscriptions.isNotEmpty()) {
                subscriptions.importAll(envelope.subscriptions)
            }
        }
        return result
    }

    /** Removes credentials while keeping the rest of the profile editable. */
    private fun stripSecrets(profile: Profile): Profile {
        val endpoint: ServerEndpoint = profile.config.endpoint
        val config: NexusConfig = profile.config.copy(
            endpoint = endpoint.copy(
                id = "",
                password = "",
                wireGuardPrivateKey = "",
                preSharedKey = ""
            ),
            rawJson = null
        )
        return profile.copy(
            config = config,
            sourceUrl = profile.sourceUrl.substringBefore('?')
        )
    }
}

/** Small helper for building an empty subscription list in tests. */
fun emptySubscription(): Subscription = Subscription(id = "", name = "", url = "")
