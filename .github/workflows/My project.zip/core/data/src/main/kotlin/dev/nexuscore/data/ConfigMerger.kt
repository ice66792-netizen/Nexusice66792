package dev.nexuscore.data

import dev.nexuscore.model.ConfigOverrides
import dev.nexuscore.model.EffectiveConfig
import dev.nexuscore.model.NexusConfig

/**
 * Precedence, highest last:
 *
 * 1. defaults (already baked into the data class defaults)
 * 2. values coming from the profile / subscription document
 * 3. user overrides stored per profile
 * 4. ephemeral session overrides (expert mode "tune for this session")
 */
object ConfigMerger {

    fun merge(
        base: NexusConfig,
        overrides: ConfigOverrides? = null,
        session: ConfigOverrides? = null
    ): EffectiveConfig {
        val o = overrides ?: ConfigOverrides()
        val s = if (o.isEmpty) session ?: ConfigOverrides() else session ?: ConfigOverrides()

        val merged = base.copy(
            transport = s.transport ?: o.transport ?: base.transport,
            security = s.security ?: o.security ?: base.security,
            mux = s.mux ?: o.mux ?: base.mux,
            network = s.network ?: o.network ?: base.network,
            dns = s.dns ?: o.dns ?: base.dns,
            routing = s.routing ?: o.routing ?: base.routing,
            performance = s.performance ?: o.performance ?: base.performance
        )

        val applied = ConfigOverrides(
            transport = o.transport ?: s.transport,
            security = o.security ?: s.security,
            mux = o.mux ?: s.mux,
            network = o.network ?: s.network,
            dns = o.dns ?: s.dns,
            routing = o.routing ?: s.routing,
            performance = o.performance ?: s.performance
        )
        return EffectiveConfig(
            config = merged,
            appliedOverrides = applied,
            usedRawJson = !merged.rawJson.isNullOrBlank()
        )
    }
}
