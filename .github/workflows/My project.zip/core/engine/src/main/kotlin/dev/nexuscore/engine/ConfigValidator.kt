package dev.nexuscore.engine

import dev.nexuscore.model.DnsMode
import dev.nexuscore.model.EngineCapabilities
import dev.nexuscore.model.EngineFeature
import dev.nexuscore.model.LogLevel
import dev.nexuscore.model.NexusConfig
import dev.nexuscore.model.ProxyProtocol
import dev.nexuscore.model.QueryStrategy
import dev.nexuscore.model.RuleAction
import dev.nexuscore.model.RuleKind
import dev.nexuscore.model.SecurityMode
import dev.nexuscore.model.TransportNetwork
import dev.nexuscore.model.ValidationIssue
import dev.nexuscore.model.ValidationReport
import dev.nexuscore.model.ValidationSeverity

/**
 * Pure validation. It never touches I/O so it is fully unit testable and can run
 * on every keystroke in the editor.
 */
class ConfigValidator {

    fun validate(config: NexusConfig, capabilities: EngineCapabilities): ValidationReport {
        val issues = mutableListOf<ValidationIssue>()

        fun error(code: String, message: String, path: String?) =
            issues.add(ValidationIssue(code, message, ValidationSeverity.ERROR, path))

        fun warn(code: String, message: String, path: String?) =
            issues.add(ValidationIssue(code, message, ValidationSeverity.WARNING, path))

        fun info(code: String, message: String, path: String?) =
            issues.add(ValidationIssue(code, message, ValidationSeverity.INFO, path))

        // --- core support ---
        if (!capabilities.supports(config.protocol)) {
            error(
                "protocol.unsupported",
                "Engine does not support ${config.protocol.name}. Choose another protocol or another engine.",
                "protocol"
            )
        }

        // --- endpoint ---
        val endpoint = config.endpoint
        if (endpoint.address.isBlank()) {
            error("endpoint.address.missing", "Server address is required.", "endpoint.address")
        } else if (!isHostnameOrIp(endpoint.address)) {
            error("endpoint.address.invalid", "Server address is not a valid host or IP.", "endpoint.address")
        }
        if (endpoint.port !in 1..65535) {
            error("endpoint.port.range", "Port must be between 1 and 65535.", "endpoint.port")
        }
        if (needsUserId(config.protocol) && endpoint.id.isBlank()) {
            error("endpoint.id.missing", "This protocol requires a user id / UUID.", "endpoint.id")
        }
        if (config.protocol == ProxyProtocol.TROJAN && endpoint.password.isBlank()) {
            error("endpoint.password.missing", "Trojan requires a password.", "endpoint.password")
        }
        if (config.protocol == ProxyProtocol.SHADOWSOCKS && endpoint.password.isBlank()) {
            error("endpoint.password.missing", "Shadowsocks requires a password.", "endpoint.password")
        }
        if (config.protocol == ProxyProtocol.WIREGUARD &&
            endpoint.wireGuardPrivateKey.isBlank()
        ) {
            error("endpoint.wgkey.missing", "WireGuard requires a private key.", "endpoint.wireGuardPrivateKey")
        }

        // --- security ---
        when (config.security.mode) {
            SecurityMode.REALITY -> {
                if (!capabilities.supports(EngineFeature.REALITY)) {
                    error("security.reality.unsupported", "Engine does not support REALITY.", "security.mode")
                }
                if (endpoint.publicKey.isBlank()) {
                    error("security.reality.key", "REALITY requires a public key.", "endpoint.publicKey")
                }
                if (config.security.serverName.isBlank()) {
                    error("security.reality.sni", "REALITY requires a server name (SNI).", "security.serverName")
                }
            }

            SecurityMode.TLS -> {
                if (!capabilities.supports(EngineFeature.TLS)) {
                    warn("security.tls.unsupported", "Engine reports no TLS support.", "security.mode")
                }
            }

            SecurityMode.NONE -> Unit
        }
        if (config.security.tlsFragmentEnabled && !capabilities.supports(EngineFeature.TLS_FRAGMENTATION)) {
            warn(
                "security.fragment.unsupported",
                "TLS fragmentation is not available for this engine and will be ignored.",
                "security.tlsFragmentEnabled"
            )
        }

        // --- transport ---
        if (config.transport.network == TransportNetwork.GRPC && config.transport.serviceName.isBlank()) {
            warn("transport.grpc.service", "gRPC usually requires a service name.", "transport.serviceName")
        }
        if (config.transport.network == TransportNetwork.WS && !config.transport.path.startsWith("/")) {
            error("transport.ws.path", "WebSocket path must start with '/'.", "transport.path")
        }

        // --- network ---
        if (config.network.mtu !in 576..9000) {
            error("network.mtu.range", "MTU must be between 576 and 9000.", "network.mtu")
        }
        if (!config.network.ipv4Enabled && !config.network.ipv6Enabled) {
            error("network.ip.none", "At least one IP family must stay enabled.", "network.ipv6Enabled")
        }
        if (config.network.socksPort !in 1024..65535) {
            error("network.socks.range", "Local SOCKS port must be 1024-65535.", "network.socksPort")
        }
        if (config.network.reconnect.maxAttempts !in 0..50) {
            warn("network.reconnect.range", "Reconnect attempts outside 0-50 are clamped.", "network.reconnect")
        }

        // --- dns ---
        if (config.dns.mode != DnsMode.SYSTEM && config.dns.servers.isEmpty()) {
            error("dns.servers.missing", "This DNS mode requires at least one server.", "dns.servers")
        }
        config.dns.servers.forEachIndexed { index, server ->
            val valid = when (config.dns.mode) {
                DnsMode.DNS_OVER_TLS -> server.startsWith("tls://") || server.startsWith("https://")
                DnsMode.DNS_OVER_HTTPS -> server.startsWith("https://")
                else -> isIp(server) || isHostnameOrIp(server)
            }
            if (!valid) {
                error(
                    "dns.server.invalid",
                    "DNS server '$server' does not match the selected mode.",
                    "dns.servers[$index]"
                )
            }
        }
        if (config.dns.queryStrategy == QueryStrategy.USE_IPV6 && !config.network.ipv6Enabled) {
            warn("dns.ipv6.disabled", "IPv6 DNS resolution is requested but IPv6 is disabled.", "dns.queryStrategy")
        }
        if (config.dns.mode != DnsMode.SYSTEM && !capabilities.supports(EngineFeature.DNS_OVERRIDE)) {
            error("dns.override.unsupported", "Engine cannot override DNS.", "dns.mode")
        }

        // --- routing ---
        validateRouting(
            config = config,
            capabilities = capabilities,
            error = { code, message, path -> error(code, message, path) },
            warn = { code, message, path -> warn(code, message, path) }
        )

        // --- performance / log ---
        val maxLevel = runCatching { LogLevel.valueOf(capabilities.maxLogLevel.uppercase()) }
            .getOrDefault(LogLevel.WARNING)
        if (config.performance.logLevel.ordinal > maxLevel.ordinal) {
            warn(
                "performance.loglevel.unsupported",
                "Requested log level is above '${capabilities.maxLogLevel}'; the engine will clamp it.",
                "performance.logLevel"
            )
        }
        if (config.performance.statsRefreshIntervalMs < 250) {
            warn("performance.stats.tooFrequent", "Stats refresh below 250 ms is ignored.", "performance.statsRefreshIntervalMs")
        }

        // --- native JSON import ---
        if (!config.rawJson.isNullOrBlank()) {
            if (!capabilities.supports(EngineFeature.FULL_JSON_IMPORT)) {
                error("config.rawjson.unsupported", "Engine cannot consume native JSON configurations.", "rawJson")
            } else {
                info("config.rawjson.present", "Native JSON is present; form values are used only as fallback.", "rawJson")
            }
        }

        return ValidationReport(issues)
    }

    private fun validateRouting(
        config: NexusConfig,
        capabilities: EngineCapabilities,
        error: (String, String, String?) -> Unit,
        warn: (String, String, String?) -> Unit
    ) {
        val rules = config.routing.rules
        if (rules.isEmpty()) return

        val seenIds = mutableSetOf<String>()
        rules.forEachIndexed { index, rule ->
            val path = "routing.rules[$index]"
            if (!seenIds.add(rule.id)) error("routing.rule.duplicate", "Duplicate rule id '${rule.id}'.", path)

            if (!rule.enabled) return@forEachIndexed

            if (rule.value.isBlank()) {
                error("routing.rule.empty", "Rule value is empty.", "$path.value")
                return@forEachIndexed
            }

            when (rule.kind) {
                RuleKind.DOMAIN_REGEX -> runCatching { Regex(rule.value) }.onFailure {
                    error("routing.rule.regex", "Invalid regular expression: ${it.message}", "$path.value")
                }

                RuleKind.IP_CIDR -> if (!isCidr(rule.value)) {
                    error("routing.rule.cidr", "'${rule.value}' is not a valid CIDR.", "$path.value")
                }

                RuleKind.PORT -> {
                    val port = rule.value.toIntOrNull()
                    if (port == null || port !in 1..65535) {
                        error("routing.rule.port", "Port must be 1-65535.", "$path.value")
                    }
                }

                RuleKind.NETWORK -> if (rule.value.lowercase() !in setOf("tcp", "udp", "tcp,udp")) {
                    error("routing.rule.network", "Network must be tcp, udp or tcp,udp.", "$path.value")
                }

                RuleKind.PROTOCOL -> if (rule.value.lowercase() !in setOf("http", "tls", "bittorrent", "quic")) {
                    warn("routing.rule.protocol", "Unusual protocol matcher '${rule.value}'.", "$path.value")
                }

                RuleKind.APP -> {
                    if (!capabilities.supports(EngineFeature.APP_ROUTING)) {
                        error(
                            "routing.rule.app.unsupported",
                            "Engine cannot match Android apps; disable this rule.",
                            path
                        )
                    } else if (!rule.value.matches(Regex("[A-Za-z0-9_.]+"))) {
                        error("routing.rule.app.package", "Use an Android package name.", "$path.value")
                    }
                }

                RuleKind.DOMAIN, RuleKind.DOMAIN_SUFFIX, RuleKind.DOMAIN_KEYWORD ->
                    if (rule.value.contains(' ')) {
                        error("routing.rule.domain.space", "Domain rules must not contain spaces.", "$path.value")
                    }
            }

            if (rule.action == RuleAction.BLOCK && index == rules.size - 1) {
                warn("routing.rule.block.last", "A trailing BLOCK rule can cut off every connection.", path)
            }
        }

        if (config.routing.rules.count { it.enabled } > 200) {
            warn("routing.rules.many", "More than 200 active rules may slow down DNS resolution.", "routing.rules")
        }
    }

    private fun needsUserId(protocol: ProxyProtocol): Boolean =
        protocol == ProxyProtocol.VLESS || protocol == ProxyProtocol.VMESS

    private fun isHostnameOrIp(value: String): Boolean =
        isIp(value) || value.matches(Regex("^[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?(\\.[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?)*$"))

    private fun isIp(value: String): Boolean {
        val v4 = value.split('.')
        if (v4.size == 4 && v4.all { p -> p.toIntOrNull()?.let { it in 0..255 } == true && p.none { c -> c == '+' } }) {
            return true
        }
        return value.contains(':') && value.matches(Regex("^[0-9a-fA-F:]+$")) && value.count { it == ':' } >= 2
    }

    private fun isCidr(value: String): Boolean {
        val parts = value.split('/')
        if (parts.size != 2) return false
        val prefix = parts[1].toIntOrNull() ?: return false
        val address = parts[0]
        return if (address.contains(':')) {
            isIp(address) && prefix in 0..128
        } else {
            isIp(address) && prefix in 0..32
        }
    }
}
