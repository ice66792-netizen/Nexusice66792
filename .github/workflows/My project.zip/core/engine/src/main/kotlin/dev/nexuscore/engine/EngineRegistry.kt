package dev.nexuscore.engine

import dev.nexuscore.model.EngineDescriptor
import dev.nexuscore.model.EngineId
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Holds the providers that are compiled into the APK.
 *
 * Adding a new engine means adding one module that implements [EngineProvider]
 * and registering it once in the application graph - no UI change is required.
 */
class EngineRegistry(private val providers: List<EngineProvider>) {

    private val byId: Map<EngineId, EngineProvider> = providers.associateBy { it.id }

    private val _selected = MutableStateFlow(
        providers.firstOrNull { it.id == EngineId.XRAY }?.id ?: providers.first().id
    )
    val selected: StateFlow<EngineId> = _selected.asStateFlow()

    val availableIds: List<EngineId> = providers.map { it.id }

    fun descriptors(): List<EngineDescriptor> = providers.map { it.descriptor() }

    fun provider(id: EngineId = _selected.value): EngineProvider? = byId[id]

    /** Returns false when the engine is not part of this build. */
    fun select(id: EngineId): Boolean {
        if (byId[id] == null) return false
        _selected.value = id
        return true
    }
}
