package dev.nexuscore.engine

import dev.nexuscore.model.EngineCapabilities
import dev.nexuscore.model.EngineDescriptor
import dev.nexuscore.model.EngineDiagnostics
import dev.nexuscore.model.EngineId
import dev.nexuscore.model.EngineSessionRequest
import dev.nexuscore.model.EngineState
import dev.nexuscore.model.EngineStats
import dev.nexuscore.model.NexusConfig
import dev.nexuscore.model.ValidationReport
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

/**
 * The only contract the UI and the connection manager know about.
 *
 * Implementations are responsible for *not* pretending to work: if the native
 * part is missing, [descriptor] must report [dev.nexuscore.model.EngineAvailability.Unavailable]
 * and [start] must fail with a concrete reason.
 */
interface EngineProvider {

    val id: EngineId

    /** Cheap, synchronous description. Safe to call from the UI thread. */
    fun descriptor(): EngineDescriptor

    fun capabilities(): EngineCapabilities

    /** Loads native libraries / checks the environment. Idempotent. */
    suspend fun initialize(): EngineInitResult

    suspend fun validate(config: NexusConfig): ValidationReport

    suspend fun start(request: EngineSessionRequest): EngineStartResult

    suspend fun stop()

    fun state(): StateFlow<EngineState>

    fun stats(): Flow<EngineStats>

    suspend fun diagnostics(): EngineDiagnostics

    /** Releases every resource. Called when the engine is swapped or the app dies. */
    suspend fun shutdown()
}

sealed interface EngineInitResult {
    data object Ready : EngineInitResult
    data class Failed(val reasons: List<String>) : EngineInitResult
}

sealed interface EngineStartResult {
    data object Started : EngineStartResult
    data class Rejected(val reasons: List<String>) : EngineStartResult
    data class Failed(val message: String, val detail: String? = null) : EngineStartResult
}

/**
 * UI facing tunnel control implemented by the app module (VpnService owner).
 * Feature modules depend on this interface only, never on the service.
 */
interface VpnControl {
    val state: StateFlow<EngineState>
    val stats: Flow<EngineStats>

    /** True while the system VPN consent dialog must be shown. */
    val awaitingPermission: StateFlow<Boolean>

    val lastError: StateFlow<String?>

    fun requestConnect()

    fun requestDisconnect()

    /** Called by the UI after the consent dialog returns. */
    fun onPermissionResult(granted: Boolean)

    /** Used by the service to surface failures that happen before engine.start. */
    fun reportError(message: String?, detail: String? = null)
}
