package dev.nexuscore.engine

import dev.nexuscore.model.NexusConfig
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

data class ConfigChange(
    val path: String,
    val before: String,
    val after: String
)

/**
 * Flattens two configurations into dotted paths and returns the differences.
 * Used by "preview changes" and by the expert mode config comparison.
 */
object ConfigDiff {

    private val json = Json { encodeDefaults = true; prettyPrint = false }

    fun diff(before: NexusConfig, after: NexusConfig): List<ConfigChange> {
        val left = flatten(json.encodeToJsonElement(NexusConfig.serializer(), before))
        val right = flatten(json.encodeToJsonElement(NexusConfig.serializer(), after))
        val keys = (left.keys + right.keys).sorted()
        return keys.mapNotNull { key ->
            val a = left[key] ?: "<absent>"
            val b = right[key] ?: "<absent>"
            if (a == b) null else ConfigChange(key, a, b)
        }
    }

    fun changedFields(before: NexusConfig, after: NexusConfig): List<String> =
        diff(before, after).map { it.path }

    private fun flatten(
        element: JsonElement,
        prefix: String = "",
        target: MutableMap<String, String> = LinkedHashMap()
    ): Map<String, String> {
        when (element) {
            is JsonObject -> element.entries.forEach { (key, value) ->
                val path = if (prefix.isEmpty()) key else "$prefix.$key"
                if (value is JsonObject) flatten(value, path, target)
                else if (value is JsonArray) flattenArray(value, path, target)
                else target[path] = render(value)
            }

            else -> target[prefix] = render(element)
        }
        return target
    }

    private fun flattenArray(array: JsonArray, path: String, target: MutableMap<String, String>) {
        if (array.isEmpty()) {
            target[path] = "[]"
            return
        }
        array.forEachIndexed { index, item ->
            val child = "$path[$index]"
            if (item is JsonObject) flatten(item, child, target) else target[child] = render(item)
        }
    }

    private fun render(element: JsonElement): String = when (element) {
        is JsonPrimitive -> element.content
        else -> element.toString()
    }
}
