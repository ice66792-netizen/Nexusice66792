# Интеграция сетевого ядра

## Что уже есть

* `core:engine` — контракт `EngineProvider` (init, descriptor, capabilities, validate, start/stop,
  state, stats, diagnostics, shutdown).
* `engine:xray` — `XrayConfigBuilder` (полноценная генерация Xray JSON из `NexusConfig`) и
  `XrayNativeBridge` — JNI-контракт.
* `app` — `VpnService`, который создаёт TUN и передаёт `fd` движку.

## Что нужно добавить, чтобы туннель реально работал

1. Собрать Xray-core (MPL-2.0) под Android и мост:

```bash
git clone https://github.com/XTLS/libXray && cd libXray
python3 build/main.py android        # требует Go + NDK
```

2. Реализовать 5 функций из `dev.nexuscore.engine.xray.XrayNativeBridge` (C ABI, `JNI_OnLoad`):

```c
jstring Java_dev_nexuscore_engine_xray_XrayNativeBridge_nativeInit(JNIEnv*, jclass, jstring dataDir, jstring configDir);
jstring Java_dev_nexuscore_engine_xray_XrayNativeBridge_nativeRun(JNIEnv*, jclass, jstring configJson, jint tunFd, jint socksPort);
jstring Java_dev_nexuscore_engine_xray_XrayNativeBridge_nativeStop(JNIEnv*, jclass);
jstring Java_dev_nexuscore_engine_xray_XrayNativeBridge_nativeStats(JNIEnv*, jclass);
jstring Java_dev_nexuscore_engine_xray_XrayNativeBridge_nativeVersion(JNIEnv*, jclass);
```

Возврат `NULL` = успех, иначе — текст ошибки (он попадает в диагностику как есть).
`nativeStats` возвращает JSON `{"uplink":123,"downlink":456,"connections":3}` в байтах.

3. Положить `.so` в `engine/xray/src/main/jniLibs/arm64-v8a/libnexusxray.so` (и при необходимости
   `armeabi-v7a`, `x86_64`).

4. Пересобрать: `./gradlew :app:assembleDebug`. `XrayEngineProvider.descriptor()` начнёт
   возвращать `Available` и реальную версию ядра.

## Мост: важные детали

* Xray запускается с SOCKS-inbound на `127.0.0.1:<socksPort>`; TUN → SOCKS обрабатывает мост
  (tun2socks внутри того же `.so`) — иначе пакеты из TUN некуда девать.
* `nativeInit` вызывается один раз; `nativeStop` должен дождаться завершения горутин.
* Все исключения моста ловятся в Kotlin; состояние `Connected` ставится **только** после успешного
  `nativeRun`.
* Секреты не логируются: мост получает готовый JSON, а `SecretRedactor` маскирует логи.

## Почему libXray не вкомпилирован

Репозиторий не содержит бинарных артефактов и не собирает NDK-код в текущем окружении.
Это осознанное ограничение: адаптер компилируется и работает всегда, но без `.so` он обязан
сообщать `Unavailable` — приложение не имитирует подключение.
