-keepclasseswithmembernames class dev.nexuscore.engine.xray.XrayNativeBridge {
    native <methods>;
}
-keep class kotlinx.serialization.** { *; }
-keepclassmembers class **$$serializer { *; }
-keepclassmembers @kotlinx.serialization.Serializable class * { *; }
