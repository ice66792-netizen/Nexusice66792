package dev.nexuscore.app

import androidx.compose.ui.test.assertExists
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import dev.nexuscore.design.NexusTheme
import dev.nexuscore.feature.dashboard.DashboardScreen
import dev.nexuscore.feature.dashboard.DashboardUiState
import dev.nexuscore.model.ThemeSettings
import org.junit.Rule
import org.junit.Test

class DashboardUiTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun dashboardRendersConnectButton() {
        composeRule.setContent {
            NexusTheme(ThemeSettings()) {
                DashboardScreen(
                    state = DashboardUiState(),
                    onToggleConnection = {},
                    onOpenProfiles = {},
                    onOpenSettings = {},
                    onQuickAction = {}
                )
            }
        }
        composeRule.onNodeWithTag("dashboard").assertExists()
        composeRule.onNodeWithTag("connect_button").assertExists()
    }
}
