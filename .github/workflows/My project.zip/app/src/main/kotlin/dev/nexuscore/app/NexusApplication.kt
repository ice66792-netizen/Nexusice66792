package dev.nexuscore.app

import android.app.Application
import dev.nexuscore.common.NexusLog
import dev.nexuscore.data.NexusServices
import dev.nexuscore.engine.mock.MockEngineProvider
import dev.nexuscore.engine.xray.XrayEngineProvider
import dev.nexuscore.app.vpn.VpnControlImpl

class NexusApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        NexusLog.minLevel = 1
        NexusServices.initialize(
            context = this,
            appVersion = BuildConfig.VERSION_NAME,
            engineProviders = listOf(
                XrayEngineProvider(this),
                MockEngineProvider()
            )
        )
        NexusServices.attachControl(
            VpnControlImpl(
                context = this,
                settings = NexusServices.settings,
                profiles = NexusServices.profiles,
                engines = NexusServices.engines
            )
        )
        NexusLog.i("App", "Nexus Core ${BuildConfig.VERSION_NAME} initialised")
    }
}
