package dev.nexuscore.app.vpn

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import dev.nexuscore.app.MainActivity
import dev.nexuscore.app.R
import dev.nexuscore.common.NexusLog
import dev.nexuscore.data.NexusServices
import dev.nexuscore.data.ConfigMerger
import dev.nexuscore.engine.EngineStartResult
import dev.nexuscore.model.EngineSessionRequest
import dev.nexuscore.model.NexusConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Owns the TUN interface. The engine receives the file descriptor and is fully
 * responsible for the tunnel; if it reports that the tunnel is not running, the
 * UI shows the failure instead of a fake "connected" state.
 */
class NexusVpnService : VpnService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tunnel: ParcelFileDescriptor? = null
    private var notificationManager: NotificationManager? = null

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager?.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                getString(R.string.vpn_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = getString(R.string.vpn_channel_description) }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startTunnel()
            ACTION_STOP -> stopTunnel()
            else -> NexusLog.w("VpnService", "Unknown action ${intent?.action}")
        }
        return START_NOT_STICKY
    }

    override fun onRevoke() {
        NexusLog.w("VpnService", "VPN permission revoked by the system")
        control()?.reportError("VPN permission was revoked")
        stopTunnel()
    }

    override fun onDestroy() {
        scope.launch { runCatching { NexusServices.engines.provider()?.stop() } }
        closeTunnel()
        scope.cancel()
        super.onDestroy()
    }

    private fun startTunnel() {
        if (tunnel != null) return
        scope.launch {
            val control = control()
            val appSettings = NexusServices.settings.currentAppSettings()
            val profile = NexusServices.profiles.find(appSettings.activeProfileId)
                ?: NexusServices.profiles.profiles.value.firstOrNull()
            if (profile == null) {
                control?.reportError("No profile selected")
                stopSelf()
                return@launch
            }
            val provider = NexusServices.engines.provider(profile.engineId)
            if (provider == null) {
                control?.reportError("Engine is not available")
                stopSelf()
                return@launch
            }

            val effective = ConfigMerger.merge(profile.config, profile.overrides).config
            val report = provider.validate(effective)
            if (!report.isValid) {
                control?.reportError(
                    "Configuration is invalid",
                    report.errors.firstOrNull()?.message
                )
                stopSelf()
                return@launch
            }

            val descriptor = try {
                buildTun(effective)
            } catch (t: Throwable) {
                NexusLog.e("VpnService", "establish() failed", t)
                control?.reportError("Android refused to create the tunnel", t.message)
                stopSelf()
                return@launch
            }
            tunnel = descriptor

            when (val result = provider.start(
                EngineSessionRequest(
                    config = effective,
                    tunFileDescriptor = descriptor.fd,
                    dnsServers = effective.dns.servers,
                    socksPort = effective.network.socksPort
                )
            )) {
                is EngineStartResult.Started -> {
                    control?.reportError(null)
                    showNotification(profile.name)
                    NexusLog.i("VpnService", "Tunnel started for '${profile.name}'")
                }

                is EngineStartResult.Rejected -> {
                    closeTunnel()
                    control?.reportError("Engine rejected the configuration", result.reasons.joinToString("\n"))
                    stopSelf()
                }

                is EngineStartResult.Failed -> {
                    closeTunnel()
                    control?.reportError(result.message, result.detail)
                    stopSelf()
                }
            }
        }
    }

    private fun stopTunnel() {
        scope.launch {
            NexusServices.engines.provider()?.stop()
            closeTunnel()
            notificationManager?.cancel(NOTIFICATION_ID)
            stopSelf()
        }
    }

    private fun buildTun(config: NexusConfig): ParcelFileDescriptor {
        val builder = Builder()
            .setSession("Nexus Core")
            .setMtu(config.network.mtu)
            .addAddress("10.10.0.2", 32)
            .setBlocking(true)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            builder.setMetered(false)
        }
        if (config.network.ipv4Enabled) {
            builder.addRoute("0.0.0.0", 0)
        }
        if (config.network.ipv6Enabled) {
            builder.addAddress("fd00::2", 128)
            builder.addRoute("::", 0)
        }

        val dnsServers = config.dns.servers.mapNotNull { server ->
            server.substringAfter("://").substringBefore('/').substringBefore(':').takeIf { it.isNotBlank() }
        }
        if (dnsServers.isEmpty()) {
            builder.addDnsServer("1.1.1.1")
        } else {
            dnsServers.take(2).forEach { server -> runCatching { builder.addDnsServer(server) } }
        }

        return builder.establish() ?: error("establish() returned null")
    }

    private fun closeTunnel() {
        runCatching { tunnel?.close() }
        tunnel = null
        notificationManager?.cancel(NOTIFICATION_ID)
    }

    private fun showNotification(profileName: String) {
        val intent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(getString(R.string.vpn_notification_title))
            .setContentText(profileName)
            .setOngoing(true)
            .setContentIntent(intent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        runCatching { notificationManager?.notify(NOTIFICATION_ID, notification) }
    }

    private fun control(): VpnControlImpl? = NexusServices.control as? VpnControlImpl

    companion object {
        const val ACTION_START = "dev.nexuscore.action.START"
        const val ACTION_STOP = "dev.nexuscore.action.STOP"
        private const val CHANNEL_ID = "vpn_status"
        private const val NOTIFICATION_ID = 1001
    }
}
