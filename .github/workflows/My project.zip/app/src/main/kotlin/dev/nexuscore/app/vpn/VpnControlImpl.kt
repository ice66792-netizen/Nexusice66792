package dev.nexuscore.app.vpn

import android.content.Context
import android.content.Intent
import android.net.VpnService
import dev.nexuscore.app.R
import dev.nexuscore.data.ProfileRepository
import dev.nexuscore.data.SettingsRepository
import dev.nexuscore.engine.EngineRegistry
import dev.nexuscore.engine.VpnControl
import dev.nexuscore.model.EngineAvailability
import dev.nexuscore.model.EngineState
import dev.nexuscore.model.EngineStats
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn

/**
 * Drives the VpnService and mirrors whichever engine is selected.
 * The state shown in the UI always comes from the engine itself.
 */
class VpnControlImpl(
    private val context: Context,
    private val settings: SettingsRepository,
    private val profiles: ProfileRepository,
    private val engines: EngineRegistry
) : VpnControl {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override val state: StateFlow<EngineState> = engines.selected.flatMapLatest { id ->
        engines.provider(id)?.state() ?: flowOf(
            EngineState.Unavailable(listOf("Engine '${id.key}' is not registered in this build"))
        )
    }.stateIn(scope, SharingStarted.Eagerly, EngineState.Idle)

    override val stats: Flow<EngineStats> = engines.selected.flatMapLatest { id ->
        engines.provider(id)?.stats() ?: flowOf(EngineStats())
    }

    override val awaitingPermission = MutableStateFlow(false)

    override val lastError = MutableStateFlow<String?>(null)

    override fun requestConnect() {
        val provider = engines.provider()
        if (provider == null) {
            reportError("No engine selected")
            return
        }
        val descriptor = provider.descriptor()
        if (!descriptor.isAvailable) {
            val reasons = (descriptor.availability as? EngineAvailability.Unavailable)?.reasons.orEmpty()
            reportError("Engine is unavailable", reasons.joinToString("\n").ifBlank { null })
            return
        }
        val prepareIntent = VpnService.prepare(context)
        if (prepareIntent != null) {
            awaitingPermission.value = true
        } else {
            startService()
        }
    }

    override fun onPermissionResult(granted: Boolean) {
        awaitingPermission.value = false
        if (granted) {
            startService()
        } else {
            reportError(context.getString(R.string.vpn_permission_denied))
        }
    }

    override fun requestDisconnect() {
        context.startService(Intent(context, NexusVpnService::class.java).setAction(NexusVpnService.ACTION_STOP))
    }

    override fun reportError(message: String?, detail: String?) {
        lastError.value = listOfNotNull(message, detail).joinToString("\n").ifBlank { null }
    }

    private fun startService() {
        lastError.value = null
        context.startService(Intent(context, NexusVpnService::class.java).setAction(NexusVpnService.ACTION_START))
    }
}
