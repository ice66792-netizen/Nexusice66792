package dev.nexuscore.app.ui

import android.app.Activity
import android.content.Context
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BugReport
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import dev.nexuscore.app.BuildConfig
import dev.nexuscore.data.NexusServices
import dev.nexuscore.data.SettingsRepository
import dev.nexuscore.design.NexusTheme
import dev.nexuscore.design.nexusViewModel
import dev.nexuscore.feature.dashboard.DashboardScreen
import dev.nexuscore.feature.dashboard.DashboardViewModel
import dev.nexuscore.feature.personalization.CustomizationScreen
import dev.nexuscore.feature.personalization.CustomizationViewModel
import dev.nexuscore.feature.profiles.ProfileEditorScreen
import dev.nexuscore.feature.profiles.ProfilesScreen
import dev.nexuscore.feature.profiles.ProfilesViewModel
import dev.nexuscore.feature.profiles.SubscriptionsScreen
import dev.nexuscore.feature.settings.CoreSettingsScreen
import dev.nexuscore.feature.settings.CoreSettingsViewModel
import dev.nexuscore.feature.system.SystemScreen
import dev.nexuscore.feature.system.SystemViewModel
import dev.nexuscore.model.BackupPart
import dev.nexuscore.model.QuickAction

private data class Destination(
    val route: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

private val destinations = listOf(
    Destination("dashboard", "Home", Icons.Outlined.Home),
    Destination("profiles", "Profiles", Icons.Outlined.Layers),
    Destination("core", "Core", Icons.Outlined.Tune),
    Destination("style", "Look", Icons.Outlined.Palette),
    Destination("system", "System", Icons.Outlined.BugReport)
)

@Composable
fun NexusRoot() {
    val context = LocalContext.current
    val settings = NexusServices.settings
    val control = NexusServices.control

    val themeState by settings.themeState.collectAsStateWithLifecycle(
        initialValue = SettingsRepository.defaultThemeState()
    )

    val navController = rememberNavController()
    val snackbar = remember { SnackbarHostState() }

    val awaitingPermission by control.awaitingPermission.collectAsStateWithLifecycle()
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        control.onPermissionResult(result.resultCode == Activity.RESULT_OK)
    }

    LaunchedEffect(awaitingPermission) {
        if (!awaitingPermission) return@LaunchedEffect
        val intent = VpnService.prepare(context)
        if (intent != null) {
            permissionLauncher.launch(intent)
        } else {
            control.onPermissionResult(true)
        }
    }

    NexusTheme(theme = themeState.active) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = { NexusBottomBar(navController) }
        ) { padding ->
            NexusNavHost(
                navController = navController,
                context = context,
                modifier = Modifier.fillMaxSize().padding(padding)
            )
        }
    }
}

@Composable
private fun NexusBottomBar(navController: NavHostController) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val current = backStackEntry?.destination?.route
    NavigationBar {
        destinations.forEach { destination ->
            NavigationBarItem(
                selected = current == destination.route,
                onClick = {
                    if (current != destination.route) {
                        navController.navigate(destination.route) {
                            popUpTo("dashboard") { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                icon = { Icon(destination.icon, contentDescription = destination.label) },
                label = { Text(destination.label) }
            )
        }
    }
}

@Composable
private fun NexusNavHost(
    navController: NavHostController,
    context: Context,
    modifier: Modifier = Modifier
) {
    val dashboardVm = nexusViewModel {
        DashboardViewModel(
            NexusServices.settings,
            NexusServices.profiles,
            NexusServices.engines,
            NexusServices.control
        )
    }
    val profilesVm = nexusViewModel {
        ProfilesViewModel(
            NexusServices.profiles,
            NexusServices.settings,
            NexusServices.engines,
            NexusServices.subscriptions
        )
    }
    val coreVm = nexusViewModel {
        CoreSettingsViewModel(NexusServices.profiles, NexusServices.settings, NexusServices.engines)
    }
    val styleVm = nexusViewModel { CustomizationViewModel(NexusServices.settings) }
    val systemVm = nexusViewModel {
        SystemViewModel(
            NexusServices.settings,
            NexusServices.profiles,
            NexusServices.engines,
            NexusServices.backups,
            NexusServices.control,
            BuildConfig.VERSION_NAME
        )
    }

    NavHost(navController = navController, startDestination = "dashboard", modifier = modifier) {
        composable("dashboard") {
            val state by dashboardVm.state.collectAsStateWithLifecycle()
            DashboardScreen(
                state = state,
                onToggleConnection = dashboardVm::toggleConnection,
                onOpenProfiles = { navController.navigate("profiles") },
                onOpenSettings = { navController.navigate("core") },
                onQuickAction = { action ->
                    when (action) {
                        QuickAction.CONNECT -> dashboardVm.toggleConnection()
                        QuickAction.PROFILES -> navController.navigate("profiles")
                        QuickAction.ROUTING, QuickAction.DNS -> navController.navigate("core")
                        QuickAction.DIAGNOSTICS, QuickAction.BACKUP -> navController.navigate("system")
                    }
                }
            )
        }

        composable("profiles") {
            val list by profilesVm.list.collectAsStateWithLifecycle()
            val active by profilesVm.activeId.collectAsStateWithLifecycle()
            val subscriptions by profilesVm.subscriptionList.collectAsStateWithLifecycle()
            val importText by profilesVm.importText.collectAsStateWithLifecycle()
            val message by profilesVm.message.collectAsStateWithLifecycle()
            ProfilesScreen(
                profiles = list,
                activeId = active,
                subscriptions = subscriptions,
                importText = importText,
                message = message,
                onImportTextChange = profilesVm::onImportTextChange,
                onImport = {
                    profilesVm.importFromLink()
                    navController.navigate("editor")
                },
                onSelect = profilesVm::select,
                onCreate = {
                    profilesVm.createNew()
                    navController.navigate("editor")
                },
                onEdit = { profile ->
                    profilesVm.openEditor(profile)
                    navController.navigate("editor")
                },
                onDuplicate = profilesVm::duplicate,
                onDelete = profilesVm::delete,
                onAddSubscription = profilesVm::addSubscription,
                onRefreshSubscription = profilesVm::refreshSubscription,
                onRemoveSubscription = profilesVm::removeSubscription,
                onOpenSubscriptions = { navController.navigate("subs") }
            )
        }

        composable("editor") {
            val editor by profilesVm.editor.collectAsStateWithLifecycle()
            ProfileEditorScreen(
                state = editor,
                onClose = {
                    profilesVm.closeEditor()
                    navController.popBackStack()
                },
                onUpdateName = { name -> profilesVm.updateDraft { it.copy(name = name) } },
                onUpdateDescription = { text -> profilesVm.updateDraft { it.copy(description = text) } },
                onProtocol = { protocol -> profilesVm.updateConfig { it.copy(protocol = protocol) } },
                onEndpoint = { transform -> profilesVm.updateConfig { it.copy(endpoint = transform(it.endpoint)) } },
                onTransport = { transform -> profilesVm.updateConfig { it.copy(transport = transform(it.transport)) } },
                onSecurity = { transform -> profilesVm.updateConfig { it.copy(security = transform(it.security)) } },
                onRawJson = { raw -> profilesVm.updateConfig { it.copy(rawJson = raw.ifBlank { null }) } },
                onClearRawJson = profilesVm::clearRawJson,
                onResetOverrides = profilesVm::resetOverrides,
                onValidate = profilesVm::validateDraft,
                onSave = profilesVm::save
            )
        }

        composable("subs") {
            val subscriptions by profilesVm.subscriptionList.collectAsStateWithLifecycle()
            SubscriptionsScreen(
                subscriptions = subscriptions,
                onAdd = profilesVm::addSubscription,
                onRefresh = profilesVm::refreshSubscription,
                onRemove = profilesVm::removeSubscription,
                onBack = { navController.popBackStack() }
            )
        }

        composable("core") {
            val state by coreVm.state.collectAsStateWithLifecycle()
            CoreSettingsScreen(
                state = state,
                onNetwork = coreVm::updateNetwork,
                onDns = coreVm::updateDns,
                onPerformance = coreVm::updatePerformance,
                onAddRule = coreVm::addRule,
                onRemoveRule = coreVm::removeRule,
                onMoveRule = coreVm::moveRule,
                onToggleRule = coreVm::setRuleEnabled,
                onSelectEngine = coreVm::selectEngine,
                onValidate = coreVm::validateNow,
                onResetOverrides = coreVm::resetOverrides,
                onDismissMessage = coreVm::dismissMessage
            )
        }

        composable("style") {
            val state by styleVm.state.collectAsStateWithLifecycle()
            CustomizationScreen(
                state = state,
                onChangeTheme = styleVm::updateTheme,
                onApplyScheme = styleVm::applyScheme,
                onSaveScheme = styleVm::saveScheme,
                onDeleteScheme = styleVm::deleteScheme,
                onToggleBlock = styleVm::toggleBlock,
                onMoveBlock = styleVm::moveBlock,
                onToggleQuickAction = styleVm::toggleQuickAction,
                onDashboard = styleVm::updateDashboard,
                onExportScheme = styleVm::exportActiveScheme,
                onImportScheme = styleVm::importScheme,
                onDismissMessage = styleVm::dismissMessage
            )
        }

        composable("system") {
            val state by systemVm.state.collectAsStateWithLifecycle()
            val redact by systemVm.redactLogs.collectAsStateWithLifecycle()
            LaunchedEffect(Unit) { systemVm.refreshDiagnostics() }
            SystemScreen(
                state = state,
                appVersion = BuildConfig.VERSION_NAME,
                redactLogs = redact,
                onRefresh = systemVm::refreshDiagnostics,
                onRedactionChange = systemVm::setRedaction,
                onExportReport = systemVm::exportReport,
                onExportBackup = { parts: Set<BackupPart>, secrets: Boolean ->
                    systemVm.exportBackup(parts, secrets)
                },
                onImportBackup = { raw: String, replace: Boolean ->
                    systemVm.importBackup(raw, replace)
                },
                onDismissMessage = systemVm::dismissMessage
            )
        }
    }
}
