package dev.nexuscore.engine.mock

import dev.nexuscore.common.NexusLog
import dev.nexuscore.engine.ConfigValidator
import dev.nexuscore.engine.EngineInitResult
import dev.nexuscore.engine.EngineProvider
import dev.nexuscore.engine.EngineStartResult
import dev.nexuscore.model.EngineAvailability
import dev.nexuscore.model.EngineCapabilities
import dev.nexuscore.model.EngineDescriptor
import dev.nexuscore.model.EngineDiagnostics
import dev.nexuscore.model.EngineFeature
import dev.nexuscore.model.EngineId
import dev.nexuscore.model.EngineSessionRequest
import dev.nexuscore.model.EngineState
import dev.nexuscore.model.EngineStats
import dev.nexuscore.model.NexusConfig
import dev.nexuscore.model.ProxyProtocol
import dev.nexuscore.model.ValidationReport
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

/**
 * EXPLICIT SIMULATION ENGINE.
 *
 * It never opens a socket and never routes a packet. It exists so the whole UI,
 * state machine and test suite can be exercised on a build without native
 * artifacts. The descriptor reports [isSimulated] = true and the UI renders a
 * permanent "simulation" banner whenever it is selected.
 */
class MockEngineProvider(
    private val validator: ConfigValidator = ConfigValidator()
) : EngineProvider {

    override val id: EngineId = EngineId.MOCK

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _state = MutableStateFlow<EngineState>(EngineState.Idle)
    override fun state(): StateFlow<EngineState> = _state.asStateFlow()

    private val _stats = MutableStateFlow(EngineStats())
    override fun stats(): Flow<EngineStats> = _stats

    private var ticker: Job? = null
    private var lastError: String? = null
    private var initialized = false

    private val capabilities = EngineCapabilities(
        features = setOf(
            EngineFeature.VLESS_REALITY,
            EngineFeature.VMESS,
            EngineFeature.TROJAN,
            EngineFeature.SHADOWSOCKS,
            EngineFeature.SOCKS,
            EngineFeature.TLS,
            EngineFeature.REALITY,
            EngineFeature.MUX,
            EngineFeature.FULL_JSON_IMPORT,
            EngineFeature.DOMAIN_ROUTING,
            EngineFeature.IP_ROUTING,
            EngineFeature.PORT_ROUTING,
            EngineFeature.DNS_OVERRIDE,
            EngineFeature.TUN_MTU,
            EngineFeature.TRAFFIC_STATS,
            EngineFeature.LOG_LEVEL_CONTROL
        ),
        protocols = setOf(
            ProxyProtocol.VLESS,
            ProxyProtocol.VMESS,
            ProxyProtocol.TROJAN,
            ProxyProtocol.SHADOWSOCKS,
            ProxyProtocol.SOCKS
        ),
        maxLogLevel = "debug",
        notes = listOf("Simulation only - no traffic leaves the device.")
    )

    override fun descriptor(): EngineDescriptor = EngineDescriptor(
        id = id,
        displayName = "Simulation engine",
        version = "1.0.0-mock",
        buildInfo = "No native code",
        isSimulated = true,
        availability = EngineAvailability.Available,
        capabilities = capabilities
    )

    override fun capabilities(): EngineCapabilities = capabilities

    override suspend fun initialize(): EngineInitResult {
        initialized = true
        return EngineInitResult.Ready
    }

    override suspend fun validate(config: NexusConfig): ValidationReport = withContext(Dispatchers.Default) {
        validator.validate(config, capabilities)
    }

    override suspend fun start(request: EngineSessionRequest): EngineStartResult {
        if (!initialized) initialize()
        val report = validate(request.config)
        if (!report.isValid) {
            lastError = report.errors.first().message
            _state.value = EngineState.Failed(report.errors.first().message, recoverable = true)
            return EngineStartResult.Rejected(report.errors.map { it.message })
        }

        _state.value = EngineState.Connecting(1)
        delay(400)
        _state.value = EngineState.Connected(System.currentTimeMillis())
        startTicker()
        NexusLog.i("MockEngine", "Simulated session started on ${request.config.endpoint.address}")
        return EngineStartResult.Started
    }

    override suspend fun stop() {
        ticker?.cancel()
        ticker = null
        _state.value = EngineState.Disconnecting
        delay(150)
        _state.value = EngineState.Idle
        _stats.value = EngineStats()
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = scope.launch {
            var up = 0L
            var down = 0L
            while (true) {
                delay(1_000)
                val upRate = Random.nextLong(2_000, 90_000)
                val downRate = Random.nextLong(8_000, 900_000)
                up += upRate / 8
                down += downRate / 8
                _stats.value = EngineStats(
                    uplinkBytes = up,
                    downlinkBytes = down,
                    uplinkRateBps = upRate,
                    downlinkRateBps = downRate,
                    activeConnections = Random.nextInt(3, 24),
                    latencyMs = Random.nextLong(18, 90),
                    sampledAtEpochMillis = System.currentTimeMillis()
                )
            }
        }
    }

    override suspend fun diagnostics(): EngineDiagnostics = EngineDiagnostics(
        engineId = id,
        engineVersion = descriptor().version,
        state = _state.value,
        lastError = lastError,
        logTail = NexusLog.snapshot().takeLast(100),
        extra = mapOf(
            "simulated" to "true",
            "note" to "No packets are routed by this engine."
        )
    )

    override suspend fun shutdown() {
        ticker?.cancel()
        ticker = null
        _state.value = EngineState.Idle
        initialized = false
    }
}
