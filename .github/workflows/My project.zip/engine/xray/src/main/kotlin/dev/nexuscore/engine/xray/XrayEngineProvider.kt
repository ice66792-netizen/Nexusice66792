package dev.nexuscore.engine.xray

import android.content.Context
import dev.nexuscore.common.NexusLog
import dev.nexuscore.engine.ConfigValidator
import dev.nexuscore.engine.EngineInitResult
import dev.nexuscore.engine.EngineProvider
import dev.nexuscore.engine.EngineStartResult
import dev.nexuscore.model.EngineAvailability
import dev.nexuscore.model.EngineCapabilities
import dev.nexuscore.model.EngineDescriptor
import dev.nexuscore.model.EngineDiagnostics
import dev.nexuscore.model.EngineFeature
import dev.nexuscore.model.EngineId
import dev.nexuscore.model.EngineSessionRequest
import dev.nexuscore.model.EngineState
import dev.nexuscore.model.EngineStats
import dev.nexuscore.model.NexusConfig
import dev.nexuscore.model.ProxyProtocol
import dev.nexuscore.model.ValidationIssue
import dev.nexuscore.model.ValidationReport
import dev.nexuscore.model.ValidationSeverity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import java.io.File

/**
 * Xray-core backed engine.
 *
 * Reality check, by design: this class compiles and runs in every build, but it
 * only *works* when the native bridge (`libnexusxray.so`) is present. Otherwise
 * [descriptor] advertises [EngineAvailability.Unavailable] with the exact
 * missing piece, the UI disables the connect button, and [start] fails with a
 * concrete error. There is no fallback to a fake tunnel.
 */
class XrayEngineProvider(
    private val appContext: Context,
    private val validator: ConfigValidator = ConfigValidator(),
    private val builder: XrayConfigBuilder = XrayConfigBuilder()
) : EngineProvider {

    override val id: EngineId = EngineId.XRAY

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json = Json { ignoreUnknownKeys = true }

    private val _state = MutableStateFlow<EngineState>(EngineState.Idle)
    override fun state(): StateFlow<EngineState> = _state.asStateFlow()

    private val _stats = MutableStateFlow(EngineStats())
    override fun stats(): Flow<EngineStats> = _stats

    private var statsJob: Job? = null
    private var lastError: String? = null
    private var prepared = false
    private var running = false

    private val capabilities: EngineCapabilities = EngineCapabilities(
        features = setOf(
            EngineFeature.VLESS_REALITY,
            EngineFeature.VMESS,
            EngineFeature.TROJAN,
            EngineFeature.SHADOWSOCKS,
            EngineFeature.SOCKS,
            EngineFeature.WIREGUARD,
            EngineFeature.TLS,
            EngineFeature.REALITY,
            EngineFeature.MUX,
            EngineFeature.FULL_JSON_IMPORT,
            EngineFeature.DOMAIN_ROUTING,
            EngineFeature.IP_ROUTING,
            EngineFeature.PORT_ROUTING,
            EngineFeature.DNS_OVERRIDE,
            EngineFeature.TUN_MTU,
            EngineFeature.TRAFFIC_STATS,
            EngineFeature.LOG_LEVEL_CONTROL
        ),
        protocols = setOf(
            ProxyProtocol.VLESS,
            ProxyProtocol.VMESS,
            ProxyProtocol.TROJAN,
            ProxyProtocol.SHADOWSOCKS,
            ProxyProtocol.SOCKS,
            ProxyProtocol.WIREGUARD
        ),
        maxLogLevel = "debug",
        notes = listOf(
            "Per-app routing is not exposed by Xray-core on Android.",
            "TLS fragmentation is applied by the app layer only when the bridge supports it."
        )
    )

    override fun descriptor(): EngineDescriptor {
        val availability = if (XrayNativeBridge.isLoaded) {
            EngineAvailability.Available
        } else {
            EngineAvailability.Unavailable(
                listOf(
                    XrayNativeBridge.loadError
                        ?: "Xray native bridge is not available in this build."
                )
            )
        }
        return EngineDescriptor(
            id = id,
            displayName = "Xray-core",
            version = XrayNativeBridge.versionOrNull() ?: "not loaded",
            buildInfo = "Nexus Xray bridge (JNI), core version reported at runtime",
            isSimulated = false,
            availability = availability,
            capabilities = capabilities
        )
    }

    override fun capabilities(): EngineCapabilities = capabilities

    override suspend fun initialize(): EngineInitResult = withContext(Dispatchers.IO) {
        if (!XrayNativeBridge.isLoaded) {
            return@withContext EngineInitResult.Failed(descriptor().availability.let {
                (it as? EngineAvailability.Unavailable)?.reasons ?: emptyList()
            })
        }
        if (prepared) return@withContext EngineInitResult.Ready
        val dataDir = File(appContext.filesDir, "xray").apply { mkdirs() }
        val configDir = File(dataDir, "config").apply { mkdirs() }
        val error = runCatching {
            XrayNativeBridge.nativeInit(dataDir.absolutePath, configDir.absolutePath)
        }.getOrElse { it.message ?: it.javaClass.simpleName }
        if (error != null) {
            lastError = error
            NexusLog.e("XrayEngine", "nativeInit failed: $error")
            return@withContext EngineInitResult.Failed(listOf(error))
        }
        prepared = true
        EngineInitResult.Ready
    }

    override suspend fun validate(config: NexusConfig): ValidationReport = withContext(Dispatchers.Default) {
        val issues = validator.validate(config, capabilities).issues.toMutableList()
        if (!config.rawJson.isNullOrBlank()) {
            issues += validateRawJson(config.rawJson)
        }
        ValidationReport(issues)
    }

    private fun validateRawJson(raw: String): List<ValidationIssue> {
        val issues = mutableListOf<ValidationIssue>()
        val parsed = runCatching { json.parseToJsonElement(raw).jsonObject }.getOrNull()
        if (parsed == null) {
            issues += ValidationIssue(
                code = "rawjson.syntax",
                message = "Imported JSON is not a valid object.",
                severity = ValidationSeverity.ERROR,
                path = "rawJson"
            )
            return issues
        }
        if (!parsed.containsKey("outbounds")) {
            issues += ValidationIssue(
                code = "rawjson.outbounds",
                message = "Imported JSON has no 'outbounds' section.",
                severity = ValidationSeverity.ERROR,
                path = "rawJson.outbounds"
            )
        }
        val inbounds = runCatching { parsed["inbounds"]?.jsonObject }.getOrNull()
        if (inbounds != null) {
            issues += ValidationIssue(
                code = "rawjson.inbounds",
                message = "Native 'inbounds' are ignored: the app provides its own SOCKS inbound.",
                severity = ValidationSeverity.WARNING,
                path = "rawJson.inbounds"
            )
        }
        return issues
    }

    override suspend fun start(request: EngineSessionRequest): EngineStartResult = withContext(Dispatchers.IO) {
        if (!XrayNativeBridge.isLoaded) {
            val reasons = (descriptor().availability as? EngineAvailability.Unavailable)?.reasons.orEmpty()
            _state.value = EngineState.Unavailable(reasons)
            return@withContext EngineStartResult.Rejected(reasons)
        }
        val report = validate(request.config)
        if (!report.isValid) {
            lastError = report.errors.firstOrNull()?.message
            return@withContext EngineStartResult.Rejected(report.errors.map { it.message })
        }

        _state.value = EngineState.Preparing
        val init = initialize()
        if (init is EngineInitResult.Failed) {
            _state.value = EngineState.Failed(init.reasons.firstOrNull() ?: "Engine init failed")
            return@withContext EngineStartResult.Rejected(init.reasons)
        }

        val configJson = try {
            request.config.rawJson?.takeIf { it.isNotBlank() }
                ?: builder.build(request.config, request.socksPort)
        } catch (t: Throwable) {
            NexusLog.e("XrayEngine", "Config generation failed", t)
            _state.value = EngineState.Failed("Could not build Xray config", t.message)
            return@withContext EngineStartResult.Failed("Could not build Xray config", t.message)
        }

        val error = runCatching {
            XrayNativeBridge.nativeRun(configJson, request.tunFileDescriptor, request.socksPort)
        }.getOrElse { it.message ?: it.javaClass.simpleName }

        if (error != null) {
            lastError = error
            NexusLog.e("XrayEngine", "nativeRun failed: $error")
            _state.value = EngineState.Failed("Xray failed to start", error)
            return@withContext EngineStartResult.Failed("Xray failed to start", error)
        }

        running = true
        _state.value = EngineState.Connected(System.currentTimeMillis())
        startStatsPolling()
        EngineStartResult.Started
    }

    private fun startStatsPolling() {
        statsJob?.cancel()
        statsJob = scope.launch {
            var previousUp = 0L
            var previousDown = 0L
            var previousAt = System.currentTimeMillis()
            while (isActive) {
                delay(1_000)
                val raw = runCatching { XrayNativeBridge.nativeStats() }.getOrNull() ?: continue
                val obj: JsonObject = runCatching { json.parseToJsonElement(raw).jsonObject }.getOrNull() ?: continue
                val up = obj["uplink"]?.jsonPrimitive?.longOrNull ?: 0L
                val down = obj["downlink"]?.jsonPrimitive?.longOrNull ?: 0L
                val connections = obj["connections"]?.jsonPrimitive?.intOrNull ?: 0
                val now = System.currentTimeMillis()
                val seconds = ((now - previousAt).coerceAtLeast(1L)) / 1000.0
                _stats.value = EngineStats(
                    uplinkBytes = up,
                    downlinkBytes = down,
                    uplinkRateBps = (((up - previousUp).coerceAtLeast(0L)) / seconds).toLong(),
                    downlinkRateBps = (((down - previousDown).coerceAtLeast(0L)) / seconds).toLong(),
                    activeConnections = connections,
                    latencyMs = null,
                    sampledAtEpochMillis = now
                )
                previousUp = up
                previousDown = down
                previousAt = now
            }
        }
    }

    override suspend fun stop() {
        statsJob?.cancel()
        statsJob = null
        _state.value = EngineState.Disconnecting
        if (XrayNativeBridge.isLoaded && running) {
            val error = runCatching { XrayNativeBridge.nativeStop() }.getOrNull()
            if (error != null) NexusLog.w("XrayEngine", "nativeStop: $error")
        }
        running = false
        _stats.value = EngineStats()
        _state.value = EngineState.Idle
    }

    override suspend fun diagnostics(): EngineDiagnostics = withContext(Dispatchers.IO) {
        EngineDiagnostics(
            engineId = id,
            engineVersion = descriptor().version,
            state = _state.value,
            lastError = lastError,
            logTail = NexusLog.snapshot().takeLast(200),
            extra = mapOf(
                "bridgeLoaded" to XrayNativeBridge.isLoaded.toString(),
                "capabilities" to capabilities.features.size.toString(),
                "protocols" to capabilities.protocols.joinToString { it.name }
            )
        )
    }

    override suspend fun shutdown() {
        runCatching { stop() }
        prepared = false
    }
}
