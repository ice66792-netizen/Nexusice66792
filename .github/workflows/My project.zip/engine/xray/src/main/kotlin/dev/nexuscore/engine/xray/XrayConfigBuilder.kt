package dev.nexuscore.engine.xray

import dev.nexuscore.model.DnsMode
import dev.nexuscore.model.DomainStrategy
import dev.nexuscore.model.NexusConfig
import dev.nexuscore.model.ProxyProtocol
import dev.nexuscore.model.QueryStrategy
import dev.nexuscore.model.RuleAction
import dev.nexuscore.model.RuleKind
import dev.nexuscore.model.SecurityMode
import dev.nexuscore.model.TransportNetwork
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject

/**
 * Translates the engine independent [NexusConfig] into a Xray-core JSON
 * configuration. Pure function, no Android dependencies - unit tested.
 *
 * Only parameters that Xray actually understands are emitted. Anything that the
 * engine cannot express (for example per-app rules) is rejected earlier by
 * ConfigValidator, so this builder never silently drops user intent.
 */
class XrayConfigBuilder {

    private val json = Json { prettyPrint = true }

    fun build(config: NexusConfig, socksPort: Int = config.network.socksPort): String {
        val root = buildJsonObject {
            putJsonObject("log") {
                put("loglevel", config.performance.logLevel.name.lowercase())
            }
            put("dns", buildDns(config))
            put("inbounds", buildInbounds(socksPort))
            put("outbounds", buildOutbounds(config))
            put("routing", buildRouting(config))
        }
        return json.encodeToString(JsonObject.serializer(), root)
    }

    private fun buildDns(config: NexusConfig): JsonObject = buildJsonObject {
        val dns = config.dns
        if (dns.mode == DnsMode.SYSTEM) {
            put("servers", buildJsonArray { })
            return@buildJsonObject
        }
        putJsonArray("servers") {
            dns.servers.forEach { server ->
                add(normalizeDnsAddress(server, dns.mode))
            }
            dns.fallbackServers.forEach { add(normalizeDnsAddress(it, dns.mode)) }
        }
        put("queryStrategy", when (dns.queryStrategy) {
            QueryStrategy.USE_IP -> "UseIP"
            QueryStrategy.USE_IPV4 -> "UseIPv4"
            QueryStrategy.USE_IPV6 -> "UseIPv6"
            QueryStrategy.USE_IPV4V6 -> "UseIPv4v6"
        })
        if (dns.disableCache) put("disableCache", true)
        if (dns.hosts.isNotEmpty()) {
            putJsonObject("hosts") {
                dns.hosts.forEach { (domain, address) ->
                    if (address.contains(',')) {
                        putJsonArray(domain) { address.split(',').forEach { add(it.trim()) } }
                    } else {
                        put(domain, address)
                    }
                }
            }
        }
        put("tag", dns.tag)
    }

    private fun normalizeDnsAddress(server: String, mode: DnsMode): String = when (mode) {
        DnsMode.DNS_OVER_TLS -> if (server.startsWith("tls://")) server else "tls://$server"
        DnsMode.DNS_OVER_HTTPS -> if (server.startsWith("https://")) server else "https://$server"
        else -> server
    }

    private fun buildInbounds(socksPort: Int): JsonArray = buildJsonArray {
        addJsonObject {
            put("tag", "socks-in")
            put("listen", "127.0.0.1")
            put("port", socksPort)
            put("protocol", "socks")
            putJsonObject("settings") {
                put("auth", "noauth")
                put("udp", true)
            }
            putJsonObject("sniffing") {
                put("enabled", true)
                putJsonArray("destOverride") {
                    add("http")
                    add("tls")
                    add("quic")
                }
            }
        }
    }

    private fun buildOutbounds(config: NexusConfig): JsonArray = buildJsonArray {
        add(proxyOutbound(config))
        addJsonObject {
            put("tag", "direct")
            put("protocol", "freedom")
        }
        addJsonObject {
            put("tag", "block")
            put("protocol", "blackhole")
        }
    }

    private fun proxyOutbound(config: NexusConfig): JsonObject = buildJsonObject {
        put("tag", "proxy")
        put("protocol", protocolName(config.protocol))
        put("settings", buildProxySettings(config))
        put("streamSettings", buildStreamSettings(config))
        if (config.mux.enabled) {
            putJsonObject("mux") {
                put("enabled", true)
                put("concurrency", config.mux.concurrency)
                put("xudpConcurrency", config.mux.xudpConcurrency)
            }
        }
    }

    private fun protocolName(protocol: ProxyProtocol): String = when (protocol) {
        ProxyProtocol.VLESS -> "vless"
        ProxyProtocol.VMESS -> "vmess"
        ProxyProtocol.TROJAN -> "trojan"
        ProxyProtocol.SHADOWSOCKS -> "shadowsocks"
        ProxyProtocol.SOCKS -> "socks"
        ProxyProtocol.WIREGUARD -> "wireguard"
        ProxyProtocol.HYSTERIA2 -> "hysteria2"
    }

    private fun buildProxySettings(config: NexusConfig): JsonObject {
        val e = config.endpoint
        return buildJsonObject {
            when (config.protocol) {
                ProxyProtocol.VLESS, ProxyProtocol.VMESS -> putJsonArray("vnext") {
                    addJsonObject {
                        put("address", e.address)
                        put("port", e.port)
                        putJsonArray("users") {
                            addJsonObject {
                                put("id", e.id)
                                if (config.protocol == ProxyProtocol.VLESS) {
                                    put("encryption", "none")
                                    if (e.flow.isNotBlank()) put("flow", e.flow)
                                } else {
                                    put("alterId", 0)
                                    put("security", "auto")
                                }
                            }
                        }
                    }
                }

                ProxyProtocol.TROJAN, ProxyProtocol.SHADOWSOCKS, ProxyProtocol.SOCKS -> putJsonArray("servers") {
                    addJsonObject {
                        put("address", e.address)
                        put("port", e.port)
                        if (config.protocol == ProxyProtocol.SHADOWSOCKS) {
                            put("method", e.method)
                            put("password", e.password)
                        } else {
                            put("password", e.password)
                        }
                    }
                }

                // Xray's wireguard outbound: secretKey + peers.
                ProxyProtocol.WIREGUARD -> {
                    put("secretKey", e.wireGuardPrivateKey)
                    putJsonArray("address") { add(e.address) }
                    putJsonArray("peers") {
                        addJsonObject {
                            put("publicKey", e.wireGuardPeerPublicKey)
                            put("endpoint", "${e.address}:${e.port}")
                            if (e.preSharedKey.isNotBlank()) put("preSharedKey", e.preSharedKey)
                        }
                    }
                }

                // Not provided by Xray-core; the capability set excludes it, so this
                // branch is unreachable through the UI and kept only for exhaustiveness.
                ProxyProtocol.HYSTERIA2 -> Unit
            }
        }
    }

    private fun buildStreamSettings(config: NexusConfig): JsonObject = buildJsonObject {
        val network = when (config.transport.network) {
            TransportNetwork.TCP -> "tcp"
            TransportNetwork.WS -> "ws"
            TransportNetwork.GRPC -> "grpc"
            TransportNetwork.HTTP2 -> "http"
            TransportNetwork.XHTTP -> "xhttp"
            TransportNetwork.KCP -> "kcp"
            TransportNetwork.QUIC -> "quic"
        }
        put("network", network)
        put("security", when (config.security.mode) {
            SecurityMode.NONE -> "none"
            SecurityMode.TLS -> "tls"
            SecurityMode.REALITY -> "reality"
        })

        when (config.security.mode) {
            SecurityMode.TLS -> putJsonObject("tlsSettings") {
                val sni = config.security.serverName.ifBlank { config.endpoint.sni }
                if (sni.isNotBlank()) put("serverName", sni)
                if (config.security.allowInsecure) put("allowInsecure", true)
                put("fingerprint", config.security.fingerprint)
                if (config.security.alpn.isNotEmpty()) {
                    putJsonArray("alpn") { config.security.alpn.forEach { add(it) } }
                }
            }

            SecurityMode.REALITY -> putJsonObject("realitySettings") {
                val sni = config.security.serverName.ifBlank { config.endpoint.sni }
                put("serverName", sni)
                put("fingerprint", config.security.fingerprint.ifBlank { config.endpoint.fingerprint })
                put("publicKey", config.endpoint.publicKey)
                if (config.endpoint.shortId.isNotBlank()) put("shortId", config.endpoint.shortId)
                put("spiderX", config.endpoint.spiderX)
            }

            SecurityMode.NONE -> Unit
        }

        when (config.transport.network) {
            TransportNetwork.WS -> putJsonObject("wsSettings") {
                put("path", config.transport.path.ifBlank { "/" })
                val host = config.transport.host
                if (host.isNotBlank()) {
                    putJsonObject("headers") { put("Host", host) }
                }
            }

            TransportNetwork.GRPC -> putJsonObject("grpcSettings") {
                put("serviceName", config.transport.serviceName)
                put("multiMode", false)
            }

            TransportNetwork.HTTP2 -> putJsonObject("httpSettings") {
                put("path", config.transport.path.ifBlank { "/" })
                if (config.transport.host.isNotBlank()) {
                    putJsonArray("host") { add(config.transport.host) }
                }
            }

            TransportNetwork.XHTTP -> putJsonObject("xhttpSettings") {
                put("path", config.transport.path.ifBlank { "/" })
                if (config.transport.host.isNotBlank()) put("host", config.transport.host)
            }

            TransportNetwork.KCP -> putJsonObject("kcpSettings") {
                put("mtu", config.network.mtu)
                put("uplinkCapacity", 5)
                put("downlinkCapacity", 20)
            }

            TransportNetwork.QUIC -> putJsonObject("quicSettings") {
                put("security", "none")
                put("key", "")
            }

            TransportNetwork.TCP -> Unit
        }
    }

    private fun buildRouting(config: NexusConfig): JsonObject = buildJsonObject {
        put("domainStrategy", when (config.routing.domainStrategy) {
            DomainStrategy.AS_IS -> "AsIs"
            DomainStrategy.IP_IF_NON_MATCH -> "IPIfNonMatch"
            DomainStrategy.IP_ON_DEMAND -> "IPOnDemand"
        })
        putJsonArray("rules") {
            if (config.routing.bypassPrivateNetworks) {
                addJsonObject {
                    put("type", "field")
                    putJsonArray("ip") { add("geoip:private") }
                    put("outboundTag", "direct")
                }
            }
            config.routing.rules.filter { it.enabled && it.kind != RuleKind.APP }.forEach { rule ->
                addJsonObject {
                    put("type", "field")
                    when (rule.kind) {
                        RuleKind.DOMAIN -> putJsonArray("domain") { add("full:${rule.value}") }
                        RuleKind.DOMAIN_SUFFIX -> putJsonArray("domain") { add("domain:${rule.value}") }
                        RuleKind.DOMAIN_KEYWORD -> putJsonArray("domain") { add("keyword:${rule.value}") }
                        RuleKind.DOMAIN_REGEX -> putJsonArray("domain") { add("regexp:${rule.value}") }
                        RuleKind.IP_CIDR -> putJsonArray("ip") { add(rule.value) }
                        RuleKind.PORT -> put("port", rule.value)
                        RuleKind.NETWORK -> put("network", rule.value.lowercase())
                        RuleKind.PROTOCOL -> putJsonArray("protocol") { add(rule.value.lowercase()) }
                        RuleKind.APP -> Unit
                    }
                    put("outboundTag", when (rule.action) {
                        RuleAction.PROXY -> "proxy"
                        RuleAction.DIRECT -> "direct"
                        RuleAction.BLOCK -> "block"
                    })
                }
            }
        }
    }
}
