package dev.nexuscore.engine.xray

import dev.nexuscore.common.SecretRedactor

/**
 * Minimal JNI surface the app expects from the bundled Xray-core bridge.
 *
 * The bridge is intentionally tiny: it starts Xray with a JSON config, hands it
 * the TUN file descriptor, and returns counters. Everything else (config
 * generation, validation, routing UI) lives in Kotlin.
 *
 * The ABI contract is documented in docs/ENGINE_INTEGRATION.md and implemented
 * by `tools/xray-bridge` (Go, links Xray-core through libXray). When the shared
 * library is absent - which is the case for a plain `assembleDebug` of this
 * repository - [loadError] is non-null and the engine reports itself as
 * unavailable instead of pretending to connect.
 */
object XrayNativeBridge {

    private const val LIBRARY_NAME = "nexusxray"

    val loadError: String? by lazy {
        runCatching { System.loadLibrary(LIBRARY_NAME) }.exceptionOrNull()?.let { throwable ->
            "Native bridge 'lib$LIBRARY_NAME.so' is not bundled: ${throwable.javaClass.simpleName}. " +
                "Build it with tools/xray-bridge/build.sh and place the ABI folders in engine/xray/src/main/jniLibs."
        }?.let(SecretRedactor::redact)
    }

    val isLoaded: Boolean get() = loadError == null

    /** @return null on success, human readable error otherwise. */
    external fun nativeInit(dataDir: String, configDir: String): String?

    /** Starts Xray with [configJson] and a TUN descriptor. @return null on success. */
    external fun nativeRun(configJson: String, tunFd: Int, socksPort: Int): String?

    external fun nativeStop(): String?

    /** JSON: {"uplink":123,"downlink":456,"connections":3} */
    external fun nativeStats(): String?

    external fun nativeVersion(): String?

    fun versionOrNull(): String? = if (!isLoaded) null else runCatching { nativeVersion() }.getOrNull()
}
