-keepclasseswithmembernames class dev.nexuscore.engine.xray.XrayNativeBridge {
    native <methods>;
}
