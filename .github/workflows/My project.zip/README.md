# Nexus Core

Android-клиент для управления прокси/VPN-конфигурациями: ядро — заменяемое, интерфейс — полностью
пользовательский, конфигурации — с явным разделением «полученное» и «переопределённое».

Название меняется в одном месте: `gradle.properties` → `nexusProjectName`, `nexusAppName`
(либо `./gradlew assembleDebug -PnexusAppName="My Client"`).

## Статус (честно)

| Что | Статус |
|---|---|
| Сборка проекта | Исходники полные; сборка выполняется на машине с Android SDK (см. ниже) |
| UI (5 разделов + редакторы) | Реализовано |
| Хранение настроек/профилей/подписок | Реализовано (DataStore + атомарные JSON-файлы) |
| Валидация конфигураций, capability gating | Реализовано |
| Backup/restore с миграцией формата | Реализовано |
| Xray-core | Адаптер + JNI-контракт реализованы; **нативная библиотека не входит в репозиторий** → движок сообщает `Unavailable` |
| Simulation engine | Реализован явно, помечен `isSimulated`, рисуется баннер, трафик не идёт |
| Тесты | JVM-тесты написаны; результаты — только из реального прогона (см. раздел «Сборка») |

Приложение **не** показывает «Connected», если ядро не запустилось: состояние берётся из
`EngineProvider.state()`.

## Архитектура

```
app ─────────────── Activity, навигация, VpnService, VpnControl
core:model ──────── конфиг, профили, темы, backup (без Android-зависимостей)
core:common ─────── лог-буфер с редактированием секретов
core:engine ─────── EngineProvider, EngineRegistry, ConfigValidator, ConfigDiff, VpnControl
core:data ───────── DataStore, JSON-хранилища, merge overrides, парсеры ссылок/подписок, backup
core:design ─────── тема из данных пользователя, компоненты, форматирование
engine:mock ─────── явная симуляция (только для UI/тестов)
engine:xray ─────── XrayConfigBuilder + XrayNativeBridge (JNI)
feature:* ───────── dashboard, profiles, settings, personalization, system
```

Правила:
1. UI не знает о конкретном ядре — только `EngineProvider`.
2. Неподдерживаемые ядром параметры не показываются как «рабочие»: `EngineCapabilities` +
   `ConfigValidator` дают ошибку/предупреждение и объяснение.
3. Никаких фиктивных переключателей: каждый элемент управления пишет в сохраняемую модель.

## Приоритет настроек

```
defaults → config из профиля/подписки → overrides пользователя → session overrides
```
Реализация: `ConfigMerger` (core:data), покрыта тестами.

## Сборка

```bash
# 1. JDK 17, Android SDK 34, build-tools 34.0.0
# 2. local.properties: sdk.dir=/path/to/android-sdk
./gradlew :app:assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk

./gradlew test            # JVM-тесты
./gradlew :app:connectedDebugAndroidTest   # UI-тест (нужен эмулятор/устройство)
```

`gradle-wrapper.jar` в репозиторий не добавлен (бинарник). Если его нет:

```bash
gradle wrapper --gradle-version 8.7
```

## Ограничения Android, о которых нужно помнить

* VPN требует явного согласия (`VpnService.prepare`); отзыв согласия обрабатывается в `onRevoke`.
* Один активный VPN на устройство; другие VPN-приложения будут конфликтовать.
* Фоновое выполнение ограничено: сервис не «висит» вечно, при убийстве процесса туннель
  закрывается, состояние сбрасывается (нет фальшивого «подключено»).
* Per-app routing у Xray-core на Android недоступен → правило `APP` валидатор блокирует.

## Движок Xray

См. [`docs/ENGINE_INTEGRATION.md`](docs/ENGINE_INTEGRATION.md). Кратко: нужен `libnexusxray.so`
(сборка Xray-core + мост), который кладётся в `engine/xray/src/main/jniLibs/<abi>/`.
Без него `XrayEngineProvider` возвращает `Unavailable` с точной причиной.

## Лицензии

Xray-core — MPL-2.0 (не распространяется в этом репозитории), AndroidX/Compose/OkHttp/Kotlin —
Apache-2.0, libXray — MIT. Happ и INCY — закрытые приложения: их код, иконки и брендинг не
используются; воспроизведены только идеи UX и открытые форматы (share-ссылки, подписки).
